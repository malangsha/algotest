# Option Trading Framework

A high-performance, event-driven framework for algorithmic options trading with support for backtesting and live trading.

## Features

- Event-driven architecture for real-time market data processing
- Support for multiple timeframes (1m, 5m, 15m, 30m, 1h, 4h, 1d)
- Pluggable tick replay mechanism for backtesting and simulation
- Comprehensive technical indicators library with vectorized implementations
- Broker-agnostic design with standardized interfaces
- Finvasia broker integration for Indian markets

## Installation

```bash
# Clone the repository
git clone https://github.com/malangsha/algotest.git
cd algotest

# Install dependencies
pip install -r requirements.txt
```

## Project Structure

```
algotest/
├── brokers/                # Broker implementations
│   ├── broker_interface.py # Abstract broker interface
│   └── finvasia_broker.py  # Finvasia broker implementation
├── core/                   # Core framework components
│   ├── data_manager.py     # Market data management
│   ├── event_manager.py    # Event handling system
│   └── logging_manager.py  # Logging configuration
├── live/                   # Live trading components
│   └── market_data_feeds.py # Live market data feeds
├── models/                 # Data models
│   ├── events.py           # Event definitions
│   ├── instrument.py       # Instrument definitions
│   ├── order.py            # Order models
│   └── position.py         # Position tracking
├── strategies/             # Trading strategies
│   └── base_strategy.py    # Base strategy class
├── utils/                  # Utility modules
│   ├── constants.py        # Constants and enumerations
│   ├── technical_indicators.py # Technical analysis indicators
│   ├── tick_source.py      # Tick replay mechanism
│   └── timeframe_manager.py # Timeframe conversion
└── examples/               # Example scripts
    └── tick_replay_demo.py # Demo of tick replay mechanism
```

## Tick Replay Mechanism

The framework includes a pluggable tick replay mechanism that allows you to test strategies with different data sources:

1. **Real Tick Source**: Reads tick data from CSV files or connects to live market data feeds
2. **Synthetic Tick Source**: Generates random tick data based on configurable parameters
3. **Scripted Tick Source**: Generates tick data based on predefined scenarios (trend up, trend down, volatile, etc.)

### Example Usage

```python
# Create event manager
event_manager = EventManager()

# Create synthetic tick source
tick_source = SyntheticTickSource(
    event_manager,
    tick_interval=0.05,
    volatility=0.0002,
    trend=0.00001
)

# Create instruments
instrument = Instrument(
    symbol="NIFTY",
    exchange=Exchange.NSE,
    instrument_type=InstrumentType.INDEX
)

# Subscribe to instruments
tick_source.subscribe(instrument)

# Start tick source
tick_source.start()
```

For a complete example, see `examples/tick_replay_demo.py`.

## Running the Demo

```bash
# Run with synthetic data
python examples/tick_replay_demo.py --source synthetic

# Run with scripted scenario
python examples/tick_replay_demo.py --source scripted --scenario trend_up

# Run with real data (requires CSV files)
python examples/tick_replay_demo.py --source real --data-file data/ticks.csv
```

## Technical Indicators

The framework includes a comprehensive library of technical indicators with vectorized implementations for optimal performance:

- Moving Averages (Simple, Exponential, Weighted, Hull)
- RSI (Relative Strength Index)
- Bollinger Bands
- MACD (Moving Average Convergence Divergence)
- ATR (Average True Range)
- Stochastic Oscillator
- ADX (Average Directional Index)
- Ichimoku Cloud
- VWAP (Volume Weighted Average Price)
- Pivot Points
- SuperTrend

Example usage:

```python
import numpy as np
from utils.technical_indicators import moving_average, rsi, bollinger_bands

# Calculate indicators
prices = np.array([100.0, 101.2, 99.8, 102.3, 103.5, 101.9, 102.8])
sma = moving_average(prices, period=3)
rsi_values = rsi(prices, period=14)
upper, middle, lower = bollinger_bands(prices, period=20, std_dev=2.0)
```

## Creating a Strategy

To create a new strategy, inherit from the `BaseStrategy` class:

```python
from strategies.base_strategy import BaseStrategy

class MyStrategy(BaseStrategy):
    def __init__(self, strategy_id, instruments, timeframes, event_manager, data_manager):
        super().__init__(strategy_id, instruments, timeframes, event_manager, data_manager)
        
    def on_bar(self, event):
        # Implement your strategy logic here
        instrument = event.instrument
        timeframe = event.timeframe
        bar_data = event.data
        
        # Example: Simple moving average crossover
        if len(self.bars[instrument.symbol][timeframe]) >= 20:
            prices = [bar['close'] for bar in self.bars[instrument.symbol][timeframe]]
            sma_fast = sum(prices[-10:]) / 10
            sma_slow = sum(prices[-20:]) / 20
            
            if sma_fast > sma_slow:
                # Buy signal
                pass
            elif sma_fast < sma_slow:
                # Sell signal
                pass
```

## License

This project is licensed under the MIT License - see the LICENSE file for details.
