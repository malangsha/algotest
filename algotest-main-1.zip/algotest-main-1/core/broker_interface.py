"""
Base broker interface for the Option Trading Framework.

This module defines the standard interface that all broker implementations must follow,
providing common functionality and standardized order handling logic.
"""

import abc
import logging
from typing import Dict, List, Optional, Any, Union, Tuple

from models.order import Order, OrderStatus, OrderType
from models.instrument import Instrument
from models.position import Position
from models.market_data import MarketData, Bar, Quote, Trade
from core.event_manager import EventManager


class BrokerInterface(abc.ABC):
    """
    Abstract base class defining the interface for all broker implementations.
    
    This class provides common functionality and standardized order handling logic
    that all broker implementations should follow. Specific broker implementations
    should inherit from this class and implement the abstract methods.
    """
    
    def __init__(self):
        """Initialize the broker interface."""
        self.logger = logging.getLogger(self.__class__.__name__)
        self.event_manager = None
        
    def set_event_manager(self, event_manager: EventManager):
        """
        Set the event manager for the broker.
        
        Args:
            event_manager: The event manager instance
        """
        self.event_manager = event_manager
        
    @abc.abstractmethod
    def connect(self) -> bool:
        """
        Connect to the broker's trading API.
        
        Returns:
            bool: True if connection successful, False otherwise
        """
        pass
        
    @abc.abstractmethod
    def disconnect(self) -> bool:
        """
        Disconnect from the broker's trading API.
        
        Returns:
            bool: True if disconnection successful, False otherwise
        """
        pass
        
    @abc.abstractmethod
    def is_connected(self) -> bool:
        """
        Check if the broker connection is active.
        
        Returns:
            bool: True if connected, False otherwise
        """
        pass
        
    @abc.abstractmethod
    def place_order(self, order: Order) -> Tuple[bool, str]:
        """
        Place a new order with the broker.
        
        Args:
            order: The order to place
            
        Returns:
            Tuple[bool, str]: (success, message) tuple where success is True if order was placed successfully,
                             and message contains either the order ID or an error message
        """
        pass
        
    @abc.abstractmethod
    def cancel_order(self, order_id: str) -> Tuple[bool, str]:
        """
        Cancel an existing order.
        
        Args:
            order_id: The ID of the order to cancel
            
        Returns:
            Tuple[bool, str]: (success, message) tuple where success is True if order was cancelled successfully,
                             and message contains either a confirmation or an error message
        """
        pass
        
    @abc.abstractmethod
    def modify_order(self, order_id: str, modified_order: Order) -> Tuple[bool, str]:
        """
        Modify an existing order.
        
        Args:
            order_id: The ID of the order to modify
            modified_order: The modified order details
            
        Returns:
            Tuple[bool, str]: (success, message) tuple where success is True if order was modified successfully,
                             and message contains either a confirmation or an error message
        """
        pass
        
    @abc.abstractmethod
    def get_order_status(self, order_id: str) -> Optional[OrderStatus]:
        """
        Get the current status of an order.
        
        Args:
            order_id: The ID of the order
            
        Returns:
            Optional[OrderStatus]: The order status if found, None otherwise
        """
        pass
        
    @abc.abstractmethod
    def get_orders(self) -> List[Order]:
        """
        Get all orders (active and completed).
        
        Returns:
            List[Order]: List of all orders
        """
        pass
        
    @abc.abstractmethod
    def get_positions(self) -> List[Position]:
        """
        Get all current positions.
        
        Returns:
            List[Position]: List of all positions
        """
        pass
        
    @abc.abstractmethod
    def get_account_info(self) -> Dict[str, Any]:
        """
        Get account information (balance, margin, etc.).
        
        Returns:
            Dict[str, Any]: Dictionary containing account information
        """
        pass
        
    @abc.abstractmethod
    def subscribe_market_data(self, instrument: Instrument, data_type: str = "TICK") -> bool:
        """
        Subscribe to market data for an instrument.
        
        Args:
            instrument: The instrument to subscribe to
            data_type: The type of market data to subscribe to (e.g., "TICK", "QUOTE", "DEPTH")
            
        Returns:
            bool: True if subscription successful, False otherwise
        """
        pass
        
    @abc.abstractmethod
    def unsubscribe_market_data(self, instrument: Instrument, data_type: str = "TICK") -> bool:
        """
        Unsubscribe from market data for an instrument.
        
        Args:
            instrument: The instrument to unsubscribe from
            data_type: The type of market data to unsubscribe from
            
        Returns:
            bool: True if unsubscription successful, False otherwise
        """
        pass
        
    # Common order validation logic that can be used by all broker implementations
    def validate_order(self, order: Order) -> Tuple[bool, str]:
        """
        Validate an order before submission.
        
        Args:
            order: The order to validate
            
        Returns:
            Tuple[bool, str]: (valid, message) tuple where valid is True if order is valid,
                             and message contains either a confirmation or an error message
        """
        if not order:
            return False, "Order cannot be None"
            
        if not order.instrument:
            return False, "Order must have an instrument"
            
        if not order.quantity or order.quantity <= 0:
            return False, "Order quantity must be positive"
            
        if order.order_type == OrderType.LIMIT and (order.limit_price is None or order.limit_price <= 0):
            return False, "Limit orders must have a positive limit price"
            
        if order.order_type in [OrderType.STOP, OrderType.STOP_LIMIT] and (order.stop_price is None or order.stop_price <= 0):
            return False, "Stop orders must have a positive stop price"
            
        if order.order_type == OrderType.STOP_LIMIT and (order.limit_price is None or order.limit_price <= 0):
            return False, "Stop-limit orders must have a positive limit price"
            
        return True, "Order validation successful"
        
    # Template method for order lifecycle
    def process_order(self, order: Order) -> Tuple[bool, str]:
        """
        Process an order through its lifecycle.
        
        This is a template method that defines the order processing workflow.
        Specific broker implementations should override the abstract methods
        called within this method.
        
        Args:
            order: The order to process
            
        Returns:
            Tuple[bool, str]: (success, message) tuple where success is True if order was processed successfully,
                             and message contains either a confirmation or an error message
        """
        # Validate the order
        valid, message = self.validate_order(order)
        if not valid:
            return False, message
            
        # Place the order
        success, result = self.place_order(order)
        if not success:
            return False, result
            
        # Return the result
        return True, result
