"""
Execution handlers that process orders and submit them to appropriate venues.
FIXED: Preserves original order IDs to maintain proper order tracking throughout the system.
"""
import uuid
from datetime import datetime
from typing import Dict, List, Optional, Any, Union
from enum import Enum

from core.event_manager import EventManager
from models.events import Event, EventType, OrderEvent
from utils.constants import OrderSide, OrderStatus, OrderType
from brokers.broker_interface import BrokerInterface
from core.logging_manager import get_logger
from utils.constants import OrderType as ModelOrderType
from models.order import Order

class ExecutionHandler:
    """
    Handles the actual execution of orders by interacting with the broker interface.
    Listens for OrderEvents and translates them into broker actions.
    """
    def __init__(self, event_manager: EventManager, broker_interface: BrokerInterface):
        """
        Initialize the ExecutionHandler.

        Args:
            event_manager: The system's EventManager.
            broker_interface: The interface to the broker.
        """
        self.logger = get_logger(__name__)
        self.event_manager = event_manager
        self.broker_interface = broker_interface
        self._register_event_handlers()
        self.logger.info("Execution Handler initialized")

    def _register_event_handlers(self):
        """Register to receive Order events."""
        self.event_manager.subscribe(
            EventType.ORDER,
            self._on_order_event,
            component_name="ExecutionHandler"
        )
        self.logger.info("ExecutionHandler subscribed to ORDER events")

    def _on_order_event(self, event: OrderEvent):
        self.logger.debug(f"ExecutionHandler received order event: {event.order_id}, Symbol: {event.symbol}, Exchange: {event.exchange}, Status: {event.status}, Side: {event.side}, Type: {event.order_type}")

        # Validate the incoming OrderEvent itself first
        try:
            event.validate()
        except Exception as e:
            self.logger.error(f"Invalid OrderEvent received by ExecutionHandler: {e}. Order ID: {event.order_id}. Event: {event}")
            return

        # Ensure side and order_type are Enums for creating the Order object
        try:
            order_side_enum = event.side if isinstance(event.side, OrderSide) else OrderSide(str(event.side).upper())
            order_type_enum = event.order_type if isinstance(event.order_type, OrderType) else OrderType(str(event.order_type.value).upper())
            order_exchange_str = event.exchange.value if isinstance(event.exchange, Enum) else str(event.exchange)

            # Correctly extract the string value from the event's order_type enum
            if not (hasattr(event.order_type, 'value') and isinstance(event.order_type.value, str)):
                self.logger.error(f"ExecutionHandler: event.order_type.value is not a string. event.order_type: {event.order_type} (type: {type(event.order_type)})")
                raise ValueError(f"Cannot extract string value from event.order_type: {event.order_type}")
            
            order_type_str_value_for_model = event.order_type.value.upper()
            model_order_type_enum = ModelOrderType(order_type_str_value_for_model)
 
        except ValueError as e:
            self.logger.error(f"Invalid side/order_type/exchange in OrderEvent for order {event.order_id}: {e}. Event: {event}")
            return

        # CRITICAL FIX: Preserve the original order ID from the event
        # This ensures that when broker responds, the OrderManager can match the order
        order_for_broker = Order(
            instrument_id=event.symbol,
            quantity=event.quantity,
            side=order_side_enum,
            order_type=order_type_enum,
            price=event.price if event.price is not None else 0.0,
            strategy_id=event.strategy_id,
            exchange=order_exchange_str
        )
        
        # CRITICAL: Override the auto-generated order_id with the original from the event
        order_for_broker.order_id = event.order_id
        
        # Add broker_order_id if it exists on the event (e.g. for modify/cancel)
        if hasattr(event, 'broker_order_id') and event.broker_order_id:
            order_for_broker.broker_order_id = event.broker_order_id

        # Determine action based on event status or an explicit action field
        action = getattr(event, 'action', None)
        order_status_enum = event.status if isinstance(event.status, OrderStatus) else OrderStatus(str(event.status.value).upper())

        if action == 'SUBMIT' or order_status_enum == OrderStatus.PENDING or order_status_enum == OrderStatus.CREATED:
            self.logger.info(f"ExecutionHandler: Submitting order {order_for_broker.order_id} to broker. Details: {order_for_broker}")
            try:
                if not self.broker_interface.is_connected():
                    self.logger.warning("Broker not connected. Attempting to connect before submitting order.")
                    if not self.broker_interface.connect():
                        self.logger.error(f"Failed to connect to broker. Cannot submit order {order_for_broker.order_id}.")
                        return

                broker_response_order_id = self.broker_interface.place_order(order_for_broker)

                if broker_response_order_id:
                    self.logger.info(f"Order {order_for_broker.order_id} submitted to broker. Broker assigned ID: {broker_response_order_id}")
                else:
                    self.logger.error(f"Broker failed to place order {order_for_broker.order_id}. No broker ID received or submission failed.")
            except Exception as e:
                self.logger.error(f"Error submitting order {order_for_broker.order_id} via broker: {e}", exc_info=True)

        elif action == 'CANCEL' or order_status_enum == OrderStatus.PENDING_CANCEL:
            id_to_cancel = order_for_broker.broker_order_id if order_for_broker.broker_order_id else order_for_broker.order_id
            self.logger.info(f"ExecutionHandler: Cancelling order {id_to_cancel} with broker.")
            try:
                success = self.broker_interface.cancel_order(id_to_cancel)
                if success:
                    self.logger.info(f"Order {id_to_cancel} cancellation request submitted successfully.")
                else:
                    self.logger.error(f"Broker failed to cancel order {id_to_cancel}.")
            except Exception as e:
                self.logger.error(f"Error cancelling order {id_to_cancel} via broker: {e}", exc_info=True)

        elif action == 'MODIFY' or order_status_enum == OrderStatus.PENDING_REPLACE:
            id_to_modify = order_for_broker.broker_order_id if order_for_broker.broker_order_id else order_for_broker.order_id
            self.logger.info(f"ExecutionHandler: Modifying order {id_to_modify} with broker. New params: Px={order_for_broker.price}, Qty={order_for_broker.quantity}")
            try:
                success = self.broker_interface.modify_order(
                    order_id_to_modify=id_to_modify,
                    price=order_for_broker.price,
                    quantity=order_for_broker.quantity,
                    trigger_price=order_for_broker.trigger_price
                )
                if success:
                    self.logger.info(f"Order {id_to_modify} modification request submitted successfully.")
                else:
                    self.logger.error(f"Broker failed to modify order {id_to_modify}.")
            except Exception as e:
                self.logger.error(f"Error modifying order {id_to_modify} via broker: {e}", exc_info=True)
        else:
            self.logger.debug(f"ExecutionHandler: Ignoring order event {event.order_id} with status {order_status_enum.value} and no specific action.")

    def start(self):
        self.logger.info("Execution Handler started (no background tasks)")

    def stop(self):
        self.logger.info("Execution Handler stopped")


class SimulatedExecutionHandler(ExecutionHandler):
    """
    Simulated execution handler for backtesting and demo.
    Processes orders against market data and generates fills.
    """
    
    def __init__(self, market_data_feed, event_manager: EventManager, slippage: float = 0.0):
        """Initialize the simulated execution handler.
        
        Args:
            market_data_feed: The market data feed to get prices from
            event_manager: The event manager to dispatch events
            slippage: The slippage factor to apply to executions (e.g., 0.001 for 0.1%)
        """
        super().__init__(event_manager)
        self.market_data_feed = market_data_feed
        self.slippage = slippage
        self.filled_orders: Dict[str, Order] = {}
        self.cancelled_orders: Dict[str, Order] = {}
        
        # Register for market data events to process orders against
        self.event_manager.subscribe(EventType.MARKET_DATA, self.on_market_data, component_name="SimulatedExecutionHandler")
    
    def submit_order(self, order: Order) -> bool:
        """Submit an order to the simulated execution system.
        
        Args:
            order: The order to submit
            
        Returns:
            bool: True if the order was accepted
        """
        try:
            # Generate a broker order ID (in real systems this would come from the broker)
            order.broker_order_id = f"sim-{uuid.uuid4()}"
            
            # Update order status
            order.status = OrderStatus.PENDING
            
            # Store the order
            self.orders[order.order_id] = order
            
            # Publish the order event
            self._publish_order_event(order, "SUBMITTED")
            
            # For market orders, try to execute immediately
            if order.order_type == OrderType.MARKET:
                self._try_execute_market_order(order)
            
            self.logger.info(f"Order submitted: {order.order_id} - {order.instrument.symbol} {order.direction} {order.quantity}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error submitting order: {str(e)}")
            return False
    
    def cancel_order(self, order_id: str) -> bool:
        """Cancel an existing order.
        
        Args:
            order_id: The ID of the order to cancel
            
        Returns:
            bool: True if the order was cancelled successfully
        """
        if order_id not in self.orders:
            self.logger.warning(f"Cannot cancel order {order_id} - not found")
            return False
            
        order = self.orders[order_id]
        
        # Only cancel if the order is still pending
        if order.status in [OrderStatus.PENDING, OrderStatus.SUBMITTED]:
            order.status = OrderStatus.CANCELLED
            
            # Remove from active orders
            self.cancelled_orders[order_id] = order
            del self.orders[order_id]
            
            # Publish cancel event
            self._publish_order_event(order, "CANCELLED")
            
            self.logger.info(f"Order cancelled: {order_id}")
            return True
        else:
            self.logger.warning(f"Cannot cancel order {order_id} - status is {order.status}")
            return False
    
    def on_market_data(self, event: Event) -> None:
        """
        Process market data events to potentially execute pending orders.
        
        Args:
            event: Market data event
        """
        try:
            # Check each pending order against the current market data
            for order_id, order in list(self.orders.items()):
                if order.status in [OrderStatus.PENDING, OrderStatus.SUBMITTED]:
                    # For limit and stop orders, check if conditions are met
                    if order.order_type != OrderType.MARKET:
                        self._try_execute_limit_stop_order(order, event)
            
        except Exception as e:
            self.logger.error(f"Error processing market data for order execution: {str(e)}")
    
    def _try_execute_market_order(self, order: Order) -> None:
        """
        Try to execute a market order immediately using current market data.
        
        Args:
            order: The order to execute
        """
        # Get current market data for the instrument
        symbol = order.instrument.symbol
        if symbol not in self.market_data_feed.prices:
            self.logger.warning(f"No market data available for {symbol}, cannot execute market order")
            return
            
        price_data = self.market_data_feed.prices[symbol]
        
        # Use bid for SELL orders and ask for BUY orders
        if order.direction == "SELL":
            execution_price = price_data.get('bid', price_data.get('current'))
        else:  # BUY
            execution_price = price_data.get('ask', price_data.get('current'))
        
        # Apply slippage
        slippage_factor = 1.0 + (self.slippage if order.direction == "BUY" else -self.slippage)
        execution_price = execution_price * slippage_factor
        
        # Execute the order
        self._execute_order(order, execution_price)
    
    def _try_execute_limit_stop_order(self, order: Order, event: Event) -> None:
        """
        Try to execute a limit or stop order based on current market data.
        
        Args:
            order: The order to potentially execute
            event: Market data event
        """
        if hasattr(event, 'symbol') and event.symbol != order.instrument.symbol:
            return  # Not relevant for this order
            
        current_price = None
        
        # Get current price from the event
        if hasattr(event, 'data'):
            price_data = event.data
            # Use close price or current price as available
            current_price = price_data.get('close', price_data.get('current'))
        
        if current_price is None:
            return  # No price available
            
        should_execute = False
        
        # Check if conditions are met for this order type
        if order.order_type == OrderType.LIMIT:
            # For BUY limit orders, execute when price <= limit price
            if order.direction == "BUY" and current_price <= order.price:
                should_execute = True
            # For SELL limit orders, execute when price >= limit price
            elif order.direction == "SELL" and current_price >= order.price:
                should_execute = True
                
        elif order.order_type == OrderType.SL:
            # For BUY stop orders, execute when price >= stop price
            if order.direction == "BUY" and current_price >= order.price:
                should_execute = True
            # For SELL stop orders, execute when price <= stop price
            elif order.direction == "SELL" and current_price <= order.price:
                should_execute = True
                
        # Execute if conditions are met
        if should_execute:
            # For stop orders, we execute at market price (with slippage)
            if order.order_type == OrderType.SL:
                # Apply slippage
                slippage_factor = 1.0 + (self.slippage if order.direction == "BUY" else -self.slippage)
                execution_price = current_price * slippage_factor
            else:
                # For limit orders, we execute at the limit price
                execution_price = order.price
                
            self._execute_order(order, execution_price)
    
    def _execute_order(self, order: Order, price: float) -> None:
        """
        Execute an order at the specified price.
        
        Args:
            order: The order to execute
            price: The execution price
        """
        # Update order
        order.status = OrderStatus.FILLED
        order.filled_price = price
        order.filled_quantity = order.quantity
        order.filled_time = datetime.now()
        
        # Move to filled orders
        self.filled_orders[order.order_id] = order
        if order.order_id in self.orders:
            del self.orders[order.order_id]
        
        # Publish fill event
        self._publish_order_event(order, "FILLED")
        
        self.logger.info(
            f"Order filled: {order.order_id} - {order.instrument.symbol} "
            f"{order.direction} {order.quantity} @ {price:.4f}"
        )