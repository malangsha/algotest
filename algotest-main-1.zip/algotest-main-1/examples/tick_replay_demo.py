#!/usr/bin/env python
"""
Tick Replay Mechanism Demo

This script demonstrates how to use the pluggable tick replay mechanism
to test trading strategies with both real and synthetic market data.

Features:
- Multiple data source options (real, synthetic, scripted)
- Configurable market scenarios
- Real-time visualization of price data
- Performance metrics tracking
- Strategy signal generation and logging
- Full event lifecycle validation
"""

import os
import sys
import time
import logging
import argparse
import threading
from datetime import datetime, timedelta
from pathlib import Path

# Add the project root to the Python path to ensure imports work correctly
project_root = str(Path(__file__).resolve().parent.parent)
if project_root not in sys.path:
    sys.path.insert(0, project_root)

try:
    from models.instrument import Instrument, AssetClass
    from utils.constants import InstrumentType, Exchange, EventType, MarketDataType
    from models.events import BarEvent, Event, MarketDataEvent, SignalEvent, OrderEvent, ExecutionEvent, FillEvent, PositionEvent, AccountEvent
    from core.event_manager import EventManager
    from core.data_manager import DataManager
    from utils.tick_source import RealTickSource, SyntheticTickSource, ScriptedTickSource
    from utils.timeframe_manager import TimeframeManager
    import numpy as np
    import pandas as pd
except ImportError as e:
    print(f"Error importing required modules: {e}")
    print(f"Current sys.path: {sys.path}")
    print(f"Please run this script from the project root directory")
    sys.exit(1)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("tick_replay_demo.log")
    ]
)
logger = logging.getLogger("tick_replay_demo")

# Global variables for visualization
price_data = {}
signal_data = {}
performance_metrics = {
    'trades': 0,
    'wins': 0,
    'losses': 0,
    'profit_factor': 0,
    'max_drawdown': 0,
    'sharpe_ratio': 0
}

# Event flow tracking
event_flow = {
    'market_data_events': 0,
    'bar_events': 0,
    'signal_events': 0,
    'order_events': 0,
    'execution_events': 0,
    'fill_events': 0,
    'position_events': 0,
    'account_events': 0,
    'complete_chains': 0,
    'broken_chains': 0
}

# Event trace log for debugging
event_trace = []
MAX_TRACE_EVENTS = 100  # Limit the number of events in the trace log

# Mock Broker class for demo purposes
class MockBroker:
    """
    A simple mock broker implementation for demo purposes.
    Provides the minimal interface required by DataManager.
    """
    
    def __init__(self):
        """Initialize the mock broker."""
        self.logger = logging.getLogger("MockBroker")
        self.event_manager = None
        self._connected = True
        
    def set_event_manager(self, event_manager):
        """Set the event manager for the broker."""
        self.event_manager = event_manager
        
    def is_connected(self):
        """Check if the broker is connected."""
        return self._connected
        
    def connect(self):
        """Connect to the broker."""
        self._connected = True
        return True
        
    def disconnect(self):
        """Disconnect from the broker."""
        self._connected = False
        return True
        
    def subscribe_market_data(self, instrument, data_type=None):
        """Subscribe to market data for an instrument."""
        self.logger.debug(f"Mock broker subscribed to {instrument.symbol}")
        return True
        
    def unsubscribe_market_data(self, instrument, data_type=None):
        """Unsubscribe from market data for an instrument."""
        self.logger.debug(f"Mock broker unsubscribed from {instrument.symbol}")
        return True

# Define a simplified strategy base class for the demo
class DemoStrategy:
    """
    Simplified strategy base class for demonstration purposes.
    This class provides the minimal interface needed for the demo.
    """
    
    def __init__(self, strategy_id, instruments, timeframes, event_manager, data_manager):
        """
        Initialize the strategy.
        
        Args:
            strategy_id: Unique identifier for the strategy
            instruments: List of instruments to trade
            timeframes: List of timeframes to monitor
            event_manager: Event manager instance
            data_manager: Data manager instance
        """
        self.strategy_id = strategy_id
        self.instruments = instruments
        self.timeframes = timeframes
        self.event_manager = event_manager
        self.data_manager = data_manager
        self.logger = logging.getLogger(f"DemoStrategy-{strategy_id}")
        
        # Initialize data structures for storing bars
        self.bars = {}
        for instrument in instruments:
            self.bars[instrument.symbol] = {}
            for timeframe in timeframes:
                self.bars[instrument.symbol][timeframe] = []
        
        # CRITICAL FIX: Register for bar events directly with event_manager
        self.event_manager.subscribe(EventType.BAR, self._on_bar_event)
        
        # Log subscription
        for instrument in instruments:
            for timeframe in timeframes:
                self.logger.info(f"Subscribed to BAR events for {instrument.symbol} @ {timeframe}")
        
    def _on_bar_event(self, event):
        """
        Internal handler for bar events.
        
        Args:
            event: Bar event
        """
        if not isinstance(event, BarEvent):
            return
            
        instrument = event.instrument
        timeframe = event.timeframe
        
        # Check if we're interested in this instrument and timeframe
        if instrument.symbol not in self.bars or timeframe not in self.bars[instrument.symbol]:
            return
            
        # Store the bar data
        bar_data = {
            'timestamp': datetime.fromtimestamp(event.timestamp / 1000),  # Convert from ms to seconds
            'open': event.open_price,
            'high': event.high_price,
            'low': event.low_price,
            'close': event.close_price,
            'volume': event.volume
        }
        self.bars[instrument.symbol][timeframe].append(bar_data)
        
        # Call the strategy's bar handler
        self.on_bar(event)
        
    def on_bar(self, event):
        """
        Handle bar events. To be implemented by subclasses.
        
        Args:
            event: Bar event
        """
        pass

class EnhancedDemoStrategy(DemoStrategy):
    """
    Enhanced demonstration strategy that implements multiple technical indicators
    and trading signals with performance tracking.
    """
    
    def __init__(self, strategy_id, instruments, timeframes, event_manager, data_manager, 
                 fast_ma=5, slow_ma=20, rsi_period=14, rsi_overbought=70, rsi_oversold=30):
        """
        Initialize the strategy with configurable parameters.
        
        Args:
            strategy_id: Unique identifier for the strategy
            instruments: List of instruments to trade
            timeframes: List of timeframes to monitor
            event_manager: Event manager instance
            data_manager: Data manager instance
            fast_ma: Fast moving average period
            slow_ma: Slow moving average period
            rsi_period: RSI calculation period
            rsi_overbought: RSI overbought threshold
            rsi_oversold: RSI oversold threshold
        """
        super().__init__(strategy_id, instruments, timeframes, event_manager, data_manager)
        
        # Strategy parameters
        self.fast_ma = fast_ma
        self.slow_ma = slow_ma
        self.rsi_period = rsi_period
        self.rsi_overbought = rsi_overbought
        self.rsi_oversold = rsi_oversold
        
        # Trading state
        self.positions = {}  # symbol -> position (1 for long, -1 for short, 0 for flat)
        self.entry_prices = {}  # symbol -> entry price
        self.trade_history = []  # List of completed trades
        
        # Initialize positions
        for instrument in instruments:
            self.positions[instrument.symbol] = 0
            self.entry_prices[instrument.symbol] = 0
            
        self.logger.info(f"Strategy initialized with parameters: fast_ma={fast_ma}, slow_ma={slow_ma}, "
                         f"rsi_period={rsi_period}, rsi_overbought={rsi_overbought}, rsi_oversold={rsi_oversold}")
        
    def on_bar(self, event):
        """
        Handle bar events by analyzing price data and generating trading signals.
        
        Args:
            event: Bar event containing price data
        """
        instrument = event.instrument
        timeframe = event.timeframe
        symbol = instrument.symbol
        
        # Skip if we don't have enough data
        if len(self.bars[symbol][timeframe]) < max(self.slow_ma, self.rsi_period) + 5:
            return
            
        # Extract price data
        closes = np.array([bar['close'] for bar in self.bars[symbol][timeframe]])
        highs = np.array([bar['high'] for bar in self.bars[symbol][timeframe]])
        lows = np.array([bar['low'] for bar in self.bars[symbol][timeframe]])
        
        # Calculate indicators
        fast_ma_values = self.calculate_sma(closes, self.fast_ma)
        slow_ma_values = self.calculate_sma(closes, self.slow_ma)
        rsi_values = self.calculate_rsi(closes, self.rsi_period)
        upper_band, middle_band, lower_band = self.calculate_bollinger_bands(closes, 20, 2.0)
        
        # Current indicator values
        current_fast_ma = fast_ma_values[-1]
        current_slow_ma = slow_ma_values[-1]
        current_rsi = rsi_values[-1]
        current_upper_band = upper_band[-1]
        current_lower_band = lower_band[-1]
        current_close = closes[-1]
        
        # Previous indicator values
        prev_fast_ma = fast_ma_values[-2]
        prev_slow_ma = slow_ma_values[-2]
        prev_rsi = rsi_values[-2]
        
        # Store price data for visualization
        if symbol not in price_data:
            price_data[symbol] = {
                'timestamps': [],
                'closes': [],
                'fast_ma': [],
                'slow_ma': [],
                'rsi': [],
                'upper_band': [],
                'lower_band': []
            }
            
        timestamp = datetime.fromtimestamp(event.timestamp / 1000)  # Convert from ms to seconds
        price_data[symbol]['timestamps'].append(timestamp)
        price_data[symbol]['closes'].append(current_close)
        price_data[symbol]['fast_ma'].append(current_fast_ma)
        price_data[symbol]['slow_ma'].append(current_slow_ma)
        price_data[symbol]['rsi'].append(current_rsi)
        price_data[symbol]['upper_band'].append(current_upper_band)
        price_data[symbol]['lower_band'].append(current_lower_band)
        
        # Limit data points to prevent memory issues
        max_data_points = 1000
        if len(price_data[symbol]['timestamps']) > max_data_points:
            for key in price_data[symbol]:
                price_data[symbol][key] = price_data[symbol][key][-max_data_points:]
        
        # Generate trading signals
        signal = 0  # 0 for no signal, 1 for buy, -1 for sell
        
        # MA Crossover signal
        ma_crossover_signal = 0
        if prev_fast_ma <= prev_slow_ma and current_fast_ma > current_slow_ma:
            ma_crossover_signal = 1  # Bullish crossover
        elif prev_fast_ma >= prev_slow_ma and current_fast_ma < current_slow_ma:
            ma_crossover_signal = -1  # Bearish crossover
            
        # RSI signal
        rsi_signal = 0
        if current_rsi < self.rsi_oversold:
            rsi_signal = 1  # Oversold
        elif current_rsi > self.rsi_overbought:
            rsi_signal = -1  # Overbought
            
        # Bollinger Band signal
        bb_signal = 0
        if current_close < current_lower_band:
            bb_signal = 1  # Price below lower band
        elif current_close > current_upper_band:
            bb_signal = -1  # Price above upper band
            
        # Combine signals (simple majority vote)
        signals = [ma_crossover_signal, rsi_signal, bb_signal]
        buy_signals = signals.count(1)
        sell_signals = signals.count(-1)
        
        if buy_signals > sell_signals:
            signal = 1
        elif sell_signals > buy_signals:
            signal = -1
            
        # Store signal data for visualization
        if symbol not in signal_data:
            signal_data[symbol] = {
                'timestamps': [],
                'signals': []
            }
            
        signal_data[symbol]['timestamps'].append(timestamp)
        signal_data[symbol]['signals'].append(signal)
        
        # Limit signal data points
        if len(signal_data[symbol]['timestamps']) > max_data_points:
            for key in signal_data[symbol]:
                signal_data[symbol][key] = signal_data[symbol][key][-max_data_points:]
        
        # Log indicators and signals
        self.logger.info(
            f"Bar: {symbol} {timeframe} - "
            f"Close: {current_close:.2f}, "
            f"Fast MA: {current_fast_ma:.2f}, "
            f"Slow MA: {current_slow_ma:.2f}, "
            f"RSI: {current_rsi:.2f}, "
            f"BB Upper: {current_upper_band:.2f}, "
            f"BB Lower: {current_lower_band:.2f}, "
            f"Signal: {signal}"
        )
        
        # Execute trading logic
        current_position = self.positions[symbol]
        
        # Entry logic
        if current_position == 0:  # No position
            if signal == 1:  # Buy signal
                self.positions[symbol] = 1
                self.entry_prices[symbol] = current_close
                self.logger.info(f"BUY SIGNAL: {symbol} at {current_close:.2f}")
                
                # Create and publish signal event
                signal_event = SignalEvent(
                    event_type=EventType.SIGNAL,
                    timestamp=int(time.time() * 1000),
                    instrument=instrument,
                    strategy_id=self.strategy_id,
                    signal_type="LONG",
                    side="BUY",
                    price=current_close,
                    quantity=1,
                    timeframe=timeframe
                )
                self.event_manager.publish(signal_event)
                
                # Track event flow
                event_flow['signal_events'] += 1
                
                # Add to event trace
                add_to_event_trace("SIGNAL", signal_event)
                
            elif signal == -1:  # Sell signal
                self.positions[symbol] = -1
                self.entry_prices[symbol] = current_close
                self.logger.info(f"SELL SIGNAL: {symbol} at {current_close:.2f}")
                
                # Create and publish signal event
                signal_event = SignalEvent(
                    event_type=EventType.SIGNAL,
                    timestamp=int(time.time() * 1000),
                    instrument=instrument,
                    strategy_id=self.strategy_id,
                    signal_type="SHORT",
                    side="SELL",
                    price=current_close,
                    quantity=1,
                    timeframe=timeframe
                )
                self.event_manager.publish(signal_event)
                
                # Track event flow
                event_flow['signal_events'] += 1
                
                # Add to event trace
                add_to_event_trace("SIGNAL", signal_event)
                
        # Exit logic
        elif current_position == 1:  # Long position
            if signal == -1:  # Sell signal
                profit = current_close - self.entry_prices[symbol]
                profit_pct = (profit / self.entry_prices[symbol]) * 100
                self.positions[symbol] = 0
                self.logger.info(f"CLOSE LONG: {symbol} at {current_close:.2f}, "
                                f"Profit: {profit:.2f} ({profit_pct:.2f}%)")
                
                # Create and publish signal event
                signal_event = SignalEvent(
                    event_type=EventType.SIGNAL,
                    timestamp=int(time.time() * 1000),
                    instrument=instrument,
                    strategy_id=self.strategy_id,
                    signal_type="EXIT_LONG",
                    side="SELL",
                    price=current_close,
                    quantity=1,
                    timeframe=timeframe
                )
                self.event_manager.publish(signal_event)
                
                # Track event flow
                event_flow['signal_events'] += 1
                
                # Add to event trace
                add_to_event_trace("SIGNAL", signal_event)
                
                # Record trade
                self.trade_history.append({
                    'symbol': symbol,
                    'entry_time': price_data[symbol]['timestamps'][-len(self.bars[symbol][timeframe])],
                    'exit_time': timestamp,
                    'entry_price': self.entry_prices[symbol],
                    'exit_price': current_close,
                    'position': 'LONG',
                    'profit': profit,
                    'profit_pct': profit_pct
                })
                
                # Update performance metrics
                performance_metrics['trades'] += 1
                if profit > 0:
                    performance_metrics['wins'] += 1
                else:
                    performance_metrics['losses'] += 1
                    
        elif current_position == -1:  # Short position
            if signal == 1:  # Buy signal
                profit = self.entry_prices[symbol] - current_close
                profit_pct = (profit / self.entry_prices[symbol]) * 100
                self.positions[symbol] = 0
                self.logger.info(f"CLOSE SHORT: {symbol} at {current_close:.2f}, "
                                f"Profit: {profit:.2f} ({profit_pct:.2f}%)")
                
                # Create and publish signal event
                signal_event = SignalEvent(
                    event_type=EventType.SIGNAL,
                    timestamp=int(time.time() * 1000),
                    instrument=instrument,
                    strategy_id=self.strategy_id,
                    signal_type="EXIT_SHORT",
                    side="BUY",
                    price=current_close,
                    quantity=1,
                    timeframe=timeframe
                )
                self.event_manager.publish(signal_event)
                
                # Track event flow
                event_flow['signal_events'] += 1
                
                # Add to event trace
                add_to_event_trace("SIGNAL", signal_event)
                
                # Record trade
                self.trade_history.append({
                    'symbol': symbol,
                    'entry_time': price_data[symbol]['timestamps'][-len(self.bars[symbol][timeframe])],
                    'exit_time': timestamp,
                    'entry_price': self.entry_prices[symbol],
                    'exit_price': current_close,
                    'position': 'SHORT',
                    'profit': profit,
                    'profit_pct': profit_pct
                })
                
                # Update performance metrics
                performance_metrics['trades'] += 1
                if profit > 0:
                    performance_metrics['wins'] += 1
                else:
                    performance_metrics['losses'] += 1
        
        # Update performance metrics
        if performance_metrics['trades'] > 0:
            performance_metrics['profit_factor'] = (
                performance_metrics['wins'] / performance_metrics['trades']
                if performance_metrics['trades'] > 0 else 0
            )
            
            # Calculate max drawdown and Sharpe ratio if we have enough trades
            if len(self.trade_history) >= 5:
                # Calculate max drawdown
                equity_curve = [0]
                for trade in self.trade_history:
                    equity_curve.append(equity_curve[-1] + trade['profit'])
                
                max_equity = 0
                max_drawdown = 0
                for equity in equity_curve:
                    if equity > max_equity:
                        max_equity = equity
                    drawdown = max_equity - equity
                    if drawdown > max_drawdown:
                        max_drawdown = drawdown
                
                if max_equity > 0:
                    max_drawdown_pct = (max_drawdown / max_equity) * 100
                    performance_metrics['max_drawdown'] = max_drawdown_pct
                
                # Calculate Sharpe ratio
                returns = [trade['profit_pct'] for trade in self.trade_history]
                if len(returns) > 0:
                    mean_return = np.mean(returns)
                    std_return = np.std(returns)
                    if std_return > 0:
                        performance_metrics['sharpe_ratio'] = mean_return / std_return
    
    def calculate_sma(self, prices, period):
        """Calculate Simple Moving Average"""
        if len(prices) < period:
            return np.array([np.nan] * len(prices))
        
        sma = np.zeros_like(prices)
        sma[:period] = np.nan
        
        for i in range(period, len(prices) + 1):
            sma[i-1] = np.mean(prices[i-period:i])
            
        return sma
    
    def calculate_rsi(self, prices, period):
        """Calculate Relative Strength Index"""
        if len(prices) < period + 1:
            return np.array([np.nan] * len(prices))
        
        # Calculate price changes
        deltas = np.diff(prices)
        
        # Initialize arrays
        rsi = np.zeros_like(prices)
        rsi[:period] = np.nan
        
        # Calculate gains and losses
        gains = np.zeros_like(deltas)
        losses = np.zeros_like(deltas)
        
        gains[deltas > 0] = deltas[deltas > 0]
        losses[deltas < 0] = -deltas[deltas < 0]
        
        # Calculate average gains and losses
        avg_gain = np.zeros_like(prices)
        avg_loss = np.zeros_like(prices)
        
        # First average
        avg_gain[period] = np.mean(gains[:period])
        avg_loss[period] = np.mean(losses[:period])
        
        # Subsequent averages
        for i in range(period + 1, len(prices)):
            avg_gain[i] = (avg_gain[i-1] * (period - 1) + gains[i-1]) / period
            avg_loss[i] = (avg_loss[i-1] * (period - 1) + losses[i-1]) / period
        
        # Calculate RS and RSI
        rs = avg_gain[period:] / (avg_loss[period:] + 1e-10)  # Add small value to avoid division by zero
        rsi[period:] = 100 - (100 / (1 + rs))
        
        return rsi
    
    def calculate_bollinger_bands(self, prices, period, num_std):
        """Calculate Bollinger Bands"""
        if len(prices) < period:
            nan_array = np.array([np.nan] * len(prices))
            return nan_array, nan_array, nan_array
        
        # Calculate SMA
        middle_band = self.calculate_sma(prices, period)
        
        # Calculate standard deviation
        std = np.zeros_like(prices)
        std[:period] = np.nan
        
        for i in range(period, len(prices) + 1):
            std[i-1] = np.std(prices[i-period:i])
        
        # Calculate upper and lower bands
        upper_band = middle_band + (std * num_std)
        lower_band = middle_band - (std * num_std)
        
        return upper_band, middle_band, lower_band

def add_to_event_trace(event_type, event):
    """Add an event to the trace log"""
    if len(event_trace) >= MAX_TRACE_EVENTS:
        event_trace.pop(0)  # Remove oldest event
    
    event_trace.append({
        'timestamp': datetime.fromtimestamp(event.timestamp / 1000).strftime('%Y-%m-%d %H:%M:%S.%f'),
        'event_type': event_type,
        'event_id': event.event_id,
        'details': str(event)
    })

def on_market_data_event(event):
    """Handler for market data events"""
    if not isinstance(event, MarketDataEvent):
        return
    
    event_flow['market_data_events'] += 1
    add_to_event_trace("MARKET_DATA", event)
    
    # CRITICAL FIX: Use MarketDataType.LAST_PRICE.value instead of 'last_price'
    logger.debug(f"MarketDataEvent: {event.instrument.symbol} - {event.data.get(MarketDataType.LAST_PRICE.value)}")

def on_bar_event(event):
    """Handler for bar events"""
    if not isinstance(event, BarEvent):
        return
    
    event_flow['bar_events'] += 1
    add_to_event_trace("BAR", event)
    
    logger.debug(f"BarEvent: {event.instrument.symbol} - {event.timeframe} - {event.close_price}")

def on_signal_event(event):
    """Handler for signal events"""
    if not isinstance(event, SignalEvent):
        return
    
    event_flow['signal_events'] += 1
    add_to_event_trace("SIGNAL", event)
    
    logger.debug(f"SignalEvent: {event.instrument.symbol} - {event.signal_type} - {event.price}")
    
    # Create and publish order event
    order_event = OrderEvent(
        event_type=EventType.ORDER,
        timestamp=int(time.time() * 1000),
        instrument=event.instrument,
        strategy_id=event.strategy_id,
        order_id=f"ORD-{int(time.time())}-{event.instrument.symbol}",
        order_type="MARKET",
        side=event.side,
        quantity=event.quantity,
        price=event.price,
        status="NEW"
    )
    
    # Publish the order event
    event.event_manager.publish(order_event)
    
    # Track event flow
    event_flow['order_events'] += 1
    
    # Add to event trace
    add_to_event_trace("ORDER", order_event)

def on_order_event(event):
    """Handler for order events"""
    if not isinstance(event, OrderEvent):
        return
    
    event_flow['order_events'] += 1
    add_to_event_trace("ORDER", event)
    
    logger.debug(f"OrderEvent: {event.instrument.symbol} - {event.side} - {event.quantity} @ {event.price}")
    
    # Create and publish execution event
    execution_event = ExecutionEvent(
        event_type=EventType.EXECUTION,
        timestamp=int(time.time() * 1000),
        instrument=event.instrument,
        strategy_id=event.strategy_id,
        order_id=event.order_id,
        execution_id=f"EXEC-{int(time.time())}-{event.instrument.symbol}",
        side=event.side,
        quantity=event.quantity,
        price=event.price,
        status="FILLED"
    )
    
    # Publish the execution event
    event.event_manager.publish(execution_event)
    
    # Track event flow
    event_flow['execution_events'] += 1
    
    # Add to event trace
    add_to_event_trace("EXECUTION", execution_event)

def on_execution_event(event):
    """Handler for execution events"""
    if not isinstance(event, ExecutionEvent):
        return
    
    event_flow['execution_events'] += 1
    add_to_event_trace("EXECUTION", event)
    
    logger.debug(f"ExecutionEvent: {event.instrument.symbol} - {event.side} - {event.quantity} @ {event.price}")
    
    # Create and publish fill event
    fill_event = FillEvent(
        event_type=EventType.FILL,
        timestamp=int(time.time() * 1000),
        instrument=event.instrument,
        strategy_id=event.strategy_id,
        order_id=event.order_id,
        execution_id=event.execution_id,
        side=event.side,
        quantity=event.quantity,
        price=event.price,
        commission=event.price * event.quantity * 0.001,  # 0.1% commission
        status="FILLED"
    )
    
    # Publish the fill event
    event.event_manager.publish(fill_event)
    
    # Track event flow
    event_flow['fill_events'] += 1
    
    # Add to event trace
    add_to_event_trace("FILL", fill_event)

def on_fill_event(event):
    """Handler for fill events"""
    if not isinstance(event, FillEvent):
        return
    
    event_flow['fill_events'] += 1
    add_to_event_trace("FILL", event)
    
    logger.debug(f"FillEvent: {event.instrument.symbol} - {event.side} - {event.quantity} @ {event.price}")
    
    # Create and publish position event
    position_event = PositionEvent(
        event_type=EventType.POSITION,
        timestamp=int(time.time() * 1000),
        instrument=event.instrument,
        strategy_id=event.strategy_id,
        position_id=f"POS-{int(time.time())}-{event.instrument.symbol}",
        side=event.side,
        quantity=event.quantity,
        price=event.price,
        pnl=0.0,
        status="OPEN"
    )
    
    # Publish the position event
    event.event_manager.publish(position_event)
    
    # Track event flow
    event_flow['position_events'] += 1
    
    # Add to event trace
    add_to_event_trace("POSITION", position_event)

def on_position_event(event):
    """Handler for position events"""
    if not isinstance(event, PositionEvent):
        return
    
    event_flow['position_events'] += 1
    add_to_event_trace("POSITION", event)
    
    logger.debug(f"PositionEvent: {event.instrument.symbol} - {event.side} - {event.quantity} @ {event.price}")
    
    # Create and publish account event
    account_event = AccountEvent(
        event_type=EventType.ACCOUNT,
        timestamp=int(time.time() * 1000),
        account_id="DEMO-ACCOUNT",
        balance=10000.0,  # Fixed balance for demo
        equity=10000.0 + event.pnl,
        margin=event.price * event.quantity * 0.1,  # 10% margin
        free_margin=10000.0 - (event.price * event.quantity * 0.1),
        margin_level=100.0,
        positions=[event.position_id]
    )
    
    # Publish the account event
    event.event_manager.publish(account_event)
    
    # Track event flow
    event_flow['account_events'] += 1
    
    # Add to event trace
    add_to_event_trace("ACCOUNT", account_event)
    
    # Check if we have a complete event chain
    if (event_flow['market_data_events'] > 0 and
        event_flow['bar_events'] > 0 and
        event_flow['signal_events'] > 0 and
        event_flow['order_events'] > 0 and
        event_flow['execution_events'] > 0 and
        event_flow['fill_events'] > 0 and
        event_flow['position_events'] > 0 and
        event_flow['account_events'] > 0):
        event_flow['complete_chains'] += 1

def on_account_event(event):
    """Handler for account events"""
    if not isinstance(event, AccountEvent):
        return
    
    event_flow['account_events'] += 1
    add_to_event_trace("ACCOUNT", event)
    
    logger.debug(f"AccountEvent: {event.account_id} - Balance: {event.balance} - Equity: {event.equity}")

def save_event_trace():
    """Save the event trace to a file"""
    import json
    with open("event_trace.json", "w") as f:
        json.dump(event_trace, f, indent=2)
    logger.info("Event trace saved to event_trace.json")

def print_performance_report():
    """Print performance metrics"""
    logger.info("\n==================================================")
    logger.info("PERFORMANCE REPORT")
    logger.info("==================================================")
    logger.info(f"Total Trades: {performance_metrics['trades']}")
    logger.info(f"Winning Trades: {performance_metrics['wins']}")
    logger.info(f"Losing Trades: {performance_metrics['losses']}")
    
    win_rate = (performance_metrics['wins'] / performance_metrics['trades'] * 100
                if performance_metrics['trades'] > 0 else 0.0)
    logger.info(f"Win Rate: {win_rate:.2f}%")
    
    logger.info(f"Profit Factor: {performance_metrics['profit_factor']:.2f}")
    logger.info(f"Max Drawdown: {performance_metrics['max_drawdown']:.2f}%")
    logger.info(f"Sharpe Ratio: {performance_metrics['sharpe_ratio']:.2f}")
    logger.info("==================================================")

def print_event_flow_report():
    """Print event flow metrics"""
    logger.info("\n==================================================")
    logger.info("EVENT FLOW REPORT")
    logger.info("==================================================")
    logger.info(f"Market Data Events: {event_flow['market_data_events']}")
    logger.info(f"Bar Events: {event_flow['bar_events']}")
    logger.info(f"Signal Events: {event_flow['signal_events']}")
    logger.info(f"Order Events: {event_flow['order_events']}")
    logger.info(f"Execution Events: {event_flow['execution_events']}")
    logger.info(f"Fill Events: {event_flow['fill_events']}")
    logger.info(f"Position Events: {event_flow['position_events']}")
    logger.info(f"Account Events: {event_flow['account_events']}")
    logger.info(f"Complete Event Chains: {event_flow['complete_chains']}")
    logger.info(f"Broken Event Chains: {event_flow['broken_chains']}")
    logger.info("==================================================")

def main():
    """Main function"""
    parser = argparse.ArgumentParser(description="Tick Replay Demo")
    parser.add_argument("--source", choices=["real", "synthetic", "scripted"], default="synthetic",
                        help="Source of market data (default: synthetic)")
    parser.add_argument("--data-file", type=str, default="data/ticks.csv",
                        help="CSV file containing tick data (for real source)")
    parser.add_argument("--scenario", choices=["random_walk", "trend_up", "trend_down", "volatile", "sideways", "breakout"],
                        default="random_walk", help="Market scenario (for scripted source)")
    parser.add_argument("--duration", type=int, default=300,
                        help="Duration of the demo in seconds (default: 300)")
    parser.add_argument("--symbols", type=str, default="NIFTY,BANKNIFTY",
                        help="Comma-separated list of symbols to trade (default: NIFTY,BANKNIFTY)")
    parser.add_argument("--timeframes", type=str, default="1m,5m",
                        help="Comma-separated list of timeframes to analyze (default: 1m,5m)")
    parser.add_argument("--fast-ma", type=int, default=5,
                        help="Fast moving average period (default: 5)")
    parser.add_argument("--slow-ma", type=int, default=20,
                        help="Slow moving average period (default: 20)")
    parser.add_argument("--rsi-period", type=int, default=14,
                        help="RSI calculation period (default: 14)")
    parser.add_argument("--debug", action="store_true",
                        help="Enable debug logging")
    
    args = parser.parse_args()
    
    # Set log level
    if args.debug:
        logger.setLevel(logging.DEBUG)
        logging.getLogger("core").setLevel(logging.DEBUG)
        logging.getLogger("utils").setLevel(logging.DEBUG)
        logging.getLogger("models").setLevel(logging.DEBUG)
    
    # Parse symbols and timeframes
    symbols = args.symbols.split(",")
    timeframes = args.timeframes.split(",")
    
    # Create instruments
    instruments = []
    for symbol in symbols:
        instrument = Instrument(
            instrument_id=f"NSE:{symbol}",
            symbol=symbol,
            exchange=Exchange.NSE,
            instrument_type=InstrumentType.INDEX,
            asset_class=AssetClass.EQUITY,
            lot_size=1,
            tick_size=0.05,
            expiry=None,
            strike=None,
            option_type=None,
            is_tradable=True
        )
        instruments.append(instrument)
    
    # Create event manager
    event_manager = EventManager()
    
    # Create mock broker
    mock_broker = MockBroker()
    mock_broker.set_event_manager(event_manager)
    
    # Create minimal config for DataManager
    config = {
        "data_manager": {
            "cache_dir": "./data/cache",
            "bar_aggregation": {
                "enabled": True,
                "timeframes": timeframes
            }
        }
    }
    
    # Create data manager with mock broker
    data_manager = DataManager(config, event_manager, mock_broker)
    
    # CRITICAL FIX: Create TimeframeManager instance with proper config
    timeframe_manager = TimeframeManager(
        max_bars_in_memory=10000,
        enable_market_session_validation=True,
        enable_data_validation=True,
        enable_performance_monitoring=True,
        default_exchange="NSE"
    )
    
    # Register event handlers
    event_manager.subscribe(EventType.MARKET_DATA, on_market_data_event)
    event_manager.subscribe(EventType.BAR, on_bar_event)
    event_manager.subscribe(EventType.SIGNAL, on_signal_event)
    event_manager.subscribe(EventType.ORDER, on_order_event)
    event_manager.subscribe(EventType.EXECUTION, on_execution_event)
    event_manager.subscribe(EventType.FILL, on_fill_event)
    event_manager.subscribe(EventType.POSITION, on_position_event)
    event_manager.subscribe(EventType.ACCOUNT, on_account_event)
    
    # CRITICAL FIX: Register TimeframeManager for market data events
    event_manager.subscribe(EventType.MARKET_DATA, data_manager._on_market_data)
    
    # Create tick source based on source type
    if args.source == "real":
        tick_source = RealTickSource(event_manager, args.data_file, replay_speed=10.0, loop=True)
    elif args.source == "synthetic":
        tick_source = SyntheticTickSource(
            event_manager,
            tick_interval=0.05,
            volatility=0.001,
            trend=0.0,
            volume_mean=100.0,
            volume_std=50.0,
            price_jump_prob=0.01,
            price_jump_factor=0.01
        )
    else:  # scripted
        tick_source = ScriptedTickSource(
            event_manager,
            scenario=args.scenario,
            tick_interval=0.05,
            duration=args.duration,
            volatility=0.001,
            trend=0.0,
            volume_mean=100.0,
            volume_std=50.0,
            price_jump_prob=0.01,
            price_jump_factor=0.01
        )
    
    # Subscribe to instruments
    for instrument in instruments:
        tick_source.subscribe(instrument)
        
        # CRITICAL FIX: Log subscription for each instrument
        logger.info(f"Subscribed to market data for {instrument.symbol}")
    
    # Create strategy
    strategy = EnhancedDemoStrategy(
        strategy_id="DEMO-STRATEGY",
        instruments=instruments,
        timeframes=timeframes,
        event_manager=event_manager,
        data_manager=data_manager,
        fast_ma=args.fast_ma,
        slow_ma=args.slow_ma,
        rsi_period=args.rsi_period
    )
    
    # Start event manager
    event_manager.start()
    
    # Start tick source
    tick_source.start()
    
    try:
        # Run for specified duration
        logger.info(f"Running demo for {args.duration} seconds...")
        time.sleep(args.duration)
    except KeyboardInterrupt:
        logger.info("Demo interrupted by user")
    finally:
        # Stop tick source
        tick_source.stop()
        
        # Stop event manager
        event_manager.stop()
        
        # Print performance report
        print_performance_report()
        
        # Print event flow report
        print_event_flow_report()
        
        # Save event trace
        save_event_trace()
        
        logger.info("Demo completed successfully")

if __name__ == "__main__":
    main()
