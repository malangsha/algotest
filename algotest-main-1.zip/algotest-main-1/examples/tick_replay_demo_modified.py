#!/usr/bin/env python
"""
Tick Replay Demo

This script demonstrates the tick replay mechanism for testing strategies with synthetic or historical market data.
It shows how to use different tick sources (real, synthetic, scripted) and validates the full event lifecycle.
"""

import argparse
import logging
import sys
import time
import json
import os
from datetime import datetime, timedelta
import threading
from typing import Dict, List, Any, Optional

# Add the project root to sys.path to fix import issues
import os
import sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Import core components
from core.event_manager import EventManager
from core.data_manager import DataManager
from utils.timeframe_manager import TimeframeManager
from utils.tick_source import TickSource, RealTickSource, SyntheticTickSource, ScriptedTickSource
from models.events import (
    Event, EventType, MarketDataEvent, BarEvent, SignalEvent, 
    OrderEvent, ExecutionEvent, FillEvent, PartialFillEvent, 
    PositionEvent, AccountEvent
)
from models.instrument import Instrument, InstrumentType, AssetClass
from utils.constants import MarketDataType, Exchange, OrderSide, OrderType, OrderStatus, SignalType
from strategies.base_strategy import OptionStrategy  # Changed from BaseStrategy to OptionStrategy

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)

# Create a logger for this module
logger = logging.getLogger("tick_replay_demo")

class EventTracer:
    """
    Utility class to trace and log events for debugging and validation.
    """
    def __init__(self, output_file: str = "event_trace.json"):
        self.events = []
        self.output_file = output_file
        self.lock = threading.Lock()
        
    def trace_event(self, event: Event):
        """Record an event in the trace"""
        with self.lock:
            event_data = event.to_dict()
            event_data["event_class"] = event.__class__.__name__
            self.events.append(event_data)
            
    def save_trace(self):
        """Save the event trace to a file"""
        with self.lock:
            with open(self.output_file, 'w') as f:
                json.dump(self.events, f, indent=2)
            logger.info(f"Event trace saved to {self.output_file}")
            
    def get_event_counts(self) -> Dict[str, int]:
        """Get counts of each event type"""
        counts = {}
        with self.lock:
            for event in self.events:
                event_class = event["event_class"]
                counts[event_class] = counts.get(event_class, 0) + 1
        return counts

class DemoStrategy(OptionStrategy):  # Changed from BaseStrategy to OptionStrategy
    """
    Simple demonstration strategy that logs events and generates signals.
    """
    def __init__(self, strategy_id, config, data_manager, event_manager, event_tracer=None):
        # Create minimal objects to satisfy the parent constructor
        class DummyOptionManager:
            def __init__(self):
                pass
                
        class DummyPortfolioManager:
            def __init__(self):
                pass
                
        # Initialize with required parameters
        super().__init__(
            strategy_id=strategy_id,
            config=config,
            data_manager=data_manager,
            option_manager=DummyOptionManager(),
            portfolio_manager=DummyPortfolioManager(),
            event_manager=event_manager
        )
        
        self.event_tracer = event_tracer
        self.bars = {}  # Store bars by symbol and timeframe
        self.signals = []  # Store generated signals
        
        # Strategy parameters
        self.fast_ma_period = config.get("fast_ma_period", 10)
        self.slow_ma_period = config.get("slow_ma_period", 20)
        self.rsi_period = config.get("rsi_period", 14)
        self.rsi_overbought = config.get("rsi_overbought", 70)
        self.rsi_oversold = config.get("rsi_oversold", 30)
        
        # Initialize indicators
        self.indicators = {}
        
    def on_start(self):
        """Called when the strategy is started"""
        logger.info(f"Strategy {self.id} started")
        
    def on_market_data(self, event: MarketDataEvent):
        """Handle market data events"""
        if self.event_tracer:
            self.event_tracer.trace_event(event)
            
        symbol = event.instrument.symbol
        logger.debug(f"Received market data for {symbol}: {event.data}")
        
    def on_bar(self, event: BarEvent):
        """Handle bar events"""
        if self.event_tracer:
            self.event_tracer.trace_event(event)
            
        symbol = event.instrument.symbol
        timeframe = event.timeframe
        
        # Store the bar
        if symbol not in self.bars:
            self.bars[symbol] = {}
        if timeframe not in self.bars[symbol]:
            self.bars[symbol][timeframe] = []
            
        self.bars[symbol][timeframe].append({
            'timestamp': event.timestamp,
            'open': event.open_price,
            'high': event.high_price,
            'low': event.low_price,
            'close': event.close_price,
            'volume': event.volume
        })
        
        # Keep only the last 100 bars
        if len(self.bars[symbol][timeframe]) > 100:
            self.bars[symbol][timeframe] = self.bars[symbol][timeframe][-100:]
            
        # Calculate indicators
        self._calculate_indicators(symbol, timeframe)
        
        # Generate signals
        self._generate_signals(event)
        
        logger.info(f"Processed bar for {symbol} ({timeframe}): O={event.open_price}, H={event.high_price}, L={event.low_price}, C={event.close_price}, V={event.volume}")
        
    def _calculate_indicators(self, symbol: str, timeframe: str):
        """Calculate technical indicators for the given symbol and timeframe"""
        if len(self.bars[symbol][timeframe]) < self.slow_ma_period:
            return
            
        # Initialize indicators for this symbol/timeframe if not already done
        if symbol not in self.indicators:
            self.indicators[symbol] = {}
        if timeframe not in self.indicators[symbol]:
            self.indicators[symbol][timeframe] = {
                'fast_ma': 0,
                'slow_ma': 0,
                'rsi': 0
            }
            
        # Calculate simple moving averages
        closes = [bar['close'] for bar in self.bars[symbol][timeframe]]
        
        # Fast MA
        fast_ma_data = closes[-self.fast_ma_period:]
        self.indicators[symbol][timeframe]['fast_ma'] = sum(fast_ma_data) / len(fast_ma_data)
        
        # Slow MA
        slow_ma_data = closes[-self.slow_ma_period:]
        self.indicators[symbol][timeframe]['slow_ma'] = sum(slow_ma_data) / len(slow_ma_data)
        
        # Calculate RSI
        if len(closes) >= self.rsi_period + 1:
            changes = [closes[i] - closes[i-1] for i in range(1, len(closes))]
            changes = changes[-(self.rsi_period+1):]  # Get the last rsi_period+1 changes
            
            gains = [change if change > 0 else 0 for change in changes]
            losses = [abs(change) if change < 0 else 0 for change in changes]
            
            avg_gain = sum(gains) / self.rsi_period
            avg_loss = sum(losses) / self.rsi_period
            
            if avg_loss == 0:
                self.indicators[symbol][timeframe]['rsi'] = 100
            else:
                rs = avg_gain / avg_loss
                self.indicators[symbol][timeframe]['rsi'] = 100 - (100 / (1 + rs))
                
        logger.debug(f"Indicators for {symbol} ({timeframe}): Fast MA={self.indicators[symbol][timeframe]['fast_ma']:.2f}, "
                    f"Slow MA={self.indicators[symbol][timeframe]['slow_ma']:.2f}, "
                    f"RSI={self.indicators[symbol][timeframe]['rsi']:.2f}")
                    
    def _generate_signals(self, event: BarEvent):
        """Generate trading signals based on indicators"""
        symbol = event.instrument.symbol
        timeframe = event.timeframe
        
        # Skip if we don't have enough data
        if (symbol not in self.indicators or 
            timeframe not in self.indicators[symbol] or
            len(self.bars[symbol][timeframe]) < self.slow_ma_period):
            return
            
        indicators = self.indicators[symbol][timeframe]
        
        # MA Crossover strategy
        fast_ma = indicators['fast_ma']
        slow_ma = indicators['slow_ma']
        rsi = indicators['rsi']
        
        # Previous values (if available)
        prev_fast_ma = 0
        prev_slow_ma = 0
        if len(self.bars[symbol][timeframe]) > self.slow_ma_period + 1:
            prev_closes = [bar['close'] for bar in self.bars[symbol][timeframe][:-1]]
            prev_fast_ma_data = prev_closes[-self.fast_ma_period:]
            prev_slow_ma_data = prev_closes[-self.slow_ma_period:]
            prev_fast_ma = sum(prev_fast_ma_data) / len(prev_fast_ma_data)
            prev_slow_ma = sum(prev_slow_ma_data) / len(prev_slow_ma_data)
        
        # Generate buy signal on MA crossover and RSI < 30
        if (fast_ma > slow_ma and prev_fast_ma <= prev_slow_ma and rsi < self.rsi_oversold):
            self._create_signal(event, SignalType.ENTRY, OrderSide.BUY)
            
        # Generate sell signal on MA crossover and RSI > 70
        elif (fast_ma < slow_ma and prev_fast_ma >= prev_slow_ma and rsi > self.rsi_overbought):
            self._create_signal(event, SignalType.ENTRY, OrderSide.SELL)
            
    def _create_signal(self, event: BarEvent, signal_type: SignalType, side: OrderSide):
        """Create and emit a signal event"""
        signal = SignalEvent(
            timestamp=int(time.time() * 1000),
            symbol=event.instrument.symbol,
            exchange=event.instrument.exchange,
            signal_type=signal_type,
            signal_price=event.close_price,
            signal_time=event.timestamp,
            strategy_id=self.id,
            side=side,
            quantity=1,  # Default quantity
            timeframe=event.timeframe
        )
        
        # Store the signal
        self.signals.append(signal.to_dict())
        
        # Emit the signal event
        self.event_manager.emit(signal)
        
        if self.event_tracer:
            self.event_tracer.trace_event(signal)
            
        logger.info(f"Generated {side.value} signal for {event.instrument.symbol} at price {event.close_price}")
        
    def on_fill(self, event: FillEvent):
        """Handle fill events"""
        if self.event_tracer:
            self.event_tracer.trace_event(event)
        logger.info(f"Fill received: {event.symbol} {event.side.value} {event.quantity} @ {event.price}")
        
    def on_order(self, event: OrderEvent):
        """Handle order events"""
        if self.event_tracer:
            self.event_tracer.trace_event(event)
        logger.info(f"Order update: {event.symbol} {event.side.value} {event.quantity} @ {event.price} - Status: {event.status.value}")
        
    def on_position(self, event: PositionEvent):
        """Handle position events"""
        if self.event_tracer:
            self.event_tracer.trace_event(event)
        logger.info(f"Position update: {event.symbol} Qty: {event.quantity} Avg Price: {event.avg_price}")
        
    def on_stop(self):
        """Called when the strategy is stopped"""
        logger.info(f"Strategy {self.id} stopped")
        
        # Log summary of signals generated
        logger.info(f"Generated {len(self.signals)} signals during this run")

class MockBroker:
    """
    Mock broker implementation for testing the event lifecycle.
    Simulates order processing and execution.
    """
    def __init__(self, event_manager, event_tracer=None):
        self.event_manager = event_manager
        self.event_tracer = event_tracer
        self.orders = {}
        self.positions = {}
        self.account = {
            'balance': 100000.0,
            'equity': 100000.0,
            'margin': 0.0,
            'free_margin': 100000.0
        }
        
        # Subscribe to signal and order events
        self.event_manager.subscribe(EventType.SIGNAL, self._handle_signal)
        self.event_manager.subscribe(EventType.ORDER, self._handle_order)
        
        logger.info("MockBroker initialized")
        
    def _handle_signal(self, event: Event):
        """Handle signal events by creating orders"""
        if not isinstance(event, SignalEvent):
            return
            
        logger.info(f"MockBroker received signal: {event.symbol} {event.side.value} {event.quantity} @ {event.signal_price}")
        
        # Create an order from the signal
        order_id = f"order_{int(time.time() * 1000)}_{event.symbol}"
        
        order_event = OrderEvent(
            timestamp=int(time.time() * 1000),
            order_id=order_id,
            symbol=event.symbol,
            exchange=event.exchange,
            side=event.side,
            quantity=event.quantity,
            order_type=OrderType.MARKET,
            price=event.signal_price,
            status=OrderStatus.OPEN,
            strategy_id=event.strategy_id
        )
        
        # Store the order
        self.orders[order_id] = order_event.to_dict()
        
        # Emit the order event
        self.event_manager.emit(order_event)
        
        if self.event_tracer:
            self.event_tracer.trace_event(order_event)
            
        # Simulate order execution after a short delay
        threading.Timer(0.5, self._execute_order, args=[order_id]).start()
        
    def _handle_order(self, event: Event):
        """Handle order events (e.g., cancellations)"""
        if not isinstance(event, OrderEvent):
            return
            
        # Update the order in our records
        if event.order_id in self.orders:
            self.orders[event.order_id].update(event.to_dict())
            
    def _execute_order(self, order_id: str):
        """Simulate order execution"""
        if order_id not in self.orders:
            logger.warning(f"Order {order_id} not found for execution")
            return
            
        order = self.orders[order_id]
        
        # Create execution event
        execution_id = f"exec_{order_id}"
        execution_event = ExecutionEvent(
            timestamp=int(time.time() * 1000),
            order_id=order_id,
            execution_id=execution_id,
            symbol=order['symbol'],
            exchange=order['exchange'],
            side=OrderSide(order['side']),
            quantity=order['quantity'],
            price=order['price'],
            status=OrderStatus.FILLED,
            filled_quantity=order['quantity'],
            remaining_quantity=0,
            average_price=order['price'],
            strategy_id=order.get('strategy_id')
        )
        
        # Emit the execution event
        self.event_manager.emit(execution_event)
        
        if self.event_tracer:
            self.event_tracer.trace_event(execution_event)
            
        # Create fill event
        fill_event = FillEvent(
            timestamp=int(time.time() * 1000),
            order_id=order_id,
            fill_id=f"fill_{order_id}",
            symbol=order['symbol'],
            exchange=order['exchange'],
            side=OrderSide(order['side']),
            quantity=order['quantity'],
            price=order['price'],
            commission=0.0,
            strategy_id=order.get('strategy_id'),
            execution_id=execution_id
        )
        
        # Emit the fill event
        self.event_manager.emit(fill_event)
        
        if self.event_tracer:
            self.event_tracer.trace_event(fill_event)
            
        # Update position
        self._update_position(fill_event)
        
        # Update account
        self._update_account()
        
    def _update_position(self, fill_event: FillEvent):
        """Update position based on fill event"""
        symbol = fill_event.symbol
        
        # Initialize position if it doesn't exist
        if symbol not in self.positions:
            self.positions[symbol] = {
                'quantity': 0,
                'avg_price': 0,
                'realized_pnl': 0,
                'unrealized_pnl': 0
            }
            
        position = self.positions[symbol]
        
        # Calculate new position
        old_quantity = position['quantity']
        fill_quantity = fill_event.quantity
        
        # Adjust quantity based on side
        if fill_event.side == OrderSide.BUY:
            new_quantity = old_quantity + fill_quantity
        else:  # SELL
            new_quantity = old_quantity - fill_quantity
            
        # Calculate average price
        if new_quantity != 0:
            if old_quantity == 0:
                # New position
                avg_price = fill_event.price
            else:
                # Update existing position
                if (old_quantity > 0 and new_quantity > 0) or (old_quantity < 0 and new_quantity < 0):
                    # Adding to position
                    avg_price = ((abs(old_quantity) * position['avg_price']) + 
                                (fill_quantity * fill_event.price)) / abs(new_quantity)
                else:
                    # Reducing position or flipping sides
                    if abs(new_quantity) < abs(old_quantity):
                        # Partial close
                        avg_price = position['avg_price']
                    else:
                        # Flipping sides
                        avg_price = fill_event.price
        else:
            # Position closed
            avg_price = 0
            
        # Update position
        position['quantity'] = new_quantity
        position['avg_price'] = avg_price
        
        # Create position event
        position_event = PositionEvent(
            timestamp=int(time.time() * 1000),
            symbol=symbol,
            exchange=fill_event.exchange,
            quantity=new_quantity,
            avg_price=avg_price,
            unrealized_pnl=0.0,  # Would calculate based on current market price
            realized_pnl=0.0,    # Would calculate based on trade history
            strategy_id=fill_event.strategy_id
        )
        
        # Emit the position event
        self.event_manager.emit(position_event)
        
        if self.event_tracer:
            self.event_tracer.trace_event(position_event)
            
    def _update_account(self):
        """Update account information"""
        # In a real implementation, this would calculate equity, margin, etc.
        # For this demo, we'll just create a simple account event
        
        account_event = AccountEvent(
            timestamp=int(time.time() * 1000),
            balance=self.account['balance'],
            equity=self.account['equity'],
            margin=self.account['margin'],
            free_margin=self.account['free_margin'],
            margin_level=100.0,  # Placeholder
            account_id="demo_account"
        )
        
        # Emit the account event
        self.event_manager.emit(account_event)
        
        if self.event_tracer:
            self.event_tracer.trace_event(account_event)

def create_instruments(symbols: List[str]) -> Dict[str, Instrument]:
    """Create instrument objects for the given symbols"""
    instruments = {}
    for symbol in symbols:
        instrument = Instrument(
            instrument_id=f"{Exchange.NSE}:{symbol}",
            symbol=symbol,
            exchange=Exchange.NSE,
            instrument_type=InstrumentType.EQUITY,  # Changed from STOCK to EQUITY
            asset_class=AssetClass.EQUITY
        )
        instruments[symbol] = instrument
    return instruments

def run_demo(args):
    """Run the tick replay demo"""
    # Create event tracer
    event_tracer = EventTracer()
    
    # Create core components
    event_manager = EventManager()
    
    # Create mock broker
    broker = MockBroker(event_manager, event_tracer)
    
    # Create minimal config for DataManager
    data_manager_config = {
        'market_data': {
            'persistence': {
                'enabled': False,  # Disable persistence for demo
                'path': './data',
                'interval': 60
            },
            'use_cache': True,
            'cache_limit': 10000,
            'timeframe_manager_cache_limit': 10000,
            'use_redis': False,
            'thread_pool_size': 2,
            'processing_queue_size': 10000,
            'batch_processing': True,
            'batch_size': 200,
            'calculate_greeks': False  # Disable for demo
        }
    }
    
    # Create data manager with required arguments
    data_manager = DataManager(data_manager_config, event_manager, broker)
    
    # Create timeframe manager with correct arguments
    # First argument should be max_bars_in_memory (int)
    timeframe_manager = TimeframeManager(10000)
    
    # Set the timeframe_manager in data_manager
    # This ensures DataManager uses our TimeframeManager instance
    data_manager.timeframe_manager = timeframe_manager
    
    # Create instruments
    symbols = args.symbols.split(',') if args.symbols else ["RELIANCE", "INFY", "TCS"]
    instruments = create_instruments(symbols)
    
    # Create tick source
    if args.source == 'real':
        tick_source = RealTickSource(
            event_manager=event_manager,
            data_file=args.csv_file
        )
    elif args.source == 'scripted':
        tick_source = ScriptedTickSource(
            event_manager=event_manager,
            scenario=args.scenario
        )
    else:  # synthetic
        tick_source = SyntheticTickSource(
            event_manager=event_manager,
            volatility=args.volatility
        )
    
    # Subscribe to instruments in tick source
    for instrument in instruments.values():
        tick_source.subscribe(instrument)
    
    # Create strategy
    strategy_config = {
        'name': 'DemoStrategy',
        'description': 'Simple demonstration strategy',
        'timeframe': args.timeframes.split(',')[0] if args.timeframes else '1m',
        'additional_timeframes': args.timeframes.split(',')[1:] if args.timeframes else [],
        'fast_ma_period': args.fast_ma,
        'slow_ma_period': args.slow_ma,
        'rsi_period': args.rsi_period
    }
    
    strategy_id = "demo_strategy"
    strategy = DemoStrategy(
        strategy_id=strategy_id,
        config=strategy_config,
        data_manager=data_manager,
        event_manager=event_manager,
        event_tracer=event_tracer
    )
    
    # Register strategy's event handlers
    strategy._register_event_handlers()
    
    # Subscribe to timeframes in data_manager
    timeframes = args.timeframes.split(',') if args.timeframes else ['1m', '5m', '15m']
    for symbol in symbols:
        for timeframe in timeframes:
            # Use data_manager to subscribe to timeframes
            # This ensures proper event flow through data_manager
            data_manager.subscribe_to_timeframe(instruments[symbol], timeframe, strategy_id)
    
    # Start components
    logger.info("Starting components...")
    strategy.start()
    
    # Start tick source
    logger.info(f"Starting {args.source} tick source...")
    tick_source.start()
    
    try:
        # Run for specified duration
        logger.info(f"Running demo for {args.duration} seconds...")
        time.sleep(args.duration)
    except KeyboardInterrupt:
        logger.info("Demo interrupted by user")
    finally:
        # Stop components
        logger.info("Stopping components...")
        tick_source.stop()
        strategy.stop()
        
        # Save event trace
        event_tracer.save_trace()
        
        # Print event counts
        event_counts = event_tracer.get_event_counts()
        logger.info("Event counts:")
        for event_type, count in event_counts.items():
            logger.info(f"  {event_type}: {count}")

def parse_args():
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(description='Tick Replay Demo')
    
    parser.add_argument('--source', choices=['real', 'synthetic', 'scripted'], default='synthetic',
                        help='Tick source type (default: synthetic)')
    parser.add_argument('--csv-file', type=str, help='CSV file for real tick source')
    parser.add_argument('--scenario', choices=['trend_up', 'trend_down', 'breakout', 'range', 'volatile'],
                        default='trend_up', help='Scenario for scripted tick source (default: trend_up)')
    parser.add_argument('--symbols', type=str, default='RELIANCE,INFY,TCS',
                        help='Comma-separated list of symbols (default: RELIANCE,INFY,TCS)')
    parser.add_argument('--timeframes', type=str, default='1m,5m,15m',
                        help='Comma-separated list of timeframes (default: 1m,5m,15m)')
    parser.add_argument('--duration', type=int, default=60,
                        help='Duration to run in seconds (default: 60)')
    parser.add_argument('--volatility', type=float, default=0.002,
                        help='Volatility for synthetic tick source (default: 0.002)')
    parser.add_argument('--fast-ma', type=int, default=10,
                        help='Fast moving average period (default: 10)')
    parser.add_argument('--slow-ma', type=int, default=20,
                        help='Slow moving average period (default: 20)')
    parser.add_argument('--rsi-period', type=int, default=14,
                        help='RSI period (default: 14)')
    parser.add_argument('--debug', action='store_true',
                        help='Enable debug logging')
    
    return parser.parse_args()

if __name__ == '__main__':
    args = parse_args()
    
    # Set log level
    if args.debug:
        logging.getLogger().setLevel(logging.DEBUG)
        
    run_demo(args)
