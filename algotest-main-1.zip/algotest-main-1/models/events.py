from dataclasses import dataclass, field, asdict
from typing import Dict, Any, Optional, Union, List, Callable
from datetime import datetime
import json
import uuid
import logging
import time
from enum import Enum

from utils.constants import Exchange, OrderType, OrderSide, OrderStatus, SignalType, EventType, MarketDataType, EventPriority, TimeframeEventType
from models.instrument import Instrument

logger = logging.getLogger("models.events")

class EventValidationError(Exception):
    """Exception raised when event validation fails"""
    pass

def validate_event(event, required_fields: List[str]):
    """
    Validate that an event has all required fields.

    Args:
        event: The event to validate
        required_fields: List of required field names

    Raises:
        EventValidationError: If any required field is missing
    """
    missing_fields = []
    for field in required_fields:
        if not hasattr(event, field) or getattr(event, field) is None:
            missing_fields.append(field)

    if missing_fields:
        error_msg = f"Missing required fields in {event.__class__.__name__}: {', '.join(missing_fields)}"
        logger.error(error_msg)
        raise EventValidationError(error_msg)

    return True

@dataclass
class Event:
    """Base class for all events in the system."""

    event_type: EventType
    timestamp: int
    event_id: str = None
    priority: EventPriority = EventPriority.NORMAL

    def __post_init__(self):
        if self.event_id is None:
            self.event_id = str(uuid.uuid4())
        if self.timestamp is None:
            self.timestamp = int(datetime.now().timestamp() * 1000)

    def to_dict(self) -> Dict[str, Any]:
        """Convert event to dictionary."""
        return {
            "event_id": self.event_id,
            "event_type": self.event_type.value,
            "timestamp": self.timestamp,
            "priority": self.priority.value
        }

    def to_json(self) -> str:
        """Convert event to JSON string."""
        return json.dumps(self.to_dict())

    def validate(self) -> bool:
        """
        Validate that the event has all required fields.

        Returns:
            bool: True if valid, raises exception otherwise
        """
        required_fields = ["event_type", "timestamp", "event_id"]
        return validate_event(self, required_fields)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Event':
        """Create event from dictionary."""
        return cls(
            event_type=EventType(data["event_type"]) if isinstance(data["event_type"], str) else data["event_type"],
            timestamp=data["timestamp"],
            event_id=data.get("event_id"),
            priority=EventPriority(data["priority"]) if "priority" in data else EventPriority.NORMAL
        )

    def __lt__(self, other):
        """Compare events based on priority and timestamp"""
        if self.priority != other.priority:
            return self.priority.value < other.priority.value
        return self.timestamp < other.timestamp

@dataclass
class MarketDataEvent(Event):
    """Event for market data updates."""
    # Required arguments must come first
    instrument: Instrument = None
    exchange: str = Exchange.NSE
    data_type: MarketDataType = MarketDataType.QUOTE
    data: Dict[str, Any] = None

    def __post_init__(self):
        super().__post_init__()
        if self.event_type is None:
            self.event_type = EventType.MARKET_DATA
        if self.data is None:
            self.data = {}

    def to_dict(self) -> Dict[str, Any]:
        """Convert market data event to dictionary."""
        result = super().to_dict()
        result.update({
            "instrument_id": self.instrument.instrument_id if self.instrument else None,
            "symbol": self.instrument.symbol if self.instrument else None,  # Include symbol in serialized form for convenience
            "exchange": self.exchange,
            "data_type": self.data_type.value,
            "data": self.data
        })
        return result

    def validate(self) -> bool:
        """
        Validate that the market data event has all required fields.

        Returns:
            bool: True if valid, raises exception otherwise
        """
        super().validate()
        required_fields = ["instrument", "data_type", "data"]
        return validate_event(self, required_fields)

    @classmethod
    def from_dict(cls, data: Dict[str, Any], instrument_registry=None) -> 'MarketDataEvent':
        """
        Create market data event from dictionary.

        Args:
            data: Dictionary containing event data
            instrument_registry: Optional registry to look up instrument
        """
        instrument_id = data.get("instrument_id")
        symbol = data.get("symbol")

        # Attempt to get instrument from registry
        instrument = None
        if instrument_registry:
            if instrument_id:
                instrument = instrument_registry.get_by_id(instrument_id)
            elif symbol:
                instrument = instrument_registry.get_by_symbol(symbol)

        if not instrument:
            # Create a basic instrument if we can't find one
            instrument = Instrument(
                instrument_id=instrument_id,
                symbol=symbol,
                exchange=data.get("exchange")
            )

        return cls(
            event_type=EventType(data["event_type"]),
            timestamp=data["timestamp"],
            event_id=data.get("event_id"),
            instrument=instrument,
            exchange=data["exchange"],
            data_type=MarketDataType(data["data_type"]),
            data=data["data"]
        )

    @property
    def symbol(self) -> str:
        """Get the symbol from the instrument for backward compatibility."""
        return self.instrument.symbol if self.instrument else None

@dataclass
class BarEvent(Event):
    """Event for timeframe-specific OHLCV bar updates."""

    instrument: Instrument = None
    timeframe: str = '1m'  # Default timeframe is 1 minute
    open_price: float = 0.0
    high_price: float = 0.0
    low_price: float = 0.0
    close_price: float = 0.0
    volume: float = 0.0
    bar_start_time: Optional[int] = None  # Start time of the bar in milliseconds

    def __post_init__(self):
        super().__post_init__()
        if self.event_type is None:
            self.event_type = EventType.BAR
        # If bar_start_time is not set, calculate it from the timestamp
        if self.bar_start_time is None:
            self.bar_start_time = self.timestamp

    def to_dict(self) -> Dict[str, Any]:
        """Convert bar event to dictionary."""
        result = super().to_dict()
        result.update({
            "instrument_id": self.instrument.instrument_id if self.instrument else None,
            "symbol": self.instrument.symbol if self.instrument else None,
            "exchange": self.instrument.exchange if self.instrument else None,
            "timeframe": self.timeframe,
            "open_price": self.open_price,
            "high_price": self.high_price,
            "low_price": self.low_price,
            "close_price": self.close_price,
            "volume": self.volume,
            "bar_start_time": self.bar_start_time
        })
        return result

    def validate(self) -> bool:
        """
        Validate that the bar event has all required fields.

        Returns:
            bool: True if valid, raises exception otherwise
        """
        super().validate()
        required_fields = ["instrument", "timeframe", "open_price", "high_price", "low_price", "close_price"]
        return validate_event(self, required_fields)

    @classmethod
    def from_dict(cls, data: Dict[str, Any], instrument_registry=None) -> 'BarEvent':
        """
        Create bar event from dictionary.

        Args:
            data: Dictionary containing event data
            instrument_registry: Optional registry to look up instrument
        """
        instrument_id = data.get("instrument_id")
        symbol = data.get("symbol")
        exchange = data.get("exchange")

        # Attempt to get instrument from registry
        instrument = None
        if instrument_registry:
            if instrument_id:
                instrument = instrument_registry.get_by_id(instrument_id)
            elif symbol:
                instrument = instrument_registry.get_by_symbol(symbol, exchange)

        if not instrument:
            # Create a basic instrument if we can't find one
            instrument = Instrument(
                instrument_id=instrument_id,
                symbol=symbol,
                exchange=exchange
            )

        return cls(
            event_type=EventType(data["event_type"]),
            timestamp=data["timestamp"],
            event_id=data.get("event_id"),
            instrument=instrument,
            timeframe=data["timeframe"],
            open_price=data["open_price"],
            high_price=data["high_price"],
            low_price=data["low_price"],
            close_price=data["close_price"],
            volume=data.get("volume", 0.0),
            bar_start_time=data.get("bar_start_time")
        )

    @property
    def symbol(self) -> str:
        """Get the symbol from the instrument for backward compatibility."""
        return self.instrument.symbol if self.instrument else None

@dataclass
class OrderEvent(Event):
    """Event for order updates."""

    order_id: str = None
    symbol: str = None
    exchange: str = Exchange.NSE
    side: OrderSide = OrderSide.BUY
    quantity: float = 0
    order_type: OrderType = OrderType.LIMIT
    status: OrderStatus = OrderStatus.OPEN
    price: Optional[float] = None
    trigger_price: Optional[float] = None
    filled_quantity: float = 0.0
    remaining_quantity: Optional[float] = None
    average_price: Optional[float] = None
    order_time: Optional[int] = None
    last_update_time: Optional[int] = None
    strategy_id: Optional[str] = None
    client_order_id: Optional[str] = None
    broker_order_id: Optional[str] = None
    rejection_reason: Optional[str] = None
    # For backward compatibility with systems that use 'action' instead of 'side'
    action: Optional[str] = None
    # Add instrument field for compatibility with newer code
    instrument: Optional[Instrument] = None
    time_in_force: Optional[str] = None

    def __post_init__(self):
        super().__post_init__()
        if self.event_type is None:
            self.event_type = EventType.ORDER
        if self.remaining_quantity is None:
            self.remaining_quantity = self.quantity - self.filled_quantity

        # Standardize between side and action (action is deprecated)
        self._standardize_side_and_action()

        # Ensure order_id is not None
        if self.order_id is None:
            self.order_id = str(uuid.uuid4())

        # Convert order_type if it's a string
        if isinstance(self.order_type, str):
            try:
                self.order_type = OrderType(self.order_type)
            except (ValueError, TypeError):
                pass

        # Convert status if it's a string
        if isinstance(self.status, str):
            try:
                self.status = OrderStatus(self.status)
            except (ValueError, TypeError):
                pass

        # Set order_time if not provided
        if self.order_time is None:
            self.order_time = self.timestamp

        # Set last_update_time if not provided
        if self.last_update_time is None:
            self.last_update_time = self.timestamp

    def _standardize_side_and_action(self):
        """Standardize between side and action for backward compatibility"""
        if self.action is None and self.side is not None:
            # Convert side to string action
            self.action = self.side.value if isinstance(self.side, OrderSide) else self.side
        elif self.side is None and self.action is not None:
            # Convert action to OrderSide enum
            if isinstance(self.action, str):
                try:
                    self.side = OrderSide(self.action)
                except (ValueError, TypeError):
                    self.side = self.action
            else:
                self.side = self.action

        # Ensure side is an OrderSide enum when possible
        if isinstance(self.side, str):
            try:
                self.side = OrderSide(self.side)
            except (ValueError, TypeError):
                pass

    def validate(self) -> bool:
        """
        Validate that the order event has all required fields.

        Returns:
            bool: True if valid, raises exception otherwise
        """
        super().validate()
        required_fields = ["order_id", "symbol", "side", "quantity", "order_type", "status", "exchange"]
        return validate_event(self, required_fields)

    def to_dict(self) -> Dict[str, Any]:
        """Convert order event to dictionary."""
        result = super().to_dict()
        result.update({
            "order_id": self.order_id,
            "symbol": self.symbol,
            "exchange": self.exchange,
            "side": self.side.value if isinstance(self.side, OrderSide) else self.side,
            "action": self.action if self.action else (self.side.value if isinstance(self.side, OrderSide) else self.side),
            "quantity": self.quantity,
            "order_type": self.order_type.value if isinstance(self.order_type, OrderType) else self.order_type,
            "status": self.status.value if isinstance(self.status, OrderStatus) else self.status,
            "price": self.price,
            "trigger_price": self.trigger_price,
            "filled_quantity": self.filled_quantity,
            "remaining_quantity": self.remaining_quantity,
            "average_price": self.average_price,
            "order_time": self.order_time,
            "last_update_time": self.last_update_time,
            "strategy_id": self.strategy_id,
            "client_order_id": self.client_order_id,
            "broker_order_id": self.broker_order_id,
            "rejection_reason": self.rejection_reason,
            "time_in_force": self.time_in_force
        })
        return result

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'OrderEvent':
        """Create order event from dictionary."""
        # Standardize between side and action
        side = data.get("side")
        action = data.get("action")

        if side is None and action is not None:
            side = action

        return cls(
            event_type=EventType(data["event_type"]),
            timestamp=data["timestamp"],
            event_id=data.get("event_id"),
            order_id=data["order_id"],
            symbol=data["symbol"],
            exchange=data["exchange"],
            side=OrderSide(side) if side else None,
            action=action,
            quantity=data["quantity"],
            order_type=OrderType(data["order_type"]) if "order_type" in data else None,
            status=OrderStatus(data["status"]) if "status" in data else None,
            price=data.get("price"),
            trigger_price=data.get("trigger_price"),
            filled_quantity=data.get("filled_quantity", 0.0),
            remaining_quantity=data.get("remaining_quantity"),
            average_price=data.get("average_price"),
            order_time=data.get("order_time"),
            last_update_time=data.get("last_update_time"),
            strategy_id=data.get("strategy_id"),
            client_order_id=data.get("client_order_id"),
            broker_order_id=data.get("broker_order_id"),
            rejection_reason=data.get("rejection_reason"),
            time_in_force=data.get("time_in_force")
        )

@dataclass
class ExecutionEvent(OrderEvent):
    """
    Event representing an execution update for an order.

    ExecutionEvent is an intermediate step between OrderEvent and FillEvent.
    It represents an execution report from the broker or exchange about the
    status of an order, which may be partially filled, filled, rejected, or
    in some other state.
    """
    # Additional fields specific to executions
    execution_id: Optional[str] = None
    execution_time: Optional[int] = None
    last_filled_quantity: Optional[float] = None
    last_filled_price: Optional[float] = None
    average_filled_price: Optional[float] = None
    leaves_quantity: Optional[float] = None  # Quantity remaining to be filled
    cumulative_filled_quantity: Optional[float] = None
    commission: Optional[float] = None
    execution_type: Optional[str] = None  # NEW, PARTIAL, CANCELED, REJECTED, etc.
    text: Optional[str] = None  # Additional execution info or error message

    def __post_init__(self):
        super().__post_init__()
        if self.event_type is None:
            self.event_type = EventType.EXECUTION

        # Default execution_id if not provided
        if self.execution_id is None:
            self.execution_id = str(uuid.uuid4())

        # Default execution_time if not provided
        if self.execution_time is None:
            self.execution_time = self.timestamp

        # Calculate leaves_quantity if not provided
        if self.leaves_quantity is None and self.quantity is not None and self.cumulative_filled_quantity is not None:
            self.leaves_quantity = self.quantity - self.cumulative_filled_quantity

        # Set cumulative_filled_quantity if not provided
        if self.cumulative_filled_quantity is None:
            self.cumulative_filled_quantity = self.filled_quantity

    def validate(self) -> bool:
        """
        Validate that the execution event has all required fields.

        Returns:
            bool: True if valid, raises exception otherwise
        """
        super().validate()
        required_fields = ["order_id", "symbol", "status", "execution_id"]
        return validate_event(self, required_fields)

    def to_dict(self) -> Dict[str, Any]:
        """Convert execution event to dictionary."""
        result = super().to_dict()
        result.update({
            "execution_id": self.execution_id,
            "execution_time": self.execution_time,
            "last_filled_quantity": self.last_filled_quantity,
            "last_filled_price": self.last_filled_price,
            "average_filled_price": self.average_filled_price,
            "leaves_quantity": self.leaves_quantity,
            "cumulative_filled_quantity": self.cumulative_filled_quantity,
            "commission": self.commission,
            "execution_type": self.execution_type,
            "text": self.text
        })
        return result

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ExecutionEvent':
        """Create execution event from dictionary."""
        # Create base OrderEvent
        order_event_data = data.copy()

        # Extract execution-specific fields
        execution_specific = {
            "execution_id": data.get("execution_id"),
            "execution_time": data.get("execution_time"),
            "last_filled_quantity": data.get("last_filled_quantity"),
            "last_filled_price": data.get("last_filled_price"),
            "average_filled_price": data.get("average_filled_price"),
            "leaves_quantity": data.get("leaves_quantity"),
            "cumulative_filled_quantity": data.get("cumulative_filled_quantity"),
            "commission": data.get("commission"),
            "execution_type": data.get("execution_type"),
            "text": data.get("text")
        }

        # Create OrderEvent object first
        order_event = OrderEvent.from_dict(order_event_data)

        # Convert to dict and update with execution fields
        order_dict = asdict(order_event)
        order_dict.update(execution_specific)

        # Set the event type to EXECUTION
        order_dict["event_type"] = EventType.EXECUTION

        # Create ExecutionEvent using the combined dictionary
        return cls(**order_dict)

@dataclass
class FillEvent(Event):
    """Event for order fill updates."""

    order_id: str = None
    symbol: str = None
    exchange: str = None
    side: OrderSide = OrderSide.BUY
    quantity: float = 0.0
    price: float = 0.0
    commission: float = 0.0
    fill_time: Optional[int] = None
    strategy_id: Optional[str] = None
    broker_order_id: Optional[str] = None
    fill_id: Optional[str] = None
    # For backward compatibility
    action: Optional[str] = None
    # Add instrument field for compatibility with newer code
    instrument: Optional[Instrument] = None
    execution_id: Optional[str] = None

    def __post_init__(self):
        super().__post_init__()
        if self.event_type is None:
            self.event_type = EventType.FILL
        if self.fill_id is None:
            self.fill_id = str(uuid.uuid4())
        if self.fill_time is None:
            self.fill_time = self.timestamp

        # Standardize between side and action
        self._standardize_side_and_action()

    def _standardize_side_and_action(self):
        """Standardize between side and action for backward compatibility"""
        if self.action is None and self.side is not None:
            # Convert side to string action
            self.action = self.side.value if isinstance(self.side, OrderSide) else self.side
        elif self.side is None and self.action is not None:
            # Convert action to OrderSide enum
            if isinstance(self.action, str):
                try:
                    self.side = OrderSide(self.action)
                except (ValueError, TypeError):
                    self.side = self.action
            else:
                self.side = self.action

        # Ensure side is an OrderSide enum when possible
        if isinstance(self.side, str):
            try:
                self.side = OrderSide(self.side)
            except (ValueError, TypeError):
                pass

    def validate(self) -> bool:
        """
        Validate that the fill event has all required fields.

        Returns:
            bool: True if valid, raises exception otherwise
        """
        super().validate()
        required_fields = ["order_id", "symbol", "side", "quantity", "price", "fill_id"]
        return validate_event(self, required_fields)

    def to_dict(self) -> Dict[str, Any]:
        """Convert fill event to dictionary."""
        result = super().to_dict()
        result.update({
            "fill_id": self.fill_id,
            "order_id": self.order_id,
            "symbol": self.symbol,
            "exchange": self.exchange,
            "side": self.side.value if isinstance(self.side, OrderSide) else self.side,
            "action": self.action if self.action else (self.side.value if isinstance(self.side, OrderSide) else self.side),
            "quantity": self.quantity,
            "price": self.price,
            "commission": self.commission,
            "fill_time": self.fill_time,
            "strategy_id": self.strategy_id,
            "broker_order_id": self.broker_order_id,
            "execution_id": self.execution_id
        })
        return result

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'FillEvent':
        """Create fill event from dictionary."""
        # Standardize between side and action
        side = data.get("side")
        action = data.get("action")

        if side is None and action is not None:
            side = action

        return cls(
            event_type=EventType(data["event_type"]),
            timestamp=data["timestamp"],
            event_id=data.get("event_id"),
            fill_id=data.get("fill_id"),
            order_id=data["order_id"],
            symbol=data["symbol"],
            exchange=data["exchange"],
            side=OrderSide(side) if side else None,
            action=action,
            quantity=data["quantity"],
            price=data["price"],
            commission=data.get("commission", 0.0),
            fill_time=data.get("fill_time"),
            strategy_id=data.get("strategy_id"),
            broker_order_id=data.get("broker_order_id"),
            execution_id=data.get("execution_id")
        )

@dataclass
class PartialFillEvent(FillEvent):
    """
    Event for partial order fill updates.
    
    This is a specialized version of FillEvent that represents a partial fill
    of an order, where the filled quantity is less than the total order quantity.
    """
    
    total_quantity: float = 0.0  # Total order quantity
    cumulative_quantity: float = 0.0  # Total filled quantity so far
    remaining_quantity: float = 0.0  # Quantity remaining to be filled
    
    def __post_init__(self):
        super().__post_init__()
        if self.event_type is None:
            self.event_type = EventType.PARTIAL_FILL
            
        # Calculate remaining fields if not provided
        if self.total_quantity == 0.0 and self.remaining_quantity > 0.0:
            self.total_quantity = self.quantity + self.remaining_quantity
            
        if self.cumulative_quantity == 0.0:
            self.cumulative_quantity = self.quantity
            
        if self.remaining_quantity == 0.0 and self.total_quantity > 0.0:
            self.remaining_quantity = self.total_quantity - self.cumulative_quantity
    
    def validate(self) -> bool:
        """
        Validate that the partial fill event has all required fields.
        
        Returns:
            bool: True if valid, raises exception otherwise
        """
        super().validate()
        required_fields = ["total_quantity", "cumulative_quantity", "remaining_quantity"]
        return validate_event(self, required_fields)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert partial fill event to dictionary."""
        result = super().to_dict()
        result.update({
            "total_quantity": self.total_quantity,
            "cumulative_quantity": self.cumulative_quantity,
            "remaining_quantity": self.remaining_quantity
        })
        return result
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'PartialFillEvent':
        """Create partial fill event from dictionary."""
        # Create base FillEvent
        fill_event_data = data.copy()
        
        # Extract partial fill specific fields
        partial_fill_specific = {
            "total_quantity": data.get("total_quantity", 0.0),
            "cumulative_quantity": data.get("cumulative_quantity", 0.0),
            "remaining_quantity": data.get("remaining_quantity", 0.0)
        }
        
        # Create FillEvent object first
        fill_event = FillEvent.from_dict(fill_event_data)
        
        # Convert to dict and update with partial fill fields
        fill_dict = asdict(fill_event)
        fill_dict.update(partial_fill_specific)
        
        # Set the event type to PARTIAL_FILL
        fill_dict["event_type"] = EventType.PARTIAL_FILL
        
        # Create PartialFillEvent using the combined dictionary
        return cls(**fill_dict)

@dataclass
class SignalEvent(Event):
    """Event for trading signals generated by strategies."""

    symbol: str = None
    exchange: str = None
    signal_type: SignalType = SignalType.ENTRY
    signal_price: float = 0.0
    signal_time: int = None
    strategy_id: str = None
    side: Optional[OrderSide] = None
    quantity: Optional[float] = None
    order_type: Optional[OrderType] = None
    price: Optional[float] = None
    trigger_price: Optional[float] = None
    expiry: Optional[int] = None
    confidence: Optional[float] = None
    metadata: Optional[Dict[str, Any]] = None
    # Add instrument field for compatibility with newer code
    instrument: Optional[Instrument] = None
    timeframe: Optional[str] = None
    time_in_force: Optional[str] = None

    def __post_init__(self):
        super().__post_init__()
        if self.event_type is None:
            self.event_type = EventType.SIGNAL
        if self.signal_time is None:
            self.signal_time = self.timestamp
        if self.metadata is None:
            self.metadata = {}

    def validate(self) -> bool:
        """
        Validate that the signal event has all required fields.

        Returns:
            bool: True if valid, raises exception otherwise
        """
        super().validate()
        required_fields = ["symbol", "signal_type", "signal_price", "signal_time"]
        return validate_event(self, required_fields)

    def to_dict(self) -> Dict[str, Any]:
        """Convert signal event to dictionary."""
        result = super().to_dict()
        result.update({
            "symbol": self.symbol,
            "exchange": self.exchange,
            "signal_type": self.signal_type.value if isinstance(self.signal_type, SignalType) else self.signal_type,
            "signal_price": self.signal_price,
            "signal_time": self.signal_time,
            "strategy_id": self.strategy_id,
            "side": self.side.value if isinstance(self.side, OrderSide) else self.side,
            "quantity": self.quantity,
            "order_type": self.order_type.value if isinstance(self.order_type, OrderType) else self.order_type,
            "price": self.price,
            "trigger_price": self.trigger_price,
            "expiry": self.expiry,
            "confidence": self.confidence,
            "metadata": self.metadata,
            "timeframe": self.timeframe,
            "time_in_force": self.time_in_force
        })
        return result

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'SignalEvent':
        """Create signal event from dictionary."""
        return cls(
            event_type=EventType(data["event_type"]),
            timestamp=data["timestamp"],
            event_id=data.get("event_id"),
            symbol=data["symbol"],
            exchange=data["exchange"],
            signal_type=SignalType(data["signal_type"]) if "signal_type" in data else None,
            signal_price=data["signal_price"],
            signal_time=data["signal_time"],
            strategy_id=data.get("strategy_id"),
            side=OrderSide(data["side"]) if "side" in data else None,
            quantity=data.get("quantity"),
            order_type=OrderType(data["order_type"]) if "order_type" in data else None,
            price=data.get("price"),
            trigger_price=data.get("trigger_price"),
            expiry=data.get("expiry"),
            confidence=data.get("confidence"),
            metadata=data.get("metadata"),
            timeframe=data.get("timeframe"),
            time_in_force=data.get("time_in_force")
        )

@dataclass
class PositionEvent(Event):
    """Event for position updates."""

    instrument: Instrument = None
    quantity: float = 0.0
    avg_price: float = 0.0
    unrealized_pnl: float = 0.0
    realized_pnl: float = 0.0
    position_value: Optional[float] = None
    margin_used: Optional[float] = None
    last_update_time: Optional[int] = None
    strategy_id: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None
    # For backward compatibility
    symbol: Optional[str] = None
    exchange: Optional[str] = None

    def __post_init__(self):
        super().__post_init__()
        if self.event_type is None:
            self.event_type = EventType.POSITION
        if self.last_update_time is None:
            self.last_update_time = self.timestamp
        if self.metadata is None:
            self.metadata = {}

        # Ensure symbol and exchange are set for backward compatibility
        if self.instrument:
            if self.symbol is None:
                self.symbol = self.instrument.symbol
            if self.exchange is None:
                self.exchange = self.instrument.exchange
        
        # Calculate position_value if not provided
        if self.position_value is None:
            self.position_value = abs(self.quantity) * self.avg_price

    def validate(self) -> bool:
        """
        Validate that the position event has all required fields.

        Returns:
            bool: True if valid, raises exception otherwise
        """
        super().validate()
        
        # Check if either instrument or symbol is provided
        if not self.instrument and not self.symbol:
            raise EventValidationError(f"Missing required fields in {self.__class__.__name__}: instrument or symbol")
            
        required_fields = ["quantity", "avg_price"]
        return validate_event(self, required_fields)

    def to_dict(self) -> Dict[str, Any]:
        """Convert position event to dictionary."""
        result = super().to_dict()
        result.update({
            "instrument_id": self.instrument.instrument_id if self.instrument else None,
            "symbol": self.symbol if self.symbol else (self.instrument.symbol if self.instrument else None),
            "exchange": self.exchange if self.exchange else (self.instrument.exchange if self.instrument else None),
            "quantity": self.quantity,
            "avg_price": self.avg_price,
            "unrealized_pnl": self.unrealized_pnl,
            "realized_pnl": self.realized_pnl,
            "position_value": self.position_value,
            "margin_used": self.margin_used,
            "last_update_time": self.last_update_time,
            "strategy_id": self.strategy_id,
            "metadata": self.metadata
        })
        return result

    @classmethod
    def from_dict(cls, data: Dict[str, Any], instrument_registry=None) -> 'PositionEvent':
        """
        Create position event from dictionary.
        
        Args:
            data: Dictionary containing event data
            instrument_registry: Optional registry to look up instrument
        """
        instrument_id = data.get("instrument_id")
        symbol = data.get("symbol")
        exchange = data.get("exchange")

        # Attempt to get instrument from registry
        instrument = None
        if instrument_registry:
            if instrument_id:
                instrument = instrument_registry.get_by_id(instrument_id)
            elif symbol:
                instrument = instrument_registry.get_by_symbol(symbol, exchange)

        if not instrument and (symbol or exchange):
            # Create a basic instrument if we can't find one
            instrument = Instrument(
                instrument_id=instrument_id,
                symbol=symbol,
                exchange=exchange
            )

        return cls(
            event_type=EventType(data["event_type"]),
            timestamp=data["timestamp"],
            event_id=data.get("event_id"),
            instrument=instrument,
            symbol=data.get("symbol"),
            exchange=data.get("exchange"),
            quantity=data["quantity"],
            avg_price=data["avg_price"],
            unrealized_pnl=data.get("unrealized_pnl", 0.0),
            realized_pnl=data.get("realized_pnl", 0.0),
            position_value=data.get("position_value"),
            margin_used=data.get("margin_used"),
            last_update_time=data.get("last_update_time"),
            strategy_id=data.get("strategy_id"),
            metadata=data.get("metadata")
        )

@dataclass
class AccountEvent(Event):
    """Event for account updates."""

    balance: float = 0.0
    equity: float = 0.0
    margin: float = 0.0
    free_margin: float = 0.0
    margin_level: float = 0.0
    account_id: Optional[str] = None
    currency: Optional[str] = None
    last_update_time: Optional[int] = None
    metadata: Optional[Dict[str, Any]] = None

    def __post_init__(self):
        super().__post_init__()
        if self.event_type is None:
            self.event_type = EventType.ACCOUNT
        if self.last_update_time is None:
            self.last_update_time = self.timestamp
        if self.metadata is None:
            self.metadata = {}

    def validate(self) -> bool:
        """
        Validate that the account event has all required fields.

        Returns:
            bool: True if valid, raises exception otherwise
        """
        super().validate()
        required_fields = ["balance", "equity", "margin", "free_margin"]
        return validate_event(self, required_fields)

    def to_dict(self) -> Dict[str, Any]:
        """Convert account event to dictionary."""
        result = super().to_dict()
        result.update({
            "balance": self.balance,
            "equity": self.equity,
            "margin": self.margin,
            "free_margin": self.free_margin,
            "margin_level": self.margin_level,
            "account_id": self.account_id,
            "currency": self.currency,
            "last_update_time": self.last_update_time,
            "metadata": self.metadata
        })
        return result

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'AccountEvent':
        """Create account event from dictionary."""
        return cls(
            event_type=EventType(data["event_type"]),
            timestamp=data["timestamp"],
            event_id=data.get("event_id"),
            balance=data["balance"],
            equity=data["equity"],
            margin=data["margin"],
            free_margin=data["free_margin"],
            margin_level=data.get("margin_level", 0.0),
            account_id=data.get("account_id"),
            currency=data.get("currency"),
            last_update_time=data.get("last_update_time"),
            metadata=data.get("metadata")
        )

@dataclass
class TimerEvent(Event):
    """Event for timer-based triggers."""
    
    interval: int = 1000  # Interval in milliseconds
    repeat: bool = False  # Whether the timer should repeat
    timer_id: Optional[str] = None
    callback: Optional[Callable] = None
    next_trigger: Optional[int] = None
    metadata: Optional[Dict[str, Any]] = None
    
    def __post_init__(self):
        super().__post_init__()
        if self.event_type is None:
            self.event_type = EventType.TIMER
        if self.timer_id is None:
            self.timer_id = str(uuid.uuid4())
        if self.next_trigger is None:
            self.next_trigger = self.timestamp + self.interval
        if self.metadata is None:
            self.metadata = {}
    
    def validate(self) -> bool:
        """
        Validate that the timer event has all required fields.
        
        Returns:
            bool: True if valid, raises exception otherwise
        """
        super().validate()
        required_fields = ["interval", "timer_id", "next_trigger"]
        return validate_event(self, required_fields)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert timer event to dictionary."""
        result = super().to_dict()
        result.update({
            "interval": self.interval,
            "repeat": self.repeat,
            "timer_id": self.timer_id,
            "next_trigger": self.next_trigger,
            "metadata": self.metadata
        })
        # Cannot serialize callback function
        return result
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'TimerEvent':
        """Create timer event from dictionary."""
        return cls(
            event_type=EventType(data["event_type"]),
            timestamp=data["timestamp"],
            event_id=data.get("event_id"),
            interval=data["interval"],
            repeat=data.get("repeat", False),
            timer_id=data.get("timer_id"),
            next_trigger=data.get("next_trigger"),
            metadata=data.get("metadata")
        )

@dataclass
class SystemEvent(Event):
    """Event for system-level notifications and control."""
    
    system_action: str = None  # e.g., "shutdown", "restart", "pause", "resume"
    message: Optional[str] = None
    severity: Optional[str] = "INFO"  # INFO, WARNING, ERROR, CRITICAL
    source: Optional[str] = None  # Component that generated the event
    metadata: Optional[Dict[str, Any]] = None
    
    def __post_init__(self):
        super().__post_init__()
        if self.event_type is None:
            self.event_type = EventType.SYSTEM
        if self.metadata is None:
            self.metadata = {}
    
    def validate(self) -> bool:
        """
        Validate that the system event has all required fields.
        
        Returns:
            bool: True if valid, raises exception otherwise
        """
        super().validate()
        required_fields = ["system_action"]
        return validate_event(self, required_fields)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert system event to dictionary."""
        result = super().to_dict()
        result.update({
            "system_action": self.system_action,
            "message": self.message,
            "severity": self.severity,
            "source": self.source,
            "metadata": self.metadata
        })
        return result
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'SystemEvent':
        """Create system event from dictionary."""
        return cls(
            event_type=EventType(data["event_type"]),
            timestamp=data["timestamp"],
            event_id=data.get("event_id"),
            system_action=data["system_action"],
            message=data.get("message"),
            severity=data.get("severity", "INFO"),
            source=data.get("source"),
            metadata=data.get("metadata")
        )

@dataclass
class RiskBreachEvent(Event):
    """Event for risk limit breaches."""
    
    risk_type: str = None  # e.g., "position_limit", "drawdown_limit", "margin_call"
    symbol: Optional[str] = None
    exchange: Optional[str] = None
    instrument: Optional[Instrument] = None
    strategy_id: Optional[str] = None
    limit_value: Optional[float] = None
    current_value: Optional[float] = None
    breach_percentage: Optional[float] = None
    message: Optional[str] = None
    severity: Optional[str] = "WARNING"  # WARNING, CRITICAL
    metadata: Optional[Dict[str, Any]] = None
    
    def __post_init__(self):
        super().__post_init__()
        if self.event_type is None:
            self.event_type = EventType.RISK_BREACH
        if self.metadata is None:
            self.metadata = {}
            
        # Ensure symbol and exchange are set for backward compatibility
        if self.instrument:
            if self.symbol is None:
                self.symbol = self.instrument.symbol
            if self.exchange is None:
                self.exchange = self.instrument.exchange
                
        # Calculate breach percentage if not provided
        if self.breach_percentage is None and self.limit_value is not None and self.current_value is not None and self.limit_value != 0:
            self.breach_percentage = (self.current_value / self.limit_value) * 100
    
    def validate(self) -> bool:
        """
        Validate that the risk breach event has all required fields.
        
        Returns:
            bool: True if valid, raises exception otherwise
        """
        super().validate()
        required_fields = ["risk_type"]
        return validate_event(self, required_fields)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert risk breach event to dictionary."""
        result = super().to_dict()
        result.update({
            "risk_type": self.risk_type,
            "symbol": self.symbol if self.symbol else (self.instrument.symbol if self.instrument else None),
            "exchange": self.exchange if self.exchange else (self.instrument.exchange if self.instrument else None),
            "strategy_id": self.strategy_id,
            "limit_value": self.limit_value,
            "current_value": self.current_value,
            "breach_percentage": self.breach_percentage,
            "message": self.message,
            "severity": self.severity,
            "metadata": self.metadata
        })
        return result
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any], instrument_registry=None) -> 'RiskBreachEvent':
        """
        Create risk breach event from dictionary.
        
        Args:
            data: Dictionary containing event data
            instrument_registry: Optional registry to look up instrument
        """
        instrument_id = data.get("instrument_id")
        symbol = data.get("symbol")
        exchange = data.get("exchange")

        # Attempt to get instrument from registry
        instrument = None
        if instrument_registry:
            if instrument_id:
                instrument = instrument_registry.get_by_id(instrument_id)
            elif symbol:
                instrument = instrument_registry.get_by_symbol(symbol, exchange)

        if not instrument and (symbol or exchange):
            # Create a basic instrument if we can't find one
            instrument = Instrument(
                instrument_id=instrument_id,
                symbol=symbol,
                exchange=exchange
            )
            
        return cls(
            event_type=EventType(data["event_type"]),
            timestamp=data["timestamp"],
            event_id=data.get("event_id"),
            risk_type=data["risk_type"],
            symbol=data.get("symbol"),
            exchange=data.get("exchange"),
            instrument=instrument,
            strategy_id=data.get("strategy_id"),
            limit_value=data.get("limit_value"),
            current_value=data.get("current_value"),
            breach_percentage=data.get("breach_percentage"),
            message=data.get("message"),
            severity=data.get("severity", "WARNING"),
            metadata=data.get("metadata")
        )

@dataclass
class TradeEvent(Event):
    """Event for trade updates and trade-related information."""
    
    trade_id: str = None
    symbol: str = None
    exchange: str = None
    instrument: Optional[Instrument] = None
    side: OrderSide = OrderSide.BUY
    quantity: float = 0.0
    price: float = 0.0
    trade_time: Optional[int] = None
    order_id: Optional[str] = None
    strategy_id: Optional[str] = None
    pnl: Optional[float] = None
    commission: Optional[float] = None
    slippage: Optional[float] = None
    metadata: Optional[Dict[str, Any]] = None
    
    def __post_init__(self):
        super().__post_init__()
        if self.event_type is None:
            self.event_type = EventType.TRADE
        if self.trade_id is None:
            self.trade_id = str(uuid.uuid4())
        if self.trade_time is None:
            self.trade_time = self.timestamp
        if self.metadata is None:
            self.metadata = {}
            
        # Ensure symbol and exchange are set for backward compatibility
        if self.instrument:
            if self.symbol is None:
                self.symbol = self.instrument.symbol
            if self.exchange is None:
                self.exchange = self.instrument.exchange
    
    def validate(self) -> bool:
        """
        Validate that the trade event has all required fields.
        
        Returns:
            bool: True if valid, raises exception otherwise
        """
        super().validate()
        
        # Check if either instrument or symbol is provided
        if not self.instrument and not self.symbol:
            raise EventValidationError(f"Missing required fields in {self.__class__.__name__}: instrument or symbol")
            
        required_fields = ["trade_id", "side", "quantity", "price"]
        return validate_event(self, required_fields)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert trade event to dictionary."""
        result = super().to_dict()
        result.update({
            "trade_id": self.trade_id,
            "instrument_id": self.instrument.instrument_id if self.instrument else None,
            "symbol": self.symbol if self.symbol else (self.instrument.symbol if self.instrument else None),
            "exchange": self.exchange if self.exchange else (self.instrument.exchange if self.instrument else None),
            "side": self.side.value if isinstance(self.side, OrderSide) else self.side,
            "quantity": self.quantity,
            "price": self.price,
            "trade_time": self.trade_time,
            "order_id": self.order_id,
            "strategy_id": self.strategy_id,
            "pnl": self.pnl,
            "commission": self.commission,
            "slippage": self.slippage,
            "metadata": self.metadata
        })
        return result
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any], instrument_registry=None) -> 'TradeEvent':
        """
        Create trade event from dictionary.
        
        Args:
            data: Dictionary containing event data
            instrument_registry: Optional registry to look up instrument
        """
        instrument_id = data.get("instrument_id")
        symbol = data.get("symbol")
        exchange = data.get("exchange")

        # Attempt to get instrument from registry
        instrument = None
        if instrument_registry:
            if instrument_id:
                instrument = instrument_registry.get_by_id(instrument_id)
            elif symbol:
                instrument = instrument_registry.get_by_symbol(symbol, exchange)

        if not instrument and (symbol or exchange):
            # Create a basic instrument if we can't find one
            instrument = Instrument(
                instrument_id=instrument_id,
                symbol=symbol,
                exchange=exchange
            )
            
        # Convert side to OrderSide enum if possible
        side = data.get("side")
        if isinstance(side, str):
            try:
                side = OrderSide(side)
            except (ValueError, TypeError):
                pass
            
        return cls(
            event_type=EventType(data["event_type"]),
            timestamp=data["timestamp"],
            event_id=data.get("event_id"),
            trade_id=data["trade_id"],
            symbol=data.get("symbol"),
            exchange=data.get("exchange"),
            instrument=instrument,
            side=side,
            quantity=data["quantity"],
            price=data["price"],
            trade_time=data.get("trade_time"),
            order_id=data.get("order_id"),
            strategy_id=data.get("strategy_id"),
            pnl=data.get("pnl"),
            commission=data.get("commission"),
            slippage=data.get("slippage"),
            metadata=data.get("metadata")
        )
