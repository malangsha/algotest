#!/usr/bin/env python3
"""
Enhanced Parquet Reader with Trading Data Focus

A comprehensive utility to read, analyze, and export Parquet files with special 
attention to timestamp columns and trading data structures.

Usage:
    python enhanced_parquet_reader.py <parquet_file> [options]
    
Options:
    --info              Show detailed file information and column analysis
    --head N            Show first N rows (default: 10)
    --tail N            Show last N rows (default: 5)
    --sample N          Show random N rows
    --describe          Show statistical summary
    --output-csv FILE   Export to CSV file
    --output-excel FILE Export to Excel file
    --date-range        Show date range for timestamp columns
    --trading-summary   Show trading-specific summary (OHLCV analysis)
"""

import sys
import argparse
import pandas as pd
from pathlib import Path
import numpy as np
from datetime import datetime

class TradingParquetAnalyzer:
    """Domain model for analyzing trading data from Parquet files"""
    
    def __init__(self, file_path: str):
        self.file_path = Path(file_path)
        self.df = None
        self.timestamp_columns = []
        self.trading_columns = {}
        
    def load_data(self) -> bool:
        """Load parquet file and identify column types"""
        try:
            self.df = pd.read_parquet(self.file_path)
            self._identify_column_types()
            return True
        except Exception as e:
            print(f"Error reading Parquet file: {e}")
            return False
    
    def _identify_column_types(self):
        """Identify timestamp and trading-related columns"""
        if self.df is None:
            return
        
        # Find timestamp columns
        for col in self.df.columns:
            if pd.api.types.is_datetime64_any_dtype(self.df[col]):
                self.timestamp_columns.append(col)
        
        # Identify common trading columns (case-insensitive)
        column_mapping = {
            'open': ['open', 'o', 'open_price'],
            'high': ['high', 'h', 'high_price'],
            'low': ['low', 'l', 'low_price'],
            'close': ['close', 'c', 'close_price', 'ltp'],
            'volume': ['volume', 'vol', 'quantity', 'qty'],
            'symbol': ['symbol', 'instrument', 'scrip', 'stock'],
            'timestamp': ['timestamp', 'datetime', 'date', 'time']
        }
        
        for category, possible_names in column_mapping.items():
            for col in self.df.columns:
                if col.lower() in possible_names:
                    self.trading_columns[category] = col
                    break
    
    def show_file_info(self):
        """Display comprehensive file and data information"""
        if self.df is None:
            return
        
        print("=" * 60)
        print(f"PARQUET FILE ANALYSIS: {self.file_path.name}")
        print("=" * 60)
        
        # Basic info
        print(f"File Size: {self.file_path.stat().st_size / (1024*1024):.2f} MB")
        print(f"Shape: {self.df.shape[0]:,} rows × {self.df.shape[1]} columns")
        print(f"Memory Usage: {self.df.memory_usage(deep=True).sum() / (1024*1024):.2f} MB")
        
        # Column information
        print("\nCOLUMN INFORMATION:")
        print("-" * 40)
        for i, (col, dtype) in enumerate(zip(self.df.columns, self.df.dtypes), 1):
            null_count = self.df[col].isnull().sum()
            null_pct = (null_count / len(self.df)) * 100
            print(f"{i:2d}. {col:<20} | {str(dtype):<12} | Nulls: {null_count:,} ({null_pct:.1f}%)")
        
        # Timestamp analysis
        if self.timestamp_columns:
            print(f"\nTIMESTAMP COLUMNS FOUND: {len(self.timestamp_columns)}")
            print("-" * 40)
            for col in self.timestamp_columns:
                min_date = self.df[col].min()
                max_date = self.df[col].max()
                print(f"{col}:")
                print(f"  Range: {min_date} to {max_date}")
                print(f"  Duration: {max_date - min_date}")
        
        # Trading columns mapping
        if self.trading_columns:
            print(f"\nTRADING COLUMNS IDENTIFIED:")
            print("-" * 40)
            for category, column in self.trading_columns.items():
                print(f"{category.capitalize():<10}: {column}")
    
    def show_trading_summary(self):
        """Show trading-specific analysis (OHLCV summary)"""
        if self.df is None or not self.trading_columns:
            print("No trading columns identified for summary")
            return
        
        print("\nTRADING DATA SUMMARY:")
        print("=" * 40)
        
        # OHLCV Analysis
        ohlcv_cols = ['open', 'high', 'low', 'close', 'volume']
        available_ohlcv = {k: v for k, v in self.trading_columns.items() if k in ohlcv_cols}
        
        if available_ohlcv:
            print("OHLCV Statistics:")
            for category, col in available_ohlcv.items():
                if col in self.df.columns:
                    series = self.df[col]
                    print(f"\n{category.upper()} ({col}):")
                    print(f"  Min: {series.min():,.2f}")
                    print(f"  Max: {series.max():,.2f}")
                    print(f"  Mean: {series.mean():,.2f}")
                    print(f"  Std: {series.std():,.2f}")
        
        # Symbol analysis if available
        if 'symbol' in self.trading_columns:
            symbol_col = self.trading_columns['symbol']
            unique_symbols = self.df[symbol_col].nunique()
            print(f"\nSYMBOLS:")
            print(f"  Unique symbols: {unique_symbols}")
            if unique_symbols <= 20:
                print(f"  Symbols: {', '.join(self.df[symbol_col].unique())}")
    
    def show_date_range(self):
        """Show date range analysis for all timestamp columns"""
        if not self.timestamp_columns:
            print("No timestamp columns found")
            return
        
        print("\nDATE RANGE ANALYSIS:")
        print("=" * 40)
        for col in self.timestamp_columns:
            dates = self.df[col].dropna()
            if len(dates) > 0:
                print(f"\n{col}:")
                print(f"  First record: {dates.min()}")
                print(f"  Last record:  {dates.max()}")
                print(f"  Total span:   {dates.max() - dates.min()}")
                print(f"  Record count: {len(dates):,}")
                
                # Check for intraday patterns
                if len(dates) > 1:
                    time_diffs = dates.diff().dropna()
                    most_common_interval = time_diffs.mode()
                    if len(most_common_interval) > 0:
                        print(f"  Most common interval: {most_common_interval.iloc[0]}")
    
    def export_data(self, output_path: str, format_type: str = 'csv'):
        """Export data to specified format"""
        if self.df is None:
            return False
        
        try:
            output_file = Path(output_path)
            
            if format_type.lower() == 'csv':
                # Handle timestamp columns for CSV export
                df_export = self.df.copy()
                for col in self.timestamp_columns:
                    if col in df_export.columns:
                        df_export[col] = df_export[col].dt.strftime('%Y-%m-%d %H:%M:%S')
                df_export.to_csv(output_file, index=True)
                
            elif format_type.lower() == 'excel':
                with pd.ExcelWriter(output_file, engine='openpyxl') as writer:
                    self.df.to_excel(writer, sheet_name='Data', index=True)
                    
                    # Add summary sheet if trading data
                    if self.trading_columns:
                        summary_data = []
                        for category, col in self.trading_columns.items():
                            if col in self.df.columns and pd.api.types.is_numeric_dtype(self.df[col]):
                                summary_data.append({
                                    'Column': col,
                                    'Category': category,
                                    'Min': self.df[col].min(),
                                    'Max': self.df[col].max(),
                                    'Mean': self.df[col].mean(),
                                    'Count': self.df[col].count()
                                })
                        
                        if summary_data:
                            summary_df = pd.DataFrame(summary_data)
                            summary_df.to_excel(writer, sheet_name='Summary', index=True)
            
            print(f"Data exported to: {output_file}")
            return True
            
        except Exception as e:
            print(f"Error exporting data: {e}")
            return False

def main():
    parser = argparse.ArgumentParser(
        description='Enhanced Parquet Reader for Trading Data Analysis',
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    parser.add_argument('file', help='Path to Parquet file')
    parser.add_argument('--info', action='store_true', help='Show detailed file information')
    parser.add_argument('--head', type=int, default=10, help='Show first N rows')
    parser.add_argument('--tail', type=int, default=5, help='Show last N rows')
    parser.add_argument('--sample', type=int, help='Show random N rows')
    parser.add_argument('--describe', action='store_true', help='Show statistical summary')
    parser.add_argument('--output-csv', help='Export to CSV file')
    parser.add_argument('--output-excel', help='Export to Excel file')
    parser.add_argument('--date-range', action='store_true', help='Show date range analysis')
    parser.add_argument('--trading-summary', action='store_true', help='Show trading-specific summary')
    
    args = parser.parse_args()
    
    # Initialize analyzer
    analyzer = TradingParquetAnalyzer(args.file)
    
    if not analyzer.load_data():
        sys.exit(1)
    
    # Show basic info if requested or no specific options
    if args.info or not any([args.head, args.tail, args.sample, args.describe, 
                           args.date_range, args.trading_summary]):
        analyzer.show_file_info()
    
    # Show head rows
    if args.head > 0:
        print(f"\nFIRST {args.head} ROWS:")
        print("-" * 40)
        print(analyzer.df.head(args.head).to_string(index=True))
    
    # Show tail rows
    if args.tail > 0:
        print(f"\nLAST {args.tail} ROWS:")
        print("-" * 40)
        print(analyzer.df.tail(args.tail).to_string(index=True))
    
    # Show random sample
    if args.sample:
        print(f"\nRANDOM {args.sample} ROWS:")
        print("-" * 40)
        print(analyzer.df.sample(min(args.sample, len(analyzer.df))).to_string(index=True))
    
    # Show statistical summary
    if args.describe:
        print("\nSTATISTICAL SUMMARY:")
        print("-" * 40)
        print(analyzer.df.describe())
    
    # Show date range analysis
    if args.date_range:
        analyzer.show_date_range()
    
    # Show trading summary
    if args.trading_summary:
        analyzer.show_trading_summary()
    
    # Export data if requested
    if args.output_csv:
        analyzer.export_data(args.output_csv, 'csv')
    
    if args.output_excel:
        analyzer.export_data(args.output_excel, 'excel')

if __name__ == "__main__":
    main()
