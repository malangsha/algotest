"""
Technical indicators module for the Option Trading Framework.

This module provides vectorized implementations of common technical indicators
using NumPy and Pandas for optimal performance. All indicators are implemented
with consistent interfaces and comprehensive documentation.
"""

import numpy as np
import pandas as pd
from typing import Union, Optional, Tuple, List, Dict, Any
from enum import Enum


class MAType(Enum):
    """Moving Average type enumeration."""
    SIMPLE = "simple"
    EXPONENTIAL = "exponential"
    WEIGHTED = "weighted"
    HULL = "hull"


def moving_average(data: Union[pd.Series, np.ndarray], 
                   period: int, 
                   ma_type: Union[MAType, str] = MAType.SIMPLE) -> np.ndarray:
    """
    Calculate various types of moving averages.
    
    Args:
        data: Price data as pandas Series or numpy array
        period: Period for the moving average calculation
        ma_type: Type of moving average (simple, exponential, weighted, hull)
    
    Returns:
        numpy array containing the moving average values
    """
    if isinstance(data, pd.Series):
        data = data.values
    
    if isinstance(ma_type, str):
        ma_type = MAType(ma_type)
    
    if len(data) < period:
        return np.full_like(data, np.nan)
    
    if ma_type == MAType.SIMPLE:
        # Simple Moving Average
        weights = np.ones(period)
        sma = np.convolve(data, weights / weights.sum(), mode='valid')
        return np.concatenate([np.full(period-1, np.nan), sma])
    
    elif ma_type == MAType.EXPONENTIAL:
        # Exponential Moving Average
        alpha = 2 / (period + 1)
        ema = np.zeros_like(data)
        ema[:period] = np.nan
        ema[period-1] = np.mean(data[:period])
        
        for i in range(period, len(data)):
            ema[i] = alpha * data[i] + (1 - alpha) * ema[i-1]
        
        return ema
    
    elif ma_type == MAType.WEIGHTED:
        # Weighted Moving Average
        weights = np.arange(1, period + 1)
        wma = np.zeros_like(data)
        wma[:period-1] = np.nan
        
        for i in range(period-1, len(data)):
            wma[i] = np.sum(data[i-period+1:i+1] * weights) / np.sum(weights)
        
        return wma
    
    elif ma_type == MAType.HULL:
        # Hull Moving Average
        half_period = period // 2
        sqrt_period = int(np.sqrt(period))
        
        # Calculate WMA with period/2
        wma_half = moving_average(data, half_period, MAType.WEIGHTED)
        
        # Calculate WMA with period
        wma_full = moving_average(data, period, MAType.WEIGHTED)
        
        # Calculate 2*WMA(period/2) - WMA(period)
        hull_data = 2 * wma_half - wma_full
        
        # Calculate WMA with sqrt(period) on the result
        hull = moving_average(hull_data, sqrt_period, MAType.WEIGHTED)
        
        return hull
    
    else:
        raise ValueError(f"Unsupported moving average type: {ma_type}")


def rsi(data: Union[pd.Series, np.ndarray], period: int = 14) -> np.ndarray:
    """
    Calculate the Relative Strength Index (RSI).
    
    Formula: RSI = 100 - (100 / (1 + RS))
    where RS = Average Gain / Average Loss
    
    Args:
        data: Price data as pandas Series or numpy array
        period: RSI calculation period
    
    Returns:
        numpy array containing the RSI values
    """
    if isinstance(data, pd.Series):
        data = data.values
    
    if len(data) <= period:
        return np.full_like(data, np.nan)
    
    # Calculate price changes
    deltas = np.diff(data)
    deltas = np.append(0, deltas)  # Add 0 at the beginning to maintain array size
    
    # Separate gains and losses
    gains = np.where(deltas > 0, deltas, 0)
    losses = np.where(deltas < 0, -deltas, 0)
    
    # Initialize result array
    rsi_values = np.zeros_like(data)
    rsi_values[:period] = np.nan
    
    # First average gain and loss
    avg_gain = np.sum(gains[:period]) / period
    avg_loss = np.sum(losses[:period]) / period
    
    # Calculate RSI using Wilder's smoothing method
    for i in range(period, len(data)):
        avg_gain = ((period - 1) * avg_gain + gains[i]) / period
        avg_loss = ((period - 1) * avg_loss + losses[i]) / period
        
        if avg_loss == 0:
            rsi_values[i] = 100
        else:
            rs = avg_gain / avg_loss
            rsi_values[i] = 100 - (100 / (1 + rs))
    
    return rsi_values


def bollinger_bands(data: Union[pd.Series, np.ndarray], 
                    period: int = 20, 
                    std_dev: float = 2.0) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Calculate Bollinger Bands.
    
    Args:
        data: Price data as pandas Series or numpy array
        period: Period for the moving average calculation
        std_dev: Number of standard deviations for the bands
    
    Returns:
        Tuple of (upper_band, middle_band, lower_band) as numpy arrays
    """
    if isinstance(data, pd.Series):
        data = data.values
    
    # Calculate middle band (SMA)
    middle_band = moving_average(data, period, MAType.SIMPLE)
    
    # Calculate standard deviation
    rolling_std = np.zeros_like(data)
    rolling_std[:period-1] = np.nan
    
    for i in range(period-1, len(data)):
        rolling_std[i] = np.std(data[i-period+1:i+1], ddof=1)
    
    # Calculate upper and lower bands
    upper_band = middle_band + (rolling_std * std_dev)
    lower_band = middle_band - (rolling_std * std_dev)
    
    return upper_band, middle_band, lower_band


def macd(data: Union[pd.Series, np.ndarray], 
         fast_period: int = 12, 
         slow_period: int = 26, 
         signal_period: int = 9) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Calculate Moving Average Convergence Divergence (MACD).
    
    Args:
        data: Price data as pandas Series or numpy array
        fast_period: Period for the fast EMA
        slow_period: Period for the slow EMA
        signal_period: Period for the signal line
    
    Returns:
        Tuple of (macd_line, signal_line, histogram) as numpy arrays
    """
    if isinstance(data, pd.Series):
        data = data.values
    
    # Calculate fast and slow EMAs
    fast_ema = moving_average(data, fast_period, MAType.EXPONENTIAL)
    slow_ema = moving_average(data, slow_period, MAType.EXPONENTIAL)
    
    # Calculate MACD line
    macd_line = fast_ema - slow_ema
    
    # Calculate signal line
    signal_line = moving_average(macd_line, signal_period, MAType.EXPONENTIAL)
    
    # Calculate histogram
    histogram = macd_line - signal_line
    
    return macd_line, signal_line, histogram


def atr(high: Union[pd.Series, np.ndarray], 
        low: Union[pd.Series, np.ndarray], 
        close: Union[pd.Series, np.ndarray], 
        period: int = 14) -> np.ndarray:
    """
    Calculate Average True Range (ATR).
    
    Args:
        high: High prices as pandas Series or numpy array
        low: Low prices as pandas Series or numpy array
        close: Close prices as pandas Series or numpy array
        period: ATR calculation period
    
    Returns:
        numpy array containing the ATR values
    """
    if isinstance(high, pd.Series):
        high = high.values
    if isinstance(low, pd.Series):
        low = low.values
    if isinstance(close, pd.Series):
        close = close.values
    
    if len(close) <= period:
        return np.full_like(close, np.nan)
    
    # Calculate true range
    tr = np.zeros_like(close)
    tr[0] = high[0] - low[0]  # First TR is simply the first day's range
    
    for i in range(1, len(close)):
        # True range is the greatest of:
        # 1. Current high - current low
        # 2. Current high - previous close (absolute)
        # 3. Current low - previous close (absolute)
        tr[i] = max(
            high[i] - low[i],
            abs(high[i] - close[i-1]),
            abs(low[i] - close[i-1])
        )
    
    # Initialize ATR array
    atr_values = np.zeros_like(close)
    atr_values[:period] = np.nan
    
    # First ATR is simple average of first 'period' true ranges
    atr_values[period-1] = np.mean(tr[:period])
    
    # Calculate ATR using Wilder's smoothing method
    for i in range(period, len(close)):
        atr_values[i] = ((period - 1) * atr_values[i-1] + tr[i]) / period
    
    return atr_values


def stochastic(high: Union[pd.Series, np.ndarray], 
               low: Union[pd.Series, np.ndarray], 
               close: Union[pd.Series, np.ndarray], 
               k_period: int = 14, 
               d_period: int = 3) -> Tuple[np.ndarray, np.ndarray]:
    """
    Calculate Stochastic Oscillator.
    
    Args:
        high: High prices as pandas Series or numpy array
        low: Low prices as pandas Series or numpy array
        close: Close prices as pandas Series or numpy array
        k_period: Period for %K calculation
        d_period: Period for %D calculation (simple moving average of %K)
    
    Returns:
        Tuple of (%K, %D) as numpy arrays
    """
    if isinstance(high, pd.Series):
        high = high.values
    if isinstance(low, pd.Series):
        low = low.values
    if isinstance(close, pd.Series):
        close = close.values
    
    if len(close) <= k_period:
        return np.full_like(close, np.nan), np.full_like(close, np.nan)
    
    # Initialize %K array
    k = np.zeros_like(close)
    k[:k_period-1] = np.nan
    
    # Calculate %K
    for i in range(k_period-1, len(close)):
        highest_high = np.max(high[i-k_period+1:i+1])
        lowest_low = np.min(low[i-k_period+1:i+1])
        
        if highest_high == lowest_low:
            k[i] = 50  # If range is zero, use 50 as default
        else:
            k[i] = 100 * (close[i] - lowest_low) / (highest_high - lowest_low)
    
    # Calculate %D (SMA of %K)
    d = moving_average(k, d_period, MAType.SIMPLE)
    
    return k, d


def adx(high: Union[pd.Series, np.ndarray], 
        low: Union[pd.Series, np.ndarray], 
        close: Union[pd.Series, np.ndarray], 
        period: int = 14) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Calculate Average Directional Index (ADX), +DI, and -DI.
    
    Args:
        high: High prices as pandas Series or numpy array
        low: Low prices as pandas Series or numpy array
        close: Close prices as pandas Series or numpy array
        period: ADX calculation period
    
    Returns:
        Tuple of (ADX, +DI, -DI, DX) as numpy arrays
    """
    if isinstance(high, pd.Series):
        high = high.values
    if isinstance(low, pd.Series):
        low = low.values
    if isinstance(close, pd.Series):
        close = close.values
    
    if len(close) <= period + 1:
        nan_array = np.full_like(close, np.nan)
        return nan_array, nan_array, nan_array, nan_array
    
    # Calculate True Range
    tr = np.zeros_like(close)
    tr[0] = high[0] - low[0]
    
    for i in range(1, len(close)):
        tr[i] = max(
            high[i] - low[i],
            abs(high[i] - close[i-1]),
            abs(low[i] - close[i-1])
        )
    
    # Calculate +DM and -DM
    plus_dm = np.zeros_like(close)
    minus_dm = np.zeros_like(close)
    
    for i in range(1, len(close)):
        up_move = high[i] - high[i-1]
        down_move = low[i-1] - low[i]
        
        if up_move > down_move and up_move > 0:
            plus_dm[i] = up_move
        else:
            plus_dm[i] = 0
        
        if down_move > up_move and down_move > 0:
            minus_dm[i] = down_move
        else:
            minus_dm[i] = 0
    
    # Calculate smoothed TR, +DM, and -DM
    smoothed_tr = np.zeros_like(close)
    smoothed_plus_dm = np.zeros_like(close)
    smoothed_minus_dm = np.zeros_like(close)
    
    # First values
    smoothed_tr[period] = np.sum(tr[1:period+1])
    smoothed_plus_dm[period] = np.sum(plus_dm[1:period+1])
    smoothed_minus_dm[period] = np.sum(minus_dm[1:period+1])
    
    # Wilder's smoothing
    for i in range(period+1, len(close)):
        smoothed_tr[i] = smoothed_tr[i-1] - (smoothed_tr[i-1] / period) + tr[i]
        smoothed_plus_dm[i] = smoothed_plus_dm[i-1] - (smoothed_plus_dm[i-1] / period) + plus_dm[i]
        smoothed_minus_dm[i] = smoothed_minus_dm[i-1] - (smoothed_minus_dm[i-1] / period) + minus_dm[i]
    
    # Calculate +DI and -DI
    plus_di = np.zeros_like(close)
    minus_di = np.zeros_like(close)
    
    for i in range(period, len(close)):
        if smoothed_tr[i] > 0:
            plus_di[i] = 100 * smoothed_plus_dm[i] / smoothed_tr[i]
            minus_di[i] = 100 * smoothed_minus_dm[i] / smoothed_tr[i]
        else:
            plus_di[i] = 0
            minus_di[i] = 0
    
    # Calculate DX
    dx = np.zeros_like(close)
    
    for i in range(period, len(close)):
        if plus_di[i] + minus_di[i] > 0:
            dx[i] = 100 * abs(plus_di[i] - minus_di[i]) / (plus_di[i] + minus_di[i])
        else:
            dx[i] = 0
    
    # Calculate ADX
    adx_values = np.zeros_like(close)
    adx_values[:2*period-1] = np.nan
    
    # First ADX
    adx_values[2*period-1] = np.mean(dx[period:2*period])
    
    # Wilder's smoothing for ADX
    for i in range(2*period, len(close)):
        adx_values[i] = ((period - 1) * adx_values[i-1] + dx[i]) / period
    
    # Set initial values to NaN
    plus_di[:period] = np.nan
    minus_di[:period] = np.nan
    dx[:period] = np.nan
    
    return adx_values, plus_di, minus_di, dx


def ichimoku(high: Union[pd.Series, np.ndarray], 
             low: Union[pd.Series, np.ndarray], 
             close: Union[pd.Series, np.ndarray],
             tenkan_period: int = 9, 
             kijun_period: int = 26, 
             senkou_span_b_period: int = 52,
             displacement: int = 26) -> Dict[str, np.ndarray]:
    """
    Calculate Ichimoku Cloud components.
    
    Args:
        high: High prices as pandas Series or numpy array
        low: Low prices as pandas Series or numpy array
        close: Close prices as pandas Series or numpy array
        tenkan_period: Period for Tenkan-sen (Conversion Line)
        kijun_period: Period for Kijun-sen (Base Line)
        senkou_span_b_period: Period for Senkou Span B (Leading Span B)
        displacement: Displacement period for Senkou Span A/B and Chikou Span
    
    Returns:
        Dictionary containing all Ichimoku components as numpy arrays
    """
    if isinstance(high, pd.Series):
        high = high.values
    if isinstance(low, pd.Series):
        low = low.values
    if isinstance(close, pd.Series):
        close = close.values
    
    # Initialize arrays
    tenkan_sen = np.zeros_like(close)
    kijun_sen = np.zeros_like(close)
    senkou_span_a = np.zeros_like(close)
    senkou_span_b = np.zeros_like(close)
    chikou_span = np.zeros_like(close)
    
    # Calculate Tenkan-sen (Conversion Line)
    for i in range(tenkan_period-1, len(close)):
        highest_high = np.max(high[i-tenkan_period+1:i+1])
        lowest_low = np.min(low[i-tenkan_period+1:i+1])
        tenkan_sen[i] = (highest_high + lowest_low) / 2
    
    # Calculate Kijun-sen (Base Line)
    for i in range(kijun_period-1, len(close)):
        highest_high = np.max(high[i-kijun_period+1:i+1])
        lowest_low = np.min(low[i-kijun_period+1:i+1])
        kijun_sen[i] = (highest_high + lowest_low) / 2
    
    # Calculate Senkou Span A (Leading Span A)
    for i in range(kijun_period-1, len(close)):
        if i + displacement < len(close):
            senkou_span_a[i+displacement] = (tenkan_sen[i] + kijun_sen[i]) / 2
    
    # Calculate Senkou Span B (Leading Span B)
    for i in range(senkou_span_b_period-1, len(close)):
        if i + displacement < len(close):
            highest_high = np.max(high[i-senkou_span_b_period+1:i+1])
            lowest_low = np.min(low[i-senkou_span_b_period+1:i+1])
            senkou_span_b[i+displacement] = (highest_high + lowest_low) / 2
    
    # Calculate Chikou Span (Lagging Span)
    for i in range(displacement, len(close)):
        chikou_span[i-displacement] = close[i]
    
    # Set initial values to NaN
    tenkan_sen[:tenkan_period-1] = np.nan
    kijun_sen[:kijun_period-1] = np.nan
    senkou_span_a[:kijun_period+displacement-1] = np.nan
    senkou_span_b[:senkou_span_b_period+displacement-1] = np.nan
    chikou_span[-displacement:] = np.nan
    
    return {
        'tenkan_sen': tenkan_sen,
        'kijun_sen': kijun_sen,
        'senkou_span_a': senkou_span_a,
        'senkou_span_b': senkou_span_b,
        'chikou_span': chikou_span
    }


def vwap(high: Union[pd.Series, np.ndarray], 
         low: Union[pd.Series, np.ndarray], 
         close: Union[pd.Series, np.ndarray], 
         volume: Union[pd.Series, np.ndarray],
         reset_period: Optional[int] = None) -> np.ndarray:
    """
    Calculate Volume Weighted Average Price (VWAP).
    
    Args:
        high: High prices as pandas Series or numpy array
        low: Low prices as pandas Series or numpy array
        close: Close prices as pandas Series or numpy array
        volume: Volume data as pandas Series or numpy array
        reset_period: Period after which to reset VWAP calculation (e.g., daily)
                     If None, calculates cumulative VWAP without resetting
    
    Returns:
        numpy array containing the VWAP values
    """
    if isinstance(high, pd.Series):
        high = high.values
    if isinstance(low, pd.Series):
        low = low.values
    if isinstance(close, pd.Series):
        close = close.values
    if isinstance(volume, pd.Series):
        volume = volume.values
    
    # Calculate typical price
    typical_price = (high + low + close) / 3
    
    # Initialize arrays
    vwap_values = np.zeros_like(close)
    cumulative_tp_vol = np.zeros_like(close)
    cumulative_vol = np.zeros_like(close)
    
    if reset_period is None:
        # Cumulative VWAP without resetting
        for i in range(len(close)):
            if i == 0:
                cumulative_tp_vol[i] = typical_price[i] * volume[i]
                cumulative_vol[i] = volume[i]
            else:
                cumulative_tp_vol[i] = cumulative_tp_vol[i-1] + typical_price[i] * volume[i]
                cumulative_vol[i] = cumulative_vol[i-1] + volume[i]
            
            if cumulative_vol[i] > 0:
                vwap_values[i] = cumulative_tp_vol[i] / cumulative_vol[i]
            else:
                vwap_values[i] = typical_price[i]
    else:
        # VWAP with periodic reset
        for i in range(len(close)):
            if i % reset_period == 0:
                # Reset at the beginning of each period
                cumulative_tp_vol[i] = typical_price[i] * volume[i]
                cumulative_vol[i] = volume[i]
            else:
                # Within the same period, accumulate
                period_start = (i // reset_period) * reset_period
                cumulative_tp_vol[i] = cumulative_tp_vol[i-1] + typical_price[i] * volume[i]
                cumulative_vol[i] = cumulative_vol[i-1] + volume[i]
            
            if cumulative_vol[i] > 0:
                vwap_values[i] = cumulative_tp_vol[i] / cumulative_vol[i]
            else:
                vwap_values[i] = typical_price[i]
    
    return vwap_values


def pivot_points(high: Union[pd.Series, np.ndarray], 
                 low: Union[pd.Series, np.ndarray], 
                 close: Union[pd.Series, np.ndarray],
                 method: str = 'standard') -> Dict[str, np.ndarray]:
    """
    Calculate pivot points and support/resistance levels.
    
    Args:
        high: High prices as pandas Series or numpy array
        low: Low prices as pandas Series or numpy array
        close: Close prices as pandas Series or numpy array
        method: Pivot point calculation method ('standard', 'fibonacci', 'woodie', 'camarilla', 'demark')
    
    Returns:
        Dictionary containing pivot point and support/resistance levels as numpy arrays
    """
    if isinstance(high, pd.Series):
        high = high.values
    if isinstance(low, pd.Series):
        low = low.values
    if isinstance(close, pd.Series):
        close = close.values
    
    # Initialize arrays for pivot and support/resistance levels
    pivot = np.zeros_like(close)
    s1 = np.zeros_like(close)
    s2 = np.zeros_like(close)
    s3 = np.zeros_like(close)
    s4 = np.zeros_like(close)
    r1 = np.zeros_like(close)
    r2 = np.zeros_like(close)
    r3 = np.zeros_like(close)
    r4 = np.zeros_like(close)
    
    # Set first values to NaN
    pivot[0] = np.nan
    s1[0] = np.nan
    s2[0] = np.nan
    s3[0] = np.nan
    s4[0] = np.nan
    r1[0] = np.nan
    r2[0] = np.nan
    r3[0] = np.nan
    r4[0] = np.nan
    
    # Calculate pivot points based on the selected method
    for i in range(1, len(close)):
        if method == 'standard':
            # Standard pivot points
            pivot[i] = (high[i-1] + low[i-1] + close[i-1]) / 3
            s1[i] = (2 * pivot[i]) - high[i-1]
            s2[i] = pivot[i] - (high[i-1] - low[i-1])
            s3[i] = low[i-1] - 2 * (high[i-1] - pivot[i])
            r1[i] = (2 * pivot[i]) - low[i-1]
            r2[i] = pivot[i] + (high[i-1] - low[i-1])
            r3[i] = high[i-1] + 2 * (pivot[i] - low[i-1])
            
        elif method == 'fibonacci':
            # Fibonacci pivot points
            pivot[i] = (high[i-1] + low[i-1] + close[i-1]) / 3
            r1[i] = pivot[i] + 0.382 * (high[i-1] - low[i-1])
            r2[i] = pivot[i] + 0.618 * (high[i-1] - low[i-1])
            r3[i] = pivot[i] + 1.000 * (high[i-1] - low[i-1])
            s1[i] = pivot[i] - 0.382 * (high[i-1] - low[i-1])
            s2[i] = pivot[i] - 0.618 * (high[i-1] - low[i-1])
            s3[i] = pivot[i] - 1.000 * (high[i-1] - low[i-1])
            
        elif method == 'woodie':
            # Woodie pivot points
            pivot[i] = (high[i-1] + low[i-1] + 2 * close[i-1]) / 4
            r1[i] = (2 * pivot[i]) - low[i-1]
            r2[i] = pivot[i] + (high[i-1] - low[i-1])
            s1[i] = (2 * pivot[i]) - high[i-1]
            s2[i] = pivot[i] - (high[i-1] - low[i-1])
            
        elif method == 'camarilla':
            # Camarilla pivot points
            pivot[i] = (high[i-1] + low[i-1] + close[i-1]) / 3
            range_val = high[i-1] - low[i-1]
            
            r1[i] = close[i-1] + range_val * 1.1 / 12
            r2[i] = close[i-1] + range_val * 1.1 / 6
            r3[i] = close[i-1] + range_val * 1.1 / 4
            r4[i] = close[i-1] + range_val * 1.1 / 2
            
            s1[i] = close[i-1] - range_val * 1.1 / 12
            s2[i] = close[i-1] - range_val * 1.1 / 6
            s3[i] = close[i-1] - range_val * 1.1 / 4
            s4[i] = close[i-1] - range_val * 1.1 / 2
            
        elif method == 'demark':
            # DeMark pivot points
            if close[i-1] < open[i-1]:
                x = high[i-1] + 2 * low[i-1] + close[i-1]
            elif close[i-1] > open[i-1]:
                x = 2 * high[i-1] + low[i-1] + close[i-1]
            else:
                x = high[i-1] + low[i-1] + 2 * close[i-1]
                
            pivot[i] = x / 4
            r1[i] = x / 2 - low[i-1]
            s1[i] = x / 2 - high[i-1]
            
        else:
            raise ValueError(f"Unsupported pivot point method: {method}")
    
    # Create result dictionary
    result = {
        'pivot': pivot,
        's1': s1,
        's2': s2,
        's3': s3,
        'r1': r1,
        'r2': r2,
        'r3': r3
    }
    
    # Add s4 and r4 for Camarilla method
    if method == 'camarilla':
        result['s4'] = s4
        result['r4'] = r4
    
    return result


def supertrend(high: Union[pd.Series, np.ndarray], 
               low: Union[pd.Series, np.ndarray], 
               close: Union[pd.Series, np.ndarray],
               period: int = 10, 
               multiplier: float = 3.0) -> Tuple[np.ndarray, np.ndarray]:
    """
    Calculate SuperTrend indicator.
    
    Args:
        high: High prices as pandas Series or numpy array
        low: Low prices as pandas Series or numpy array
        close: Close prices as pandas Series or numpy array
        period: ATR calculation period
        multiplier: ATR multiplier for band calculation
    
    Returns:
        Tuple of (supertrend_values, supertrend_direction) as numpy arrays
        where direction is 1 for bullish (close > supertrend) and -1 for bearish
    """
    if isinstance(high, pd.Series):
        high = high.values
    if isinstance(low, pd.Series):
        low = low.values
    if isinstance(close, pd.Series):
        close = close.values
    
    # Calculate ATR
    atr_values = atr(high, low, close, period)
    
    # Calculate basic upper and lower bands
    basic_upper_band = np.zeros_like(close)
    basic_lower_band = np.zeros_like(close)
    
    for i in range(period, len(close)):
        basic_upper_band[i] = (high[i] + low[i]) / 2 + multiplier * atr_values[i]
        basic_lower_band[i] = (high[i] + low[i]) / 2 - multiplier * atr_values[i]
    
    # Calculate final upper and lower bands
    final_upper_band = np.zeros_like(close)
    final_lower_band = np.zeros_like(close)
    
    final_upper_band[period] = basic_upper_band[period]
    final_lower_band[period] = basic_lower_band[period]
    
    for i in range(period+1, len(close)):
        # Final upper band
        if basic_upper_band[i] < final_upper_band[i-1] or close[i-1] > final_upper_band[i-1]:
            final_upper_band[i] = basic_upper_band[i]
        else:
            final_upper_band[i] = final_upper_band[i-1]
        
        # Final lower band
        if basic_lower_band[i] > final_lower_band[i-1] or close[i-1] < final_lower_band[i-1]:
            final_lower_band[i] = basic_lower_band[i]
        else:
            final_lower_band[i] = final_lower_band[i-1]
    
    # Calculate SuperTrend
    supertrend = np.zeros_like(close)
    direction = np.zeros_like(close)
    
    # Set initial values to NaN
    supertrend[:period] = np.nan
    direction[:period] = np.nan
    
    # Initial direction
    if close[period] > final_upper_band[period]:
        direction[period] = 1
        supertrend[period] = final_lower_band[period]
    else:
        direction[period] = -1
        supertrend[period] = final_upper_band[period]
    
    # Calculate SuperTrend and direction
    for i in range(period+1, len(close)):
        if supertrend[i-1] == final_upper_band[i-1] and close[i] <= final_upper_band[i]:
            # Continuing bearish
            supertrend[i] = final_upper_band[i]
            direction[i] = -1
        elif supertrend[i-1] == final_upper_band[i-1] and close[i] > final_upper_band[i]:
            # Changing to bullish
            supertrend[i] = final_lower_band[i]
            direction[i] = 1
        elif supertrend[i-1] == final_lower_band[i-1] and close[i] >= final_lower_band[i]:
            # Continuing bullish
            supertrend[i] = final_lower_band[i]
            direction[i] = 1
        elif supertrend[i-1] == final_lower_band[i-1] and close[i] < final_lower_band[i]:
            # Changing to bearish
            supertrend[i] = final_upper_band[i]
            direction[i] = -1
    
    return supertrend, direction
