"""
Pluggable tick replay mechanism for algorithmic trading framework.

This module provides a set of classes for generating and replaying market data ticks
from various sources, including real historical data, synthetic random data, and
scripted scenarios.

Classes:
    TickSource: Abstract base class for tick sources
    RealTickSource: Reads ticks from CSV files or connects to live market data feeds
    SyntheticTickSource: Generates random market data with configurable parameters
    ScriptedTickSource: Creates predefined market scenarios (trends, breakouts, etc.)
"""

import os
import csv
import time
import random
import logging
import threading
import numpy as np
import pytz
from abc import ABC, abstractmethod
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Set, Tuple

from models.instrument import Instrument
from models.events import MarketDataEvent, Event
from utils.constants import EventType, MarketDataType

class TickSource(ABC):
    """
    Abstract base class for tick sources.
    
    This class defines the interface that all tick sources must implement.
    """
    
    def __init__(self, event_manager):
        """
        Initialize the tick source.
        
        Args:
            event_manager: Event manager instance for publishing market data events
        """
        self.logger = logging.getLogger(self.__class__.__name__)
        self.event_manager = event_manager
        self.running = False
        self.thread = None
        self.subscriptions: Set[Instrument] = set()
        self._shutdown_event = threading.Event()
        # CRITICAL FIX: Add timezone for Indian markets
        self.timezone = pytz.timezone('Asia/Kolkata')
        
    def subscribe(self, instrument: Instrument) -> bool:
        """
        Subscribe to market data for an instrument.
        
        Args:
            instrument: Instrument to subscribe to
            
        Returns:
            bool: True if subscription was successful, False otherwise
        """
        if instrument in self.subscriptions:
            self.logger.warning(f"Already subscribed to {instrument.symbol}")
            return False
            
        self.subscriptions.add(instrument)
        self.logger.info(f"Subscribed to {instrument.symbol}")
        return True
        
    def unsubscribe(self, instrument: Instrument) -> bool:
        """
        Unsubscribe from market data for an instrument.
        
        Args:
            instrument: Instrument to unsubscribe from
            
        Returns:
            bool: True if unsubscription was successful, False otherwise
        """
        if instrument not in self.subscriptions:
            self.logger.warning(f"Not subscribed to {instrument.symbol}")
            return False
            
        self.subscriptions.remove(instrument)
        self.logger.info(f"Unsubscribed from {instrument.symbol}")
        return True
        
    def start(self) -> bool:
        """
        Start the tick source.
        
        Returns:
            bool: True if started successfully, False otherwise
        """
        if self.running:
            self.logger.warning("Tick source already running")
            return False
            
        self.running = True
        self._shutdown_event.clear()
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()
        self.logger.info("Tick source started")
        return True
        
    def stop(self) -> bool:
        """
        Stop the tick source.
        
        Returns:
            bool: True if stopped successfully, False otherwise
        """
        if not self.running:
            self.logger.warning("Tick source not running")
            return False
            
        self.running = False
        self._shutdown_event.set()
        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=5.0)
        self.logger.info("Tick source stopped")
        return True
        
    @abstractmethod
    def _run(self):
        """
        Main loop for generating ticks.
        
        This method must be implemented by subclasses.
        """
        pass
    
    # CRITICAL FIX: Add method to generate timestamps in IST timezone
    def _generate_ist_timestamp(self) -> int:
        """
        Generate a timestamp in Indian Standard Time (IST) that falls within market hours.
        
        Returns:
            int: Timestamp in milliseconds (epoch)
        """
        # Get current time in IST
        now = datetime.now(self.timezone)
        
        # If current time is outside market hours (9:15 AM to 3:30 PM), adjust to within market hours
        market_open = now.replace(hour=9, minute=15, second=0, microsecond=0)
        market_close = now.replace(hour=15, minute=30, second=0, microsecond=0)
        
        # If weekend (Saturday=5, Sunday=6), adjust to Friday
        if now.weekday() >= 5:  # Weekend
            days_to_subtract = now.weekday() - 4  # Go back to Friday
            now = now - timedelta(days=days_to_subtract)
            # Reset to market hours
            now = now.replace(hour=12, minute=0, second=0, microsecond=0)
        
        # If before market open or after market close, adjust to within market hours
        if now.time() < market_open.time():
            now = now.replace(hour=12, minute=0, second=0, microsecond=0)
        elif now.time() > market_close.time():
            now = now.replace(hour=12, minute=0, second=0, microsecond=0)
        
        # Convert to milliseconds since epoch
        return int(now.timestamp() * 1000)
        
    def _publish_tick(self, instrument: Instrument, tick_data: Dict[str, Any]):
        """
        Publish a market data event.
        
        Args:
            instrument: Instrument the tick is for
            tick_data: Dictionary containing tick data fields
        """
        # CRITICAL FIX: Ensure event_type and timestamp are properly set
        if 'event_type' not in tick_data:
            tick_data['event_type'] = EventType.MARKET_DATA
            
        if MarketDataType.TIMESTAMP.value not in tick_data:
            # CRITICAL FIX: Use IST timestamp instead of UTC
            tick_data[MarketDataType.TIMESTAMP.value] = self._generate_ist_timestamp()
            
        # Create and publish the market data event
        event = MarketDataEvent(
            event_type=EventType.MARKET_DATA,
            timestamp=tick_data[MarketDataType.TIMESTAMP.value],
            instrument=instrument,
            data=tick_data
        )
        
        self.event_manager.publish(event)

class RealTickSource(TickSource):
    """
    Tick source that reads from CSV files or connects to live market data feeds.
    """
    
    def __init__(self, event_manager, data_file=None, replay_speed=1.0, loop=False):
        """
        Initialize the real tick source.
        
        Args:
            event_manager: Event manager instance
            data_file: Path to CSV file containing tick data
            replay_speed: Speed multiplier for replay (1.0 = real-time)
            loop: Whether to loop the data file when it reaches the end
        """
        super().__init__(event_manager)
        self.data_file = data_file
        self.replay_speed = replay_speed
        self.loop = loop
        self.tick_data = []
        self.current_index = 0
        
        if data_file and os.path.exists(data_file):
            self._load_data()
        else:
            self.logger.warning(f"Data file not found: {data_file}")
            
    def _load_data(self):
        """Load tick data from CSV file."""
        try:
            with open(self.data_file, 'r') as f:
                reader = csv.DictReader(f)
                self.tick_data = list(reader)
                
            self.logger.info(f"Loaded {len(self.tick_data)} ticks from {self.data_file}")
        except Exception as e:
            self.logger.error(f"Error loading data file: {str(e)}")
            self.tick_data = []
            
    def _run(self):
        """Main loop for replaying ticks from file."""
        if not self.tick_data:
            self.logger.error("No tick data to replay")
            return
            
        self.logger.info(f"Starting tick replay at {self.replay_speed}x speed")
        
        last_tick_time = None
        while self.running and not self._shutdown_event.is_set():
            if self.current_index >= len(self.tick_data):
                if self.loop:
                    self.logger.info("Reached end of tick data, looping back to start")
                    self.current_index = 0
                else:
                    self.logger.info("Reached end of tick data")
                    break
                    
            # Get the current tick
            tick = self.tick_data[self.current_index]
            
            # Extract timestamp
            try:
                tick_time = datetime.fromisoformat(tick.get('timestamp', ''))
            except (ValueError, TypeError):
                # Try millisecond timestamp
                try:
                    tick_time = datetime.fromtimestamp(int(tick.get('timestamp', 0)) / 1000)
                except (ValueError, TypeError):
                    self.logger.warning(f"Invalid timestamp in tick: {tick}")
                    self.current_index += 1
                    continue
                    
            # Calculate delay
            if last_tick_time is not None:
                delay = (tick_time - last_tick_time).total_seconds() / self.replay_speed
                if delay > 0:
                    time.sleep(delay)
                    
            # Find matching instrument
            symbol = tick.get('symbol', '')
            matching_instruments = [i for i in self.subscriptions if i.symbol == symbol]
            
            if not matching_instruments:
                self.logger.debug(f"No matching instrument for symbol: {symbol}")
                self.current_index += 1
                continue
                
            instrument = matching_instruments[0]
            
            # Convert tick data to standard format
            tick_data = self._convert_tick(tick)
            
            # Publish the tick
            self._publish_tick(instrument, tick_data)
            
            # Update last tick time
            last_tick_time = tick_time
            
            # Move to next tick
            self.current_index += 1
            
        self.logger.info("Tick replay completed")
        
    def _convert_tick(self, tick: Dict[str, str]) -> Dict[str, Any]:
        """
        Convert tick data from CSV format to standard format.
        
        Args:
            tick: Dictionary containing tick data from CSV
            
        Returns:
            Dict[str, Any]: Standardized tick data
        """
        # CRITICAL FIX: Ensure all required fields are present with correct types
        result = {}
        
        # Map CSV column names to MarketDataType values
        field_mapping = {
            'timestamp': MarketDataType.TIMESTAMP.value,
            'last': MarketDataType.LAST_PRICE.value,
            'bid': MarketDataType.BID.value,
            'ask': MarketDataType.ASK.value,
            'volume': MarketDataType.VOLUME.value,
            'open': MarketDataType.OPEN.value,
            'high': MarketDataType.HIGH.value,
            'low': MarketDataType.LOW.value,
            'close': MarketDataType.CLOSE.value,
        }
        
        # Convert fields
        for csv_field, data_type in field_mapping.items():
            if csv_field in tick:
                try:
                    if csv_field == 'timestamp':
                        # Try parsing as ISO format
                        try:
                            dt = datetime.fromisoformat(tick[csv_field])
                            # CRITICAL FIX: Ensure timestamp is in IST timezone
                            if dt.tzinfo is None:
                                dt = self.timezone.localize(dt)
                            result[data_type] = int(dt.timestamp() * 1000)
                        except ValueError:
                            # Try parsing as millisecond timestamp
                            result[data_type] = int(tick[csv_field])
                    else:
                        # Convert numeric fields
                        result[data_type] = float(tick[csv_field])
                except (ValueError, TypeError):
                    self.logger.warning(f"Error converting field {csv_field}: {tick[csv_field]}")
        
        # Ensure timestamp is present
        if MarketDataType.TIMESTAMP.value not in result:
            # CRITICAL FIX: Use IST timestamp instead of UTC
            result[MarketDataType.TIMESTAMP.value] = self._generate_ist_timestamp()
            
        # Ensure last price is present
        if MarketDataType.LAST_PRICE.value not in result and 'price' in tick:
            try:
                result[MarketDataType.LAST_PRICE.value] = float(tick['price'])
            except (ValueError, TypeError):
                pass
                
        return result

class SyntheticTickSource(TickSource):
    """
    Tick source that generates random market data with configurable parameters.
    """
    
    def __init__(self, event_manager, tick_interval=0.1, volatility=0.001, trend=0.0,
                 volume_mean=100.0, volume_std=50.0, price_jump_prob=0.01, price_jump_factor=0.01):
        """
        Initialize the synthetic tick source.
        
        Args:
            event_manager: Event manager instance
            tick_interval: Time between ticks in seconds
            volatility: Standard deviation of price changes
            trend: Mean of price changes (positive = uptrend, negative = downtrend)
            volume_mean: Mean of volume
            volume_std: Standard deviation of volume
            price_jump_prob: Probability of a price jump
            price_jump_factor: Size of price jumps as a fraction of price
        """
        super().__init__(event_manager)
        self.tick_interval = tick_interval
        self.volatility = volatility
        self.trend = trend
        self.volume_mean = volume_mean
        self.volume_std = volume_std
        self.price_jump_prob = price_jump_prob
        self.price_jump_factor = price_jump_factor
        
        # Initial prices for instruments
        self.prices = {}
        self.volumes = {}
        
    def _run(self):
        """Main loop for generating synthetic ticks."""
        self.logger.info("Starting synthetic tick generation")
        
        # Initialize prices and volumes
        for instrument in self.subscriptions:
            # Generate random initial price between 10 and 100
            self.prices[instrument] = random.uniform(10.0, 100.0)
            self.volumes[instrument] = 0
            
        while self.running and not self._shutdown_event.is_set():
            start_time = time.time()
            
            # Generate ticks for each subscribed instrument
            for instrument in self.subscriptions:
                # Generate tick data
                tick_data = self._generate_tick(instrument)
                
                # Publish the tick
                self._publish_tick(instrument, tick_data)
                
            # Sleep until next tick
            elapsed = time.time() - start_time
            sleep_time = max(0.0, self.tick_interval - elapsed)
            if sleep_time > 0:
                time.sleep(sleep_time)
                
        self.logger.info("Synthetic tick generation stopped")
        
    def _generate_tick(self, instrument: Instrument) -> Dict[str, Any]:
        """
        Generate synthetic tick data for an instrument.
        
        Args:
            instrument: Instrument to generate tick for
            
        Returns:
            Dict[str, Any]: Synthetic tick data
        """
        # Get current price
        current_price = self.prices[instrument]
        
        # Generate price change
        price_change = np.random.normal(self.trend, self.volatility) * current_price
        
        # Apply price jump with low probability
        if random.random() < self.price_jump_prob:
            jump_direction = 1 if random.random() > 0.5 else -1
            price_change += jump_direction * self.price_jump_factor * current_price
            
        # Update price
        new_price = max(0.01, current_price + price_change)
        self.prices[instrument] = new_price
        
        # Generate volume
        volume = max(1, int(np.random.normal(self.volume_mean, self.volume_std)))
        
        # Update cumulative volume
        self.volumes[instrument] += volume
        
        # Generate tick data
        tick_data = {
            # CRITICAL FIX: Use MarketDataType enum values as keys and IST timestamp
            MarketDataType.TIMESTAMP.value: self._generate_ist_timestamp(),
            MarketDataType.LAST_PRICE.value: new_price,
            MarketDataType.BID.value: new_price * 0.999,
            MarketDataType.ASK.value: new_price * 1.001,
            MarketDataType.VOLUME.value: self.volumes[instrument],  # Cumulative volume
            MarketDataType.OPEN.value: new_price,
            MarketDataType.HIGH.value: new_price * 1.001,
            MarketDataType.LOW.value: new_price * 0.999,
            MarketDataType.CLOSE.value: new_price,
            'event_type': EventType.MARKET_DATA  # CRITICAL FIX: Include event_type
        }
        
        return tick_data

class ScriptedTickSource(TickSource):
    """
    Tick source that creates predefined market scenarios.
    """
    
    def __init__(self, event_manager, scenario="random_walk", tick_interval=0.1, duration=300,
                 volatility=0.001, trend=0.0, volume_mean=100.0, volume_std=50.0,
                 price_jump_prob=0.01, price_jump_factor=0.01):
        """
        Initialize the scripted tick source.
        
        Args:
            event_manager: Event manager instance
            scenario: Market scenario to simulate
            tick_interval: Time between ticks in seconds
            duration: Duration of the scenario in seconds
            volatility: Base volatility level
            trend: Base trend level
            volume_mean: Mean of volume
            volume_std: Standard deviation of volume
            price_jump_prob: Probability of a price jump
            price_jump_factor: Size of price jumps as a fraction of price
        """
        super().__init__(event_manager)
        self.scenario = scenario
        self.tick_interval = tick_interval
        self.duration = duration
        self.volatility = volatility
        self.trend = trend
        self.volume_mean = volume_mean
        self.volume_std = volume_std
        self.price_jump_prob = price_jump_prob
        self.price_jump_factor = price_jump_factor
        
        # Initial prices and scenario parameters
        self.prices = {}
        self.volumes = {}
        self.scenario_params = {}
        self.start_time = None
        
    def _run(self):
        """Main loop for generating scripted scenario ticks."""
        self.logger.info(f"Starting scripted tick generation for scenario: {self.scenario}")
        
        # Initialize prices, volumes, and scenario parameters
        for instrument in self.subscriptions:
            # Generate random initial price between 10 and 100
            self.prices[instrument] = random.uniform(10.0, 100.0)
            self.volumes[instrument] = 0
            
            # Initialize scenario-specific parameters
            self.scenario_params[instrument] = self._initialize_scenario(instrument)
            
        self.start_time = time.time()
        
        while self.running and not self._shutdown_event.is_set():
            current_time = time.time()
            elapsed = current_time - self.start_time
            
            # Check if scenario duration has elapsed
            if elapsed >= self.duration:
                self.logger.info(f"Scenario duration ({self.duration}s) elapsed")
                break
                
            start_tick_time = time.time()
            
            # Generate ticks for each subscribed instrument
            for instrument in self.subscriptions:
                # Generate tick data based on scenario
                tick_data = self._generate_scenario_tick(instrument, elapsed)
                
                # Publish the tick
                self._publish_tick(instrument, tick_data)
                
            # Sleep until next tick
            elapsed_tick_time = time.time() - start_tick_time
            sleep_time = max(0.0, self.tick_interval - elapsed_tick_time)
            if sleep_time > 0:
                time.sleep(sleep_time)
                
        self.logger.info("Scripted tick generation completed")
        
    def _initialize_scenario(self, instrument: Instrument) -> Dict[str, Any]:
        """
        Initialize scenario-specific parameters.
        
        Args:
            instrument: Instrument to initialize scenario for
            
        Returns:
            Dict[str, Any]: Scenario parameters
        """
        params = {}
        
        if self.scenario == "trend_up":
            params["trend"] = 0.0001  # Strong uptrend
            params["volatility"] = self.volatility
            params["phase"] = 0.0  # For oscillating scenarios
            
        elif self.scenario == "trend_down":
            params["trend"] = -0.0001  # Strong downtrend
            params["volatility"] = self.volatility
            params["phase"] = 0.0
            
        elif self.scenario == "volatile":
            params["trend"] = 0.0
            params["volatility"] = self.volatility * 5.0  # High volatility
            params["phase"] = 0.0
            
        elif self.scenario == "sideways":
            params["trend"] = 0.0
            params["volatility"] = self.volatility * 0.5  # Low volatility
            params["phase"] = 0.0
            
        elif self.scenario == "breakout":
            params["trend"] = 0.0
            params["volatility"] = self.volatility
            params["breakout_time"] = self.duration * 0.7  # Breakout at 70% of duration
            params["breakout_direction"] = 1 if random.random() > 0.5 else -1
            params["breakout_magnitude"] = 0.05  # 5% price jump
            params["phase"] = 0.0
            
        else:  # random_walk
            params["trend"] = self.trend
            params["volatility"] = self.volatility
            params["phase"] = 0.0
            
        return params
        
    def _generate_scenario_tick(self, instrument: Instrument, elapsed: float) -> Dict[str, Any]:
        """
        Generate tick data based on the current scenario.
        
        Args:
            instrument: Instrument to generate tick for
            elapsed: Time elapsed since scenario start in seconds
            
        Returns:
            Dict[str, Any]: Scenario-based tick data
        """
        # Get current price and scenario parameters
        current_price = self.prices[instrument]
        params = self.scenario_params[instrument]
        
        # Calculate normalized time (0.0 to 1.0)
        normalized_time = min(1.0, elapsed / self.duration)
        
        # Generate price change based on scenario
        price_change = 0.0
        
        if self.scenario == "trend_up":
            # Accelerating uptrend
            trend_factor = params["trend"] * (1.0 + normalized_time * 2.0)
            price_change = np.random.normal(trend_factor, params["volatility"]) * current_price
            
        elif self.scenario == "trend_down":
            # Accelerating downtrend
            trend_factor = params["trend"] * (1.0 + normalized_time * 2.0)
            price_change = np.random.normal(trend_factor, params["volatility"]) * current_price
            
        elif self.scenario == "volatile":
            # Increasing volatility
            vol_factor = params["volatility"] * (1.0 + normalized_time * 3.0)
            price_change = np.random.normal(0.0, vol_factor) * current_price
            
        elif self.scenario == "sideways":
            # Oscillating sideways market
            params["phase"] += 0.01
            oscillation = np.sin(params["phase"]) * 0.0005 * current_price
            price_change = oscillation + np.random.normal(0.0, params["volatility"]) * current_price
            
        elif self.scenario == "breakout":
            # Breakout at specified time
            if elapsed >= params["breakout_time"] and elapsed < params["breakout_time"] + 5.0:
                # Apply breakout over 5 seconds
                progress = (elapsed - params["breakout_time"]) / 5.0
                breakout = params["breakout_direction"] * params["breakout_magnitude"] * progress * current_price
                price_change = breakout + np.random.normal(0.0, params["volatility"]) * current_price
            else:
                # Normal random walk before and after breakout
                price_change = np.random.normal(0.0, params["volatility"]) * current_price
                
        else:  # random_walk
            price_change = np.random.normal(params["trend"], params["volatility"]) * current_price
            
        # Update price
        new_price = max(0.01, current_price + price_change)
        self.prices[instrument] = new_price
        
        # Generate volume
        volume = max(1, int(np.random.normal(self.volume_mean, self.volume_std)))
        
        # Update cumulative volume
        self.volumes[instrument] += volume
        
        # Generate tick data
        tick_data = {
            # CRITICAL FIX: Use MarketDataType enum values as keys and IST timestamp
            MarketDataType.TIMESTAMP.value: self._generate_ist_timestamp(),
            MarketDataType.LAST_PRICE.value: new_price,
            MarketDataType.BID.value: new_price * 0.999,
            MarketDataType.ASK.value: new_price * 1.001,
            MarketDataType.VOLUME.value: self.volumes[instrument],  # Cumulative volume
            MarketDataType.OPEN.value: new_price,
            MarketDataType.HIGH.value: new_price * 1.001,
            MarketDataType.LOW.value: new_price * 0.999,
            MarketDataType.CLOSE.value: new_price,
            'event_type': EventType.MARKET_DATA  # CRITICAL FIX: Include event_type
        }
        
        return tick_data
