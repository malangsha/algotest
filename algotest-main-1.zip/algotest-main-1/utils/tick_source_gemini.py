"""
Pluggable tick replay mechanism for algorithmic trading framework.

This module provides a set of classes for generating and replaying market data ticks
from various sources, including real historical data, synthetic random data, and
scripted scenarios.

Classes:
    TickSource: Abstract base class for tick sources
    RealTickSource: Reads ticks from CSV files or connects to live market data feeds
    SyntheticTickSource: Generates random market data with configurable parameters
    ScriptedTickSource: Creates predefined market scenarios (trends, breakouts, etc.)
"""

import os
import csv
import time
import random
import logging # Ensure logging is imported
import threading
import numpy as np
import pytz
from abc import ABC, abstractmethod
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Set, Tuple

from models.instrument import Instrument # Assuming this path is correct
from models.events import MarketDataEvent, Event # Assuming this path is correct
from utils.constants import EventType, MarketDataType # Assuming this path is correct

class TickSource(ABC):
    """
    Abstract base class for tick sources.
    
    This class defines the interface that all tick sources must implement.
    """
    
    def __init__(self, event_manager):
        """
        Initialize the tick source.
        
        Args:
            event_manager: Event manager instance for publishing market data events
        """
        self.logger = logging.getLogger(self.__class__.__name__)
        self.event_manager = event_manager
        self.running = False
        self.thread = None
        self.subscriptions: Set[Instrument] = set()
        self._shutdown_event = threading.Event()
        
    def subscribe(self, instrument: Instrument) -> bool:
        """
        Subscribe to market data for an instrument.
        
        Args:
            instrument: Instrument to subscribe to
            
        Returns:
            bool: True if subscription was successful, False otherwise
        """
        if instrument in self.subscriptions:
            self.logger.warning(f"Already subscribed to {instrument.symbol}")
            return False
            
        self.subscriptions.add(instrument)
        self.logger.info(f"Subscribed to {instrument.symbol}")
        return True
        
    def unsubscribe(self, instrument: Instrument) -> bool:
        """
        Unsubscribe from market data for an instrument.
        
        Args:
            instrument: Instrument to unsubscribe from
            
        Returns:
            bool: True if unsubscription was successful, False otherwise
        """
        if instrument not in self.subscriptions:
            self.logger.warning(f"Not subscribed to {instrument.symbol}")
            return False
            
        self.subscriptions.remove(instrument)
        self.logger.info(f"Unsubscribed from {instrument.symbol}")
        return True
        
    def start(self) -> bool:
        """
        Start the tick source.
        
        Returns:
            bool: True if started successfully, False otherwise
        """
        if self.running:
            self.logger.warning("Tick source already running")
            return False
            
        self.running = True
        self._shutdown_event.clear()
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()
        self.logger.info("Tick source started")
        return True
        
    def stop(self) -> bool:
        """
        Stop the tick source.
        
        Returns:
            bool: True if stopped successfully, False otherwise
        """
        if not self.running:
            self.logger.warning("Tick source not running")
            return False
            
        self.running = False
        self._shutdown_event.set()
        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=5.0)
        self.logger.info("Tick source stopped")
        return True
        
    @abstractmethod
    def _run(self):
        """
        Main loop for generating ticks.
        
        This method must be implemented by subclasses.
        """
        pass
        
    def _publish_tick(self, instrument: Instrument, tick_data: Dict[str, Any]):
        """
        Publish a market data event.
        
        Args:
            instrument: Instrument the tick is for
            tick_data: Dictionary containing tick data fields
        """
        # Ensure event_type is properly set
        if 'event_type' not in tick_data:
            tick_data['event_type'] = EventType.MARKET_DATA
            
        # Ensure timestamp is present in the tick_data from the generator
        # If not (which shouldn't happen with SyntheticTickSource), add current time.
        # This part is more of a fallback.
        if MarketDataType.TIMESTAMP.value not in tick_data:
            self.logger.warning(f"Timestamp missing in tick_data for {instrument.symbol}. Generating one now.")
            tz = pytz.timezone("Asia/Kolkata")
            now_kolkata = datetime.now(tz)
            epoch_secs = int(now_kolkata.timestamp())
            tick_data[MarketDataType.TIMESTAMP.value] = epoch_secs
            
        # Create and publish the market data event
        # The timestamp used here is critical and comes from tick_data
        event = MarketDataEvent(
            event_type=EventType.MARKET_DATA,
            timestamp=tick_data[MarketDataType.TIMESTAMP.value], # This is the timestamp TimeframeManager will see
            instrument=instrument,
            data=tick_data
        )
        
        self.event_manager.publish(event)

class RealTickSource(TickSource):
    """
    Tick source that reads from CSV files or connects to live market data feeds.
    """
    
    def __init__(self, event_manager, data_file=None, replay_speed=1.0, loop=False):
        """
        Initialize the real tick source.
        
        Args:
            event_manager: Event manager instance
            data_file: Path to CSV file containing tick data
            replay_speed: Speed multiplier for replay (1.0 = real-time)
            loop: Whether to loop the data file when it reaches the end
        """
        super().__init__(event_manager)
        self.data_file = data_file
        self.replay_speed = replay_speed
        self.loop = loop
        self.tick_data = []
        self.current_index = 0
        
        if data_file and os.path.exists(data_file):
            self._load_data()
        else:
            self.logger.warning(f"Data file not found: {data_file}")
            
    def _load_data(self):
        """Load tick data from CSV file."""
        try:
            with open(self.data_file, 'r') as f:
                reader = csv.DictReader(f)
                self.tick_data = list(reader)
                
            self.logger.info(f"Loaded {len(self.tick_data)} ticks from {self.data_file}")
        except Exception as e:
            self.logger.error(f"Error loading data file: {str(e)}")
            self.tick_data = []
            
    def _run(self):
        """Main loop for replaying ticks from file."""
        if not self.tick_data:
            self.logger.error("No tick data to replay")
            return
            
        self.logger.info(f"Starting tick replay at {self.replay_speed}x speed")
        
        last_tick_time = None
        while self.running and not self._shutdown_event.is_set():
            if self.current_index >= len(self.tick_data):
                if self.loop:
                    self.logger.info("Reached end of tick data, looping back to start")
                    self.current_index = 0
                else:
                    self.logger.info("Reached end of tick data")
                    break
                    
            # Get the current tick
            tick = self.tick_data[self.current_index]
            
            # Extract timestamp
            try:
                # Attempt to parse ISO format timestamp first
                tick_time_str = tick.get('timestamp', '')
                if 'T' in tick_time_str or ' ' in tick_time_str: # Heuristic for ISO-like format
                    tick_time = datetime.fromisoformat(tick_time_str.replace(' ', 'T'))
                    if tick_time.tzinfo is None: # If naive, assume UTC or a default timezone
                         tick_time = pytz.utc.localize(tick_time) # Or use your system's default
                else: # Assume it's an epoch timestamp (seconds or milliseconds)
                    ts_val = float(tick_time_str)
                    if ts_val > 1e11: # Likely milliseconds
                        tick_time = datetime.fromtimestamp(ts_val / 1000, tz=pytz.utc)
                    else: # Likely seconds
                        tick_time = datetime.fromtimestamp(ts_val, tz=pytz.utc)

            except (ValueError, TypeError) as e:
                self.logger.warning(f"Invalid timestamp in tick: {tick}. Error: {e}. Skipping.")
                self.current_index += 1
                continue
                    
            # Calculate delay
            if last_tick_time is not None:
                delay = (tick_time - last_tick_time).total_seconds() / self.replay_speed
                if delay > 0:
                    time.sleep(delay)
                    
            # Find matching instrument
            symbol = tick.get('symbol', '')
            matching_instruments = [i for i in self.subscriptions if i.symbol == symbol]
            
            if not matching_instruments:
                self.logger.debug(f"No matching instrument for symbol: {symbol}")
                self.current_index += 1
                continue
                
            instrument = matching_instruments[0]
            
            # Convert tick data to standard format
            tick_data_converted = self._convert_tick(tick, instrument) # Pass instrument for context if needed
            
            # Publish the tick
            self._publish_tick(instrument, tick_data_converted)
            
            # Update last tick time
            last_tick_time = tick_time
            
            # Move to next tick
            self.current_index += 1
            
        self.logger.info("Tick replay completed")
        
    def _convert_tick(self, tick: Dict[str, str], instrument: Instrument) -> Dict[str, Any]:
        """
        Convert tick data from CSV format to standard format.
        
        Args:
            tick: Dictionary containing tick data from CSV
            instrument: The instrument object for context (e.g. exchange for timezone)
            
        Returns:
            Dict[str, Any]: Standardized tick data
        """
        result = {}
        
        # Define the timezone, potentially based on instrument's exchange
        # For simplicity, using Asia/Kolkata as default for NSE/BSE
        tz = pytz.timezone("Asia/Kolkata") # Or derive from instrument.exchange if needed

        field_mapping = {
            'timestamp': MarketDataType.TIMESTAMP.value,
            'last': MarketDataType.LAST_PRICE.value,
            'bid': MarketDataType.BID.value,
            'ask': MarketDataType.ASK.value,
            'volume': MarketDataType.VOLUME.value,
            'open': MarketDataType.OPEN.value,
            'high': MarketDataType.HIGH.value,
            'low': MarketDataType.LOW.value,
            'close': MarketDataType.CLOSE.value,
        }
        
        for csv_field, data_type_enum_val in field_mapping.items():
            if csv_field in tick and tick[csv_field] is not None and tick[csv_field] != '':
                try:
                    if csv_field == 'timestamp':
                        val_str = tick[csv_field]
                        # Try parsing as ISO format, then as epoch
                        try:
                            if 'T' in val_str or ' ' in val_str: # Heuristic for ISO-like format
                                dt_obj = datetime.fromisoformat(val_str.replace(' ', 'T'))
                            else: # Assume epoch
                                ts_val = float(val_str)
                                # Heuristic to differentiate seconds vs milliseconds
                                dt_obj = datetime.fromtimestamp(ts_val / 1000 if ts_val > 1e11 else ts_val)
                            
                            # If naive, assume it's in the target timezone or UTC
                            if dt_obj.tzinfo is None:
                                dt_obj = tz.localize(dt_obj) # Or pytz.utc.localize(dt_obj).astimezone(tz)
                            
                            result[data_type_enum_val] = int(dt_obj.timestamp()) # Store as epoch seconds
                        except ValueError:
                            self.logger.warning(f"Could not parse timestamp '{val_str}' for {instrument.symbol}. Skipping field.")
                    else:
                        result[data_type_enum_val] = float(tick[csv_field])
                except (ValueError, TypeError) as e:
                    self.logger.warning(f"Error converting field {csv_field}: '{tick[csv_field]}' for {instrument.symbol}. Error: {e}")
        
        # Ensure timestamp is present, if not parsed, use current time as fallback (should be rare)
        if MarketDataType.TIMESTAMP.value not in result:
            self.logger.warning(f"Timestamp could not be derived for {instrument.symbol} from tick: {tick}. Using current time.")
            now_kolkata = datetime.now(tz)
            result[MarketDataType.TIMESTAMP.value] = int(now_kolkata.timestamp())
            
        # Ensure last price is present if 'price' field exists (common alternative name)
        if MarketDataType.LAST_PRICE.value not in result and 'price' in tick:
            try:
                result[MarketDataType.LAST_PRICE.value] = float(tick['price'])
            except (ValueError, TypeError):
                self.logger.warning(f"Could not parse 'price' field for {instrument.symbol}: {tick['price']}")
                
        return result

class SyntheticTickSource(TickSource):
    """
    Tick source that generates random market data with configurable parameters.
    """
    
    def __init__(self, event_manager, tick_interval=0.1, volatility=0.001, trend=0.0,
                 volume_mean=100.0, volume_std=50.0, price_jump_prob=0.01, price_jump_factor=0.01):
        """
        Initialize the synthetic tick source.
        
        Args:
            event_manager: Event manager instance
            tick_interval: Time between ticks in seconds
            volatility: Standard deviation of price changes
            trend: Mean of price changes (positive = uptrend, negative = downtrend)
            volume_mean: Mean of volume
            volume_std: Standard deviation of volume
            price_jump_prob: Probability of a price jump
            price_jump_factor: Size of price jumps as a fraction of price
        """
        super().__init__(event_manager)
        self.tick_interval = tick_interval
        self.volatility = volatility
        self.trend = trend
        self.volume_mean = volume_mean
        self.volume_std = volume_std
        self.price_jump_prob = price_jump_prob
        self.price_jump_factor = price_jump_factor
        
        self.prices = {}
        self.volumes = {}
        self.logger.info("SyntheticTickSource initialized.") # Added for clarity
        
    def _run(self):
        """Main loop for generating synthetic ticks."""
        self.logger.info("Starting synthetic tick generation")
        
        for instrument in self.subscriptions:
            self.prices[instrument] = random.uniform(10.0, 100.0)
            self.volumes[instrument] = 0
            self.logger.info(f"Initial price for {instrument.symbol}: {self.prices[instrument]:.2f}")
            
        while self.running and not self._shutdown_event.is_set():
            start_time = time.time()
            
            for instrument in self.subscriptions:
                tick_data = self._generate_tick(instrument)
                self._publish_tick(instrument, tick_data)
                
            elapsed = time.time() - start_time
            sleep_time = max(0.0, self.tick_interval - elapsed)
            if sleep_time > 0:
                time.sleep(sleep_time)
                
        self.logger.info("Synthetic tick generation stopped")
        
    def _generate_tick(self, instrument: Instrument) -> Dict[str, Any]:
        """
        Generate synthetic tick data for an instrument.
        
        Args:
            instrument: Instrument to generate tick for
            
        Returns:
            Dict[str, Any]: Synthetic tick data
        """
        current_price = self.prices[instrument]
        price_change = np.random.normal(self.trend, self.volatility) * current_price
        
        if random.random() < self.price_jump_prob:
            jump_direction = 1 if random.random() > 0.5 else -1
            price_change += jump_direction * self.price_jump_factor * current_price
            
        new_price = max(0.01, current_price + price_change)
        self.prices[instrument] = new_price
        
        volume = max(1, int(np.random.normal(self.volume_mean, self.volume_std)))
        self.volumes[instrument] += volume

        # *** DIAGNOSTIC LOGGING ADDED HERE ***
        tz = pytz.timezone("Asia/Kolkata")
        current_datetime_obj = datetime.now(tz)
        epoch_seconds = int(current_datetime_obj.timestamp())
        
        # Log the generated datetime and epoch before it's used
        self.logger.debug(
            f"Generating tick for {instrument.symbol}. "
            f"datetime.now(tz): {current_datetime_obj.isoformat()}, "
            f"Generated epoch_seconds: {epoch_seconds}"
        )

        tick_data = {
            MarketDataType.TIMESTAMP.value: epoch_seconds, # Using the logged epoch_seconds
            MarketDataType.LAST_PRICE.value: new_price,
            MarketDataType.BID.value: new_price * 0.999,
            MarketDataType.ASK.value: new_price * 1.001,
            MarketDataType.VOLUME.value: self.volumes[instrument],
            MarketDataType.OPEN.value: new_price, # Simplified: open/high/low/close are same as new_price for synthetic tick
            MarketDataType.HIGH.value: new_price * 1.001, # Slight variation for H/L
            MarketDataType.LOW.value: new_price * 0.999,  # Slight variation for H/L
            MarketDataType.CLOSE.value: new_price,
            'event_type': EventType.MARKET_DATA 
        }
        
        return tick_data

class ScriptedTickSource(TickSource):
    """
    Tick source that creates predefined market scenarios.
    """
    
    def __init__(self, event_manager, scenario="random_walk", tick_interval=0.1, duration=300,
                 volatility=0.001, trend=0.0, volume_mean=100.0, volume_std=50.0,
                 price_jump_prob=0.01, price_jump_factor=0.01):
        super().__init__(event_manager)
        self.scenario = scenario
        self.tick_interval = tick_interval
        self.duration = duration
        self.volatility = volatility
        self.trend = trend
        self.volume_mean = volume_mean
        self.volume_std = volume_std
        self.price_jump_prob = price_jump_prob
        self.price_jump_factor = price_jump_factor
        
        self.prices = {}
        self.volumes = {}
        self.scenario_params = {}
        self.start_time_of_scenario = None # Renamed for clarity
        self.logger.info(f"ScriptedTickSource initialized for scenario: {self.scenario}.")

    def _run(self):
        self.logger.info(f"Starting scripted tick generation for scenario: {self.scenario}")
        
        for instrument in self.subscriptions:
            self.prices[instrument] = random.uniform(10.0, 100.0)
            self.volumes[instrument] = 0
            self.scenario_params[instrument] = self._initialize_scenario(instrument)
            self.logger.info(f"Initial price for {instrument.symbol} in script: {self.prices[instrument]:.2f}")
            
        self.start_time_of_scenario = time.time()
        
        while self.running and not self._shutdown_event.is_set():
            current_script_time = time.time()
            elapsed_scenario_time = current_script_time - self.start_time_of_scenario
            
            if elapsed_scenario_time >= self.duration:
                self.logger.info(f"Scenario duration ({self.duration}s) elapsed for {self.scenario}")
                break
                
            tick_generation_loop_start_time = time.time()
            
            for instrument in self.subscriptions:
                tick_data = self._generate_scenario_tick(instrument, elapsed_scenario_time)
                self._publish_tick(instrument, tick_data)
                
            tick_generation_loop_elapsed = time.time() - tick_generation_loop_start_time
            sleep_time = max(0.0, self.tick_interval - tick_generation_loop_elapsed)
            if sleep_time > 0:
                time.sleep(sleep_time)
                
        self.logger.info(f"Scripted tick generation completed for scenario: {self.scenario}")
        
    def _initialize_scenario(self, instrument: Instrument) -> Dict[str, Any]:
        params = {}
        base_trend = self.trend
        base_volatility = self.volatility

        if self.scenario == "trend_up":
            params["trend"] = base_trend if base_trend > 0 else 0.0001 
            params["volatility"] = base_volatility
        elif self.scenario == "trend_down":
            params["trend"] = base_trend if base_trend < 0 else -0.0001
            params["volatility"] = base_volatility
        elif self.scenario == "volatile":
            params["trend"] = base_trend
            params["volatility"] = base_volatility * 3.0 # Increased volatility
        elif self.scenario == "sideways":
            params["trend"] = 0.0 # Override base trend for sideways
            params["volatility"] = base_volatility * 0.5 # Reduced volatility
            params["phase"] = random.uniform(0, 2 * np.pi) # Random start phase for oscillation
            params["amplitude"] = 0.0005 # Oscillation amplitude
        elif self.scenario == "breakout":
            params["trend"] = 0.0 # Flat before breakout
            params["volatility"] = base_volatility
            params["breakout_time"] = self.duration * random.uniform(0.4, 0.7) # Breakout time
            params["breakout_direction"] = 1 if random.random() > 0.5 else -1
            params["breakout_magnitude"] = random.uniform(0.03, 0.07) # 3-7% price jump
            params["breakout_duration"] = random.uniform(3.0, 10.0) # Breakout occurs over 3-10 seconds
            params["post_breakout_trend"] = params["breakout_direction"] * 0.00005 # Slight trend after breakout
        else:  # random_walk (default)
            params["trend"] = base_trend
            params["volatility"] = base_volatility
            
        self.logger.debug(f"Scenario params for {instrument.symbol} ({self.scenario}): {params}")
        return params
        
    def _generate_scenario_tick(self, instrument: Instrument, elapsed_scenario_time: float) -> Dict[str, Any]:
        current_price = self.prices[instrument]
        params = self.scenario_params[instrument]
        
        normalized_time = min(1.0, elapsed_scenario_time / self.duration)
        
        price_change = 0.0
        active_trend = params.get("trend", 0.0)
        active_volatility = params.get("volatility", self.volatility)

        if self.scenario == "trend_up" or self.scenario == "trend_down":
            # Trend might accelerate slightly over time
            dynamic_trend = active_trend * (1.0 + normalized_time * 0.5) 
            price_change = np.random.normal(dynamic_trend, active_volatility) * current_price
        elif self.scenario == "volatile":
            # Volatility might increase over time
            dynamic_volatility = active_volatility * (1.0 + normalized_time * 1.0)
            price_change = np.random.normal(0.0, dynamic_volatility) * current_price
        elif self.scenario == "sideways":
            params["phase"] += (2 * np.pi / (self.duration * 0.1)) * self.tick_interval # Complete a cycle every 10% of duration
            oscillation = np.sin(params["phase"]) * params["amplitude"] * current_price
            price_change = oscillation + np.random.normal(0.0, active_volatility) * current_price
        elif self.scenario == "breakout":
            if elapsed_scenario_time >= params["breakout_time"] and \
               elapsed_scenario_time < params["breakout_time"] + params["breakout_duration"]:
                # During breakout phase
                progress = (elapsed_scenario_time - params["breakout_time"]) / params["breakout_duration"]
                breakout_amount = params["breakout_direction"] * params["breakout_magnitude"] * progress * self.prices[instrument] # Use initial price for magnitude consistency
                price_change = (breakout_amount / params["breakout_duration"] * self.tick_interval) + \
                               np.random.normal(0.0, active_volatility * 2.0) * current_price # Higher vol during breakout
            elif elapsed_scenario_time >= params["breakout_time"] + params["breakout_duration"]:
                # After breakout, apply a smaller trend
                price_change = np.random.normal(params["post_breakout_trend"], active_volatility) * current_price
            else:
                # Before breakout
                price_change = np.random.normal(active_trend, active_volatility) * current_price
        else:  # random_walk
            price_change = np.random.normal(active_trend, active_volatility) * current_price
            
        new_price = max(0.01, current_price + price_change)
        self.prices[instrument] = new_price
        
        volume = max(1, int(np.random.normal(self.volume_mean, self.volume_std)))
        self.volumes[instrument] += volume

        # *** DIAGNOSTIC LOGGING ADDED HERE ***
        tz = pytz.timezone("Asia/Kolkata")
        current_datetime_obj = datetime.now(tz) # This will be the actual current time for scripted source
        epoch_seconds = int(current_datetime_obj.timestamp())
        
        # For scripted source, you might want the timestamp to be relative to scenario start
        # This is a more advanced change. For now, using current time as per original.
        # If you need scripted timestamps, you'd calculate epoch_seconds based on
        # self.start_time_of_scenario + elapsed_scenario_time.
        
        self.logger.debug(
            f"Generating scripted tick for {instrument.symbol} ({self.scenario}). "
            f"datetime.now(tz): {current_datetime_obj.isoformat()}, "
            f"Generated epoch_seconds: {epoch_seconds}, "
            f"Elapsed Scenario Time: {elapsed_scenario_time:.2f}s"
        )

        tick_data = {
            MarketDataType.TIMESTAMP.value: epoch_seconds,
            MarketDataType.LAST_PRICE.value: new_price,
            MarketDataType.BID.value: new_price * 0.9995, # Tighter spread
            MarketDataType.ASK.value: new_price * 1.0005,  # Tighter spread
            MarketDataType.VOLUME.value: self.volumes[instrument],
            MarketDataType.OPEN.value: new_price, 
            MarketDataType.HIGH.value: new_price * 1.001,
            MarketDataType.LOW.value: new_price * 0.999,
            MarketDataType.CLOSE.value: new_price,
            'event_type': EventType.MARKET_DATA
        }
        
        return tick_data

