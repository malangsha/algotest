import pandas as pd
import numpy as np
from typing import Dict, List, Any, Optional, Union, Tuple, Set
from datetime import datetime, timedelta, time as dt_time
import threading
import time
import pytz
from collections import defaultdict, deque
from dataclasses import dataclass
from enum import Enum

from core.logging_manager import get_logger
from utils.constants import MarketDataType, EventType

class SessionType(Enum):
    """Market session types for Indian markets"""
    REGULAR = "regular"
    PRE_MARKET = "pre_market"
    POST_MARKET = "post_market"
    MUHURAT = "muhurat"
    CLOSED = "closed"


@dataclass
class SessionTiming:
    """Session timing definition"""
    start_time: dt_time
    end_time: dt_time
    session_type: SessionType
    name: str


class MarketSessionManager:
    """Manages Indian market sessions for NSE and BSE"""
    
    def __init__(self):
        self.timezone = pytz.timezone('Asia/Kolkata')
        self.sessions = {
            'NSE': [
                SessionTiming(dt_time(9, 0), dt_time(9, 15), SessionType.PRE_MARKET, "NSE Pre-Market"),
                SessionTiming(dt_time(9, 15), dt_time(15, 30), SessionType.REGULAR, "NSE Regular"),
                SessionTiming(dt_time(15, 30), dt_time(16, 0), SessionType.POST_MARKET, "NSE Post-Market"),
            ],
            'BSE': [
                SessionTiming(dt_time(9, 0), dt_time(9, 15), SessionType.PRE_MARKET, "BSE Pre-Market"),
                SessionTiming(dt_time(9, 15), dt_time(15, 30), SessionType.REGULAR, "BSE Regular"),
                SessionTiming(dt_time(15, 30), dt_time(16, 0), SessionType.POST_MARKET, "BSE Post-Market"),
            ]
        }
        
        # Weekend days (0 = Monday, 6 = Sunday)
        self.weekend_days = {5, 6}  # Saturday and Sunday
        
        # Holiday calendar - should be loaded from a file in production
        self.holidays = {
            # 2023 NSE holidays - example
            datetime(2023, 1, 26).date(),  # Republic Day
            datetime(2023, 3, 7).date(),   # Holi
            datetime(2023, 4, 7).date(),   # Good Friday
            # Add more holidays as needed
        }
        
        self.logger = get_logger("utils.market_session_manager")
    
    def is_market_open(self, timestamp: float, exchange: str = 'NSE') -> bool:
        """
        Check if the market is open at the given timestamp
        
        Args:
            timestamp: Unix timestamp in seconds
            exchange: Exchange code ('NSE' or 'BSE')
            
        Returns:
            bool: True if market is open, False otherwise
        """
        if exchange not in self.sessions:
            self.logger.warning(f"Unknown exchange: {exchange}, defaulting to NSE")
            exchange = 'NSE'
            
        dt = datetime.fromtimestamp(timestamp, self.timezone)
        
        # Check if it's a weekend
        if dt.weekday() in self.weekend_days:
            return False
            
        # Check if it's a holiday
        if dt.date() in self.holidays:
            return False
            
        # Check if it's within any session
        current_time = dt.time()
        for session in self.sessions[exchange]:
            if session.start_time <= current_time < session.end_time:
                return True
                
        return False
    
    def get_session_type(self, timestamp: float, exchange: str = 'NSE') -> SessionType:
        """
        Get the session type at the given timestamp
        
        Args:
            timestamp: Unix timestamp in seconds
            exchange: Exchange code ('NSE' or 'BSE')
            
        Returns:
            SessionType: The session type
        """
        if exchange not in self.sessions:
            self.logger.warning(f"Unknown exchange: {exchange}, defaulting to NSE")
            exchange = 'NSE'
            
        dt = datetime.fromtimestamp(timestamp, self.timezone)
        
        # Check if it's a weekend or holiday
        if dt.weekday() in self.weekend_days or dt.date() in self.holidays:
            return SessionType.CLOSED
            
        # Check which session it falls into
        current_time = dt.time()
        for session in self.sessions[exchange]:
            if session.start_time <= current_time < session.end_time:
                return session.session_type
                
        return SessionType.CLOSED
    
    def get_next_session_start(self, timestamp: float, exchange: str = 'NSE') -> float:
        """
        Get the timestamp of the next session start
        
        Args:
            timestamp: Unix timestamp in seconds
            exchange: Exchange code ('NSE' or 'BSE')
            
        Returns:
            float: Unix timestamp of next session start
        """
        dt = datetime.fromtimestamp(timestamp, self.timezone)
        current_date = dt.date()
        current_time = dt.time()
        
        # Check if there's a session starting later today
        for session in sorted(self.sessions[exchange], key=lambda s: s.start_time):
            if current_time < session.start_time:
                next_dt = datetime.combine(current_date, session.start_time)
                next_dt = self.timezone.localize(next_dt)
                return next_dt.timestamp()
        
        # If no session starts later today, find the next trading day
        days_to_add = 1
        while days_to_add < 10:  # Limit to 10 days to prevent infinite loop
            next_date = current_date + timedelta(days=days_to_add)
            
            # Skip weekends and holidays
            if next_date.weekday() not in self.weekend_days and next_date not in self.holidays:
                # Return the first session of the next trading day
                first_session = min(self.sessions[exchange], key=lambda s: s.start_time)
                next_dt = datetime.combine(next_date, first_session.start_time)
                next_dt = self.timezone.localize(next_dt)
                return next_dt.timestamp()
                
            days_to_add += 1
            
        # Fallback if no session found within 10 days
        return timestamp + 86400  # Return tomorrow's timestamp


class DataValidator:
    """Validates market data for quality and consistency"""
    
    def __init__(self):
        self.logger = get_logger("utils.data_validator")
        # Circuit breaker limits (5%, 10%, 20% for different scrips)
        self.circuit_limits = {
            'GROUP_A': 0.20,  # 20% circuit limit
            'GROUP_B': 0.10,  # 10% circuit limit
            'DEFAULT': 0.05   # 5% circuit limit
        }
        
        # Price history for validation
        self.price_history: Dict[str, deque] = defaultdict(lambda: deque(maxlen=100))
        self.lock = threading.RLock()
    
    def validate_tick(self, symbol: str, market_data: Dict[str, Any], 
                     last_close: Optional[float] = None) -> Tuple[bool, str]:
        """
        Validate a tick for data quality issues
        
        Returns:
            Tuple[bool, str]: (is_valid, reason_if_invalid)
        """
        price = market_data.get(MarketDataType.LAST_PRICE.value)
        volume = market_data.get(MarketDataType.VOLUME.value, 0)
        
        if price is None or price <= 0:
            return False, "Invalid price"
        
        if volume < 0:
            return False, "Invalid volume"
        
        # Circuit breaker check if we have last close
        if last_close and last_close > 0:
            price_change_pct = abs(price - last_close) / last_close
            limit = self.circuit_limits.get(self._get_scrip_group(symbol), 
                                           self.circuit_limits['DEFAULT'])
            
            if price_change_pct > limit:
                return False, f"Circuit breaker violation: {price_change_pct:.2%} > {limit:.2%}"
        
        # Volume spike detection
        with self.lock:
            if symbol in self.price_history:
                recent_prices = list(self.price_history[symbol])
                if len(recent_prices) >= 10:
                    avg_price = sum(recent_prices[-10:]) / 10
                    if abs(price - avg_price) / avg_price > 0.1:  # 10% deviation
                        self.logger.warning(f"Significant price deviation for {symbol}: "
                                          f"current={price}, avg={avg_price:.2f}")
            
            self.price_history[symbol].append(price)
        
        return True, ""
    
    def _get_scrip_group(self, symbol: str) -> str:
        """Determine scrip group for circuit breaker limits"""
        # Simple heuristic - in production, this should be from market data
        if 'NSE:' in symbol and any(x in symbol for x in ['RELIANCE', 'TCS', 'INFY', 'HDFC']):
            return 'GROUP_A'
        return 'DEFAULT'


class PerformanceMonitor:
    """Monitors performance metrics for the TimeframeManager"""
    
    def __init__(self):
        self.metrics = {
            'bars_completed': defaultdict(int),
            'ticks_processed': defaultdict(int),
            'processing_latency': defaultdict(list),
            'memory_usage': defaultdict(int),
            'errors': defaultdict(int),
        }
        self.lock = threading.RLock()
        self.start_time = time.time()
    
    def record_bar_completion(self, symbol: str, timeframe: str):
        """Record a bar completion event"""
        with self.lock:
            self.metrics['bars_completed'][f"{symbol}:{timeframe}"] += 1
    
    def record_tick_processing(self, symbol: str, processing_time: float):
        """Record tick processing time"""
        with self.lock:
            self.metrics['ticks_processed'][symbol] += 1
            self.metrics['processing_latency'][symbol].append(processing_time)
            # Keep only last 1000 measurements
            if len(self.metrics['processing_latency'][symbol]) > 1000:
                self.metrics['processing_latency'][symbol] = \
                    self.metrics['processing_latency'][symbol][-1000:]
    
    def record_error(self, symbol: str, error_type: str):
        """Record an error event"""
        with self.lock:
            self.metrics['errors'][f"{symbol}:{error_type}"] += 1
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get performance statistics"""
        with self.lock:
            stats = {
                'uptime_seconds': time.time() - self.start_time,
                'total_bars_completed': sum(self.metrics['bars_completed'].values()),
                'total_ticks_processed': sum(self.metrics['ticks_processed'].values()),
                'total_errors': sum(self.metrics['errors'].values()),
            }
            
            # Calculate average latency per symbol
            latency_stats = {}
            for symbol, latencies in self.metrics['processing_latency'].items():
                if latencies:
                    latency_stats[symbol] = {
                        'avg_ms': np.mean(latencies) * 1000,
                        'max_ms': np.max(latencies) * 1000,
                        'min_ms': np.min(latencies) * 1000,
                        'p95_ms': np.percentile(latencies, 95) * 1000 if len(latencies) > 20 else 0
                    }
            stats['latency_by_symbol'] = latency_stats
            
            return stats


class TimeframeManager:
    """
    Enhanced TimeframeManager with market session awareness, improved thread safety,
    data validation, and performance monitoring for Indian markets.
    """

    # Supported timeframes with Indian market focus
    SUPPORTED_TIMEFRAMES: Dict[str, int] = {
        '1m': 60, '3m': 180, '5m': 300, '15m': 900, '30m': 1800,
        '1h': 3600, '4h': 14400, '1d': 86400,
    }

    BAR_COLUMNS: List[str] = ['timestamp', 'open', 'high', 'low', 'close', 'volume', 'open_interest']

    def __init__(self, 
                 max_bars_in_memory: int = 10000,
                 enable_market_session_validation: bool = True,
                 enable_data_validation: bool = True,
                 enable_performance_monitoring: bool = True,
                 default_exchange: str = 'NSE'):
        """
        Initialize the Enhanced TimeframeManager.

        Args:
            max_bars_in_memory: Maximum bars to keep in memory per symbol/timeframe
            enable_market_session_validation: Enable market session checks
            enable_data_validation: Enable data quality validation
            enable_performance_monitoring: Enable performance metrics collection
            default_exchange: Default exchange (NSE or BSE)
        """
        self.logger = get_logger("utils.enhanced_timeframe_manager")
        self.max_bars_in_memory = max_bars_in_memory
        self.default_exchange = default_exchange
        
        # Initialize components
        self.market_session_manager = MarketSessionManager() if enable_market_session_validation else None
        self.data_validator = DataValidator() if enable_data_validation else None
        self.performance_monitor = PerformanceMonitor() if enable_performance_monitoring else None
        
        # Thread-safe data structures with fine-grained locking
        self.completed_bars_buffer: Dict[str, Dict[str, deque]] = defaultdict(
            lambda: defaultdict(lambda: deque(maxlen=self.max_bars_in_memory))
        )
        self.bars_df_cache: Dict[str, Dict[str, pd.DataFrame]] = defaultdict(dict)
        self.current_bars: Dict[str, Dict[str, Dict[str, Any]]] = defaultdict(dict)
        self.last_tick_time: Dict[str, float] = {}
        self.last_close_prices: Dict[str, float] = {}  # For circuit breaker validation
        
        # Separate locks for different data structures
        self.current_bars_lock = threading.RLock()
        self.completed_bars_lock = threading.RLock()
        self.cache_lock = threading.RLock()
        self.general_lock = threading.RLock()
        
        # Symbol metadata cache for performance
        self.symbol_metadata: Dict[str, Dict[str, Any]] = {}
        self.symbol_metadata_lock = threading.RLock()
        
        # Market session cache for performance optimization
        self.session_cache: Dict[str, Dict[str, Any]] = {}  # exchange -> {is_open, next_transition, last_check}
        self.session_cache_lock = threading.RLock()
        self.session_cache_validity = 300  # Cache validity in seconds (5 minutes max)

        
        # Memory monitoring
        self.memory_warning_threshold = max_bars_in_memory * 0.8
        
        self.logger.info(f"Enhanced TimeframeManager initialized. "
                        f"Market validation: {enable_market_session_validation}, "
                        f"Data validation: {enable_data_validation}, "
                        f"Performance monitoring: {enable_performance_monitoring}")

    def _is_market_open_cached(self, timestamp_sec: float, exchange: str) -> bool:
        """
        Check if market is open using cached session state for performance.
        Only calls the full market session check when crossing session boundaries.
        """
        if not self.market_session_manager:
            return True
            
        with self.session_cache_lock:
            cache_entry = self.session_cache.get(exchange)
            current_time = timestamp_sec
            
            # If we have a valid cache entry
            if cache_entry:
                last_check = cache_entry.get('last_check', 0)
                is_open = cache_entry.get('is_open', False)
                next_transition = cache_entry.get('next_transition', 0)
                
                # If cache is still valid and we haven't crossed a session boundary
                if (current_time - last_check < self.session_cache_validity and 
                    current_time < next_transition):
                    return is_open
            
            # Cache miss or expired, do full check
            is_open = self.market_session_manager.is_market_open(timestamp_sec, exchange)
            
            # Calculate next transition time
            if is_open:
                # If market is open, next transition is when it closes
                # Find the current session and get its end time
                session_type = self.market_session_manager.get_session_type(timestamp_sec, exchange)
                for session in self.market_session_manager.sessions[exchange]:
                    if session.session_type == session_type:
                        dt = datetime.fromtimestamp(timestamp_sec, self.market_session_manager.timezone)
                        next_dt = datetime.combine(dt.date(), session.end_time)
                        next_dt = self.market_session_manager.timezone.localize(next_dt)
                        next_transition = next_dt.timestamp()
                        break
                else:
                    # Fallback if session not found
                    next_transition = timestamp_sec + 3600  # 1 hour
            else:
                # If market is closed, next transition is when it opens
                next_transition = self.market_session_manager.get_next_session_start(timestamp_sec, exchange)
            
            # Update cache
            self.session_cache[exchange] = {
                'is_open': is_open,
                'next_transition': next_transition,
                'last_check': current_time
            }
            
            return is_open

    def ensure_timeframe_tracked(self, symbol: str, timeframe: str) -> None:
        if timeframe not in self.SUPPORTED_TIMEFRAMES:
            self.logger.warning(f"Unsupported timeframe '{timeframe}' for symbol '{symbol}'") 
            return
        
        with self.current_bars_lock: 
            if symbol not in self.current_bars: 
                self.current_bars[symbol] = {} 
            
            # Ensure the timeframe is a key in self.current_bars[symbol]
            # Initialize to None if this is the first time it's being tracked,
            # indicating no bar object has been created yet.
            if timeframe not in self.current_bars[symbol]: 
                self.current_bars[symbol][timeframe] = None 
                self.logger.info(f"Started tracking '{timeframe}' for symbol '{symbol}'. Awaiting first tick to create bar.") 
        
        # completed_bars_buffer and bars_df_cache are defaultdict, access initializes them.
        with self.completed_bars_lock: 
            _ = self.completed_bars_buffer[symbol][timeframe] 
        
        with self.cache_lock: 
            _ = self.bars_df_cache[symbol] 
            
    def process_tick(self, symbol: str, market_data: Dict[str, Any]) -> Dict[str, bool]:
        """
        Process a tick for a symbol and update bars.
        
        Args:
            symbol: Symbol identifier
            market_data: Dictionary containing market data fields
            
        Returns:
            Dict[str, bool]: Dictionary of timeframes with boolean indicating if a bar was completed
        """
        start_time = time.time()
        
        try:
            # 1. Extract required fields
            try:
                timestamp_ms = market_data.get(MarketDataType.TIMESTAMP.value)
                if timestamp_ms is None:
                    self.logger.warning(f"Missing timestamp in market data for {symbol}")
                    if self.performance_monitor:
                        self.performance_monitor.record_error(symbol, "missing_timestamp")
                    return {}
                
                # Convert timestamp to seconds if it's in milliseconds
                timestamp_sec = timestamp_ms / 1000.0 if timestamp_ms > 1e10 else timestamp_ms
                
                price = market_data.get(MarketDataType.LAST_PRICE.value)
                if price is None:
                    self.logger.warning(f"Missing price in market data for {symbol}")
                    if self.performance_monitor:
                        self.performance_monitor.record_error(symbol, "missing_price")
                    return {}
                
                volume = market_data.get(MarketDataType.VOLUME.value, 0)
                open_interest = market_data.get(MarketDataType.OPEN_INTEREST.value, 0)
                
            except Exception as e:
                self.logger.error(f"Error extracting data from market data for {symbol}: {e}")
                if self.performance_monitor:
                    self.performance_monitor.record_error(symbol, "data_conversion_error")
                return {}
            
            # 2. Data validation
            if self.data_validator:
                last_close = self.last_close_prices.get(symbol)
                is_valid, reason = self.data_validator.validate_tick(symbol, market_data, last_close)
                if not is_valid:
                    self.logger.warning(f"Invalid tick for {symbol}: {reason}. Tick: {market_data}")
                    if self.performance_monitor:
                        self.performance_monitor.record_error(symbol, f"validation_error_{reason}")
                    return {}
            
            # 3. Market session validation
            if self.market_session_manager:
                exchange = symbol.split(':')[0] if ':' in symbol else self.default_exchange
                if not self._is_market_open_cached(timestamp_sec, exchange):
                    session_type = self.market_session_manager.get_session_type(timestamp_sec, exchange)
                    self.logger.debug(f"Tick for {symbol} outside trading hours. Session: {session_type.value}")
                    # We still process the tick, but log it for awareness
            
            # 4. Update last tick time and price
            with self.general_lock:
                self.last_tick_time[symbol] = timestamp_sec
                self.last_close_prices[symbol] = price
            
            # 5. Process tick for each timeframe
            bars_completed = {}
            
            with self.current_bars_lock:
                if symbol not in self.current_bars:
                    self.logger.debug(f"Symbol {symbol} not tracked yet. Initializing.")
                    self.current_bars[symbol] = {}
                
                # Process each timeframe
                for timeframe, seconds in self.SUPPORTED_TIMEFRAMES.items():
                    # Skip if this timeframe is not being tracked for this symbol
                    if timeframe not in self.current_bars[symbol]:
                        continue
                    
                    # Get the current bar for this timeframe
                    current_bar = self.current_bars[symbol].get(timeframe)
                    
                    # Calculate the bar's start time (floor to timeframe boundary)
                    bar_start_time = int(timestamp_sec // seconds * seconds)
                    
                    # If no current bar or the tick belongs to a new bar
                    if current_bar is None or bar_start_time > current_bar['timestamp']:
                        # If we had a previous bar, complete it and add to buffer
                        if current_bar is not None:
                            self._complete_bar(symbol, timeframe, current_bar)
                            bars_completed[timeframe] = True
                        
                        # Create a new bar
                        self.current_bars[symbol][timeframe] = {
                            'timestamp': bar_start_time,
                            'open': price,
                            'high': price,
                            'low': price,
                            'close': price,
                            'volume': volume,
                            'open_interest': open_interest
                        }
                    else:
                        # Update the current bar
                        current_bar['high'] = max(current_bar['high'], price)
                        current_bar['low'] = min(current_bar['low'], price)
                        current_bar['close'] = price
                        current_bar['volume'] += volume
                        
                        # Update open interest if available
                        if open_interest is not None and open_interest > 0:
                            current_bar['open_interest'] = open_interest
            
            # 6. Record performance metrics
            if self.performance_monitor:
                processing_time = time.time() - start_time
                self.performance_monitor.record_tick_processing(symbol, processing_time)
                
                # Record bar completions
                for timeframe in bars_completed:
                    self.performance_monitor.record_bar_completion(symbol, timeframe)
            
            return bars_completed
            
        except Exception as e:
            self.logger.error(f"Error processing tick for {symbol}: {e}", exc_info=True)
            if self.performance_monitor:
                self.performance_monitor.record_error(symbol, "processing_error")
            return {}

    def _complete_bar(self, symbol: str, timeframe: str, bar: Dict[str, Any]) -> None:
        """
        Complete a bar and add it to the buffer
        
        Args:
            symbol: Symbol identifier
            timeframe: Timeframe identifier
            bar: Bar data dictionary
        """
        try:
            # Add to completed bars buffer
            with self.completed_bars_lock:
                self.completed_bars_buffer[symbol][timeframe].append(bar.copy())
                
                # Invalidate DataFrame cache
                with self.cache_lock:
                    if symbol in self.bars_df_cache and timeframe in self.bars_df_cache[symbol]:
                        del self.bars_df_cache[symbol][timeframe]
                
            # Publish bar event
            from core.event_manager import EventManager
            from models.events import BarEvent
            
            # Get the event manager instance - in production, this should be passed in
            event_manager = EventManager.get_instance()
            
            if event_manager:
                # Extract exchange and symbol
                parts = symbol.split(':')
                exchange = parts[0] if len(parts) > 1 else self.default_exchange
                symbol_only = parts[1] if len(parts) > 1 else symbol
                
                # Create instrument object
                from models.instrument import Instrument
                instrument = Instrument(
                    symbol=symbol_only,
                    exchange=exchange
                )
                
                # Create and publish bar event
                bar_event = BarEvent(
                    event_type=EventType.BAR,
                    timestamp=int(time.time() * 1000),  # Current time in ms
                    instrument=instrument,
                    timeframe=timeframe,
                    bar_start_time=bar['timestamp'] * 1000,  # Convert to ms
                    open_price=bar['open'],
                    high_price=bar['high'],
                    low_price=bar['low'],
                    close_price=bar['close'],
                    volume=bar['volume'],
                    open_interest=bar.get('open_interest', 0)
                )
                
                event_manager.publish(bar_event)
                
        except Exception as e:
            self.logger.error(f"Error completing bar for {symbol} {timeframe}: {e}", exc_info=True)
            if self.performance_monitor:
                self.performance_monitor.record_error(symbol, "bar_completion_error")

    def get_bars(self, symbol: str, timeframe: str, count: int = 100) -> Optional[pd.DataFrame]:
        """
        Get historical bars for a symbol and timeframe
        
        Args:
            symbol: Symbol identifier
            timeframe: Timeframe identifier
            count: Number of bars to return
            
        Returns:
            Optional[pd.DataFrame]: DataFrame with bar data or None if not available
        """
        if timeframe not in self.SUPPORTED_TIMEFRAMES:
            self.logger.warning(f"Unsupported timeframe: {timeframe}")
            return None
            
        # Check if we have a cached DataFrame
        with self.cache_lock:
            if (symbol in self.bars_df_cache and 
                timeframe in self.bars_df_cache[symbol] and
                len(self.bars_df_cache[symbol][timeframe]) >= count):
                return self.bars_df_cache[symbol][timeframe].tail(count).copy()
        
        # Get bars from buffer
        with self.completed_bars_lock:
            if symbol not in self.completed_bars_buffer:
                self.logger.warning(f"No bars available for symbol: {symbol}")
                return None
                
            if timeframe not in self.completed_bars_buffer[symbol]:
                self.logger.warning(f"No bars available for timeframe: {timeframe}")
                return None
                
            bars = list(self.completed_bars_buffer[symbol][timeframe])
            
        if not bars:
            self.logger.warning(f"No bars available for {symbol} {timeframe}")
            return None
            
        # Convert to DataFrame
        df = pd.DataFrame(bars)
        
        # Convert timestamp to datetime
        df['datetime'] = pd.to_datetime(df['timestamp'], unit='s')
        
        # Set index
        df.set_index('datetime', inplace=True)
        
        # Cache the DataFrame
        with self.cache_lock:
            self.bars_df_cache[symbol][timeframe] = df.copy()
            
        return df.tail(count).copy()
    
    def get_latest_bar(self, symbol: str, timeframe: str) -> Optional[Dict[str, Any]]:
        """
        Get the latest bar for a symbol and timeframe
        
        Args:
            symbol: Symbol identifier
            timeframe: Timeframe identifier
            
        Returns:
            Optional[Dict[str, Any]]: Latest bar data or None if not available
        """
        with self.completed_bars_lock:
            if (symbol in self.completed_bars_buffer and 
                timeframe in self.completed_bars_buffer[symbol] and
                len(self.completed_bars_buffer[symbol][timeframe]) > 0):
                return dict(self.completed_bars_buffer[symbol][timeframe][-1])
        return None
    
    def get_current_bar(self, symbol: str, timeframe: str) -> Optional[Dict[str, Any]]:
        """
        Get the current (incomplete) bar for a symbol and timeframe
        
        Args:
            symbol: Symbol identifier
            timeframe: Timeframe identifier
            
        Returns:
            Optional[Dict[str, Any]]: Current bar data or None if not available
        """
        with self.current_bars_lock:
            if (symbol in self.current_bars and 
                timeframe in self.current_bars[symbol]):
                return dict(self.current_bars[symbol][timeframe])
        return None
    
    def subscribe_symbol(self, instrument: Any, timeframe: str) -> bool:
        """
        Subscribe to a symbol for a specific timeframe
        
        Args:
            instrument: Instrument object or symbol string
            timeframe: Timeframe identifier
            
        Returns:
            bool: True if subscription was successful, False otherwise
        """
        if timeframe not in self.SUPPORTED_TIMEFRAMES:
            self.logger.warning(f"Unsupported timeframe: {timeframe}")
            return False
            
        # Handle both instrument objects and symbol strings
        if isinstance(instrument, str):
            symbol = instrument
        else:
            # Assume it's an instrument object with symbol and exchange attributes
            try:
                exchange = instrument.exchange.value if hasattr(instrument.exchange, 'value') else instrument.exchange
                symbol = f"{exchange}:{instrument.symbol}"
            except AttributeError:
                self.logger.error(f"Invalid instrument object: {instrument}")
                return False
                
        with self.current_bars_lock:
            if symbol not in self.current_bars:
                self.current_bars[symbol] = {}
                
            if timeframe not in self.current_bars[symbol]:
                self.current_bars[symbol][timeframe] = None
                self.logger.info(f"Subscribed to {symbol} {timeframe}")
                return True
            else:
                self.logger.warning(f"Already subscribed to {symbol} {timeframe}")
                return False
    
    def unsubscribe_symbol(self, instrument: Any, timeframe: str) -> bool:
        """
        Unsubscribe from a symbol for a specific timeframe
        
        Args:
            instrument: Instrument object or symbol string
            timeframe: Timeframe identifier
            
        Returns:
            bool: True if unsubscription was successful, False otherwise
        """
        # Handle both instrument objects and symbol strings
        if isinstance(instrument, str):
            symbol = instrument
        else:
            # Assume it's an instrument object with symbol and exchange attributes
            try:
                exchange = instrument.exchange.value if hasattr(instrument.exchange, 'value') else instrument.exchange
                symbol = f"{exchange}:{instrument.symbol}"
            except AttributeError:
                self.logger.error(f"Invalid instrument object: {instrument}")
                return False
                
        with self.current_bars_lock:
            if symbol in self.current_bars and timeframe in self.current_bars[symbol]:
                del self.current_bars[symbol][timeframe]
                
                # If no more timeframes for this symbol, remove the symbol entry
                if not self.current_bars[symbol]:
                    del self.current_bars[symbol]
                    
                self.logger.info(f"Unsubscribed from {symbol} {timeframe}")
                return True
            else:
                self.logger.warning(f"Not subscribed to {symbol} {timeframe}")
                return False
    
    def get_tracked_symbols_and_timeframes(self) -> Dict[str, List[str]]:
        """
        Get all symbols and timeframes currently being tracked
        
        Returns:
            Dict[str, List[str]]: Dictionary of symbols to list of timeframes
        """
        result = {}
        with self.current_bars_lock:
            for symbol, timeframes in self.current_bars.items():
                result[symbol] = list(timeframes.keys())
        return result
    
    def get_performance_statistics(self) -> Dict[str, Any]:
        """
        Get performance statistics
        
        Returns:
            Dict[str, Any]: Dictionary of performance statistics
        """
        if self.performance_monitor:
            return self.performance_monitor.get_statistics()
        return {}
    
    def clear_data(self, symbol: Optional[str] = None, timeframe: Optional[str] = None) -> None:
        """
        Clear data for a symbol and/or timeframe
        
        Args:
            symbol: Symbol to clear data for, or None for all symbols
            timeframe: Timeframe to clear data for, or None for all timeframes
        """
        with self.completed_bars_lock, self.current_bars_lock, self.cache_lock:
            if symbol is None:
                # Clear all data
                self.completed_bars_buffer.clear()
                self.current_bars.clear()
                self.bars_df_cache.clear()
                self.last_tick_time.clear()
                self.last_close_prices.clear()
                self.logger.info("Cleared all data")
            elif timeframe is None:
                # Clear data for a specific symbol
                if symbol in self.completed_bars_buffer:
                    del self.completed_bars_buffer[symbol]
                if symbol in self.current_bars:
                    del self.current_bars[symbol]
                if symbol in self.bars_df_cache:
                    del self.bars_df_cache[symbol]
                if symbol in self.last_tick_time:
                    del self.last_tick_time[symbol]
                if symbol in self.last_close_prices:
                    del self.last_close_prices[symbol]
                self.logger.info(f"Cleared data for {symbol}")
            else:
                # Clear data for a specific symbol and timeframe
                if symbol in self.completed_bars_buffer and timeframe in self.completed_bars_buffer[symbol]:
                    del self.completed_bars_buffer[symbol][timeframe]
                if symbol in self.current_bars and timeframe in self.current_bars[symbol]:
                    del self.current_bars[symbol][timeframe]
                if symbol in self.bars_df_cache and timeframe in self.bars_df_cache[symbol]:
                    del self.bars_df_cache[symbol][timeframe]
                self.logger.info(f"Cleared data for {symbol} {timeframe}")
