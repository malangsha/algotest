import pandas as pd
import numpy as np
from typing import Dict, List, Any, Optional, Tuple, Set, Callable, Union
from datetime import datetime, timedelta, time as dt_time
import threading
import time
import pytz
from collections import defaultdict, deque
from dataclasses import dataclass, field
from enum import Enum
from concurrent.futures import ThreadPoolExecutor
import asyncio
from pathlib import Path
import json
import logging
import os # For path joining

# Configure basic logging
# In a real application, this would be part of a centralized logging setup
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s') # CHANGED to DEBUG
logger = logging.getLogger(__name__)


class MarketDataType(Enum):
    """Enum for market data keys to ensure consistency."""
    TIMESTAMP = "timestamp"
    LAST_PRICE = "last_price"
    VOLUME = "volume"
    OPEN_INTEREST = "open_interest"
    # Add other relevant market data types if needed


class SessionType(Enum):
    """Market session types."""
    REGULAR = "regular"
    PRE_MARKET = "pre_market"
    POST_MARKET = "post_market"
    MUHURAT = "muhurat"  # Special Muhurat trading session
    CLOSED = "closed"


@dataclass
class SessionTiming:
    """Session timing definition with timezone awareness."""
    start_time: dt_time
    end_time: dt_time
    session_type: SessionType
    name: str
    timezone: pytz.BaseTzInfo = field(default_factory=lambda: pytz.timezone('Asia/Kolkata'))

    def is_active(self, dt_object: datetime) -> bool:
        """Check if session is active at given datetime object."""
        if not dt_object.tzinfo:
            # If datetime is naive, assume it's in the session's timezone
            localized_dt = self.timezone.localize(dt_object)
        else:
            localized_dt = dt_object.astimezone(self.timezone)
        current_time = localized_dt.time()
        return self.start_time <= current_time < self.end_time # Use < for end_time for typical interval logic


@dataclass
class MarketHoliday:
    """Market holiday definition."""
    date: str  #<x_bin_411>-MM-DD format
    name: str
    exchanges: Set[str] = field(default_factory=set)  # Exchanges affected by this holiday

    @property
    def datetime_date(self) -> datetime.date:
        return datetime.strptime(self.date, "%Y-%m-%d").date()


@dataclass
class BarData:
    """Represents a single OHLCV bar."""
    timestamp: int  # Unix timestamp (seconds) for the start of the bar
    open: float
    high: float
    low: float
    close: float
    volume: float
    open_interest: Optional[float] = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "timestamp": self.timestamp,
            "open": self.open,
            "high": self.high,
            "low": self.low,
            "close": self.close,
            "volume": self.volume,
            "open_interest": self.open_interest
        }


@dataclass
class TimeframeManagerConfig:
    """Configuration for the TimeframeManager."""
    timeframes: Dict[str, int] = field(default_factory=lambda: { # timeframe string to seconds
        '1m': 60, '3m': 180, '5m': 300, '15m': 900, '30m': 1800,
        '1h': 3600, '4h': 14400, '1d': 86400,
    })
    max_bars_in_memory_per_timeframe: int = 10000
    default_exchange: str = 'NSE'
    data_persistence_path: Optional[str] = None # Path to store bar data
    holidays_file_path: Optional[str] = None # Path to holidays JSON file

    # Data Validation Config
    enable_data_validation: bool = True
    max_price_change_percentage: float = 0.20 # Default 20%
    max_volume_spike_factor: float = 10.0 # e.g., 10x average volume
    max_stale_data_seconds: int = 300 # 5 minutes
    min_ticks_for_vol_avg: int = 10

    # Market Session Config
    enable_market_session_validation: bool = True
    market_sessions: Dict[str, List[SessionTiming]] = field(default_factory=dict) # Exchange -> List of SessionTimings

    # Performance Monitoring Config
    enable_performance_monitoring: bool = True

    # Event Handling
    event_callback: Optional[Callable[[BarData, str, str], None]] = None # callback for completed bars: (bar_data, symbol, timeframe)


class MarketHolidayManager:
    """Manages market holidays."""
    def __init__(self, file_path: Optional[str] = None):
        self.holidays_by_exchange: Dict[str, Set[datetime.date]] = defaultdict(set)
        self.all_holidays: Set[datetime.date] = set()
        self.logger = logger.getChild(self.__class__.__name__)
        if file_path:
            self._load_holidays(file_path)

    def _load_holidays(self, file_path: str):
        try:
            path = Path(file_path)
            if not path.exists():
                self.logger.warning(f"Holidays file not found: {file_path}")
                return

            with open(path, 'r') as f:
                holidays_data = json.load(f)
            
            for holiday_entry in holidays_data:
                try:
                    holiday = MarketHoliday(
                        date=holiday_entry['date'],
                        name=holiday_entry['name'],
                        exchanges=set(holiday_entry.get('exchanges', []))
                    )
                    date_obj = holiday.datetime_date
                    self.all_holidays.add(date_obj)
                    if not holiday.exchanges: # If no specific exchanges, assume it's for all
                        # This part might need refinement based on how "all exchanges" is defined
                        self.logger.debug(f"Holiday {holiday.name} on {holiday.date} applies generally.")
                    for exch_code in holiday.exchanges:
                        self.holidays_by_exchange[exch_code.upper()].add(date_obj)
                except KeyError as e:
                    self.logger.error(f"Missing key {e} in holiday entry: {holiday_entry}")
                except ValueError as e:
                    self.logger.error(f"Invalid date format in holiday entry {holiday_entry}: {e}")
            self.logger.info(f"Loaded {len(self.all_holidays)} unique holiday dates from {file_path}")
        except Exception as e:
            self.logger.error(f"Failed to load holidays from {file_path}: {e}", exc_info=True)

    def is_holiday(self, date_to_check: datetime.date, exchange: Optional[str] = None) -> bool:
        """Check if a given date is a holiday for a specific exchange or any exchange."""
        if exchange:
            return date_to_check in self.holidays_by_exchange.get(exchange.upper(), set())
        return date_to_check in self.all_holidays


class MarketSessionManager:
    """Manages market sessions for exchanges."""
    def __init__(self, 
                 holiday_manager: MarketHolidayManager, 
                 config_sessions: Dict[str, List[SessionTiming]],
                 default_exchange: str = 'NSE'):
        self.holiday_manager = holiday_manager
        self.sessions_by_exchange: Dict[str, List[SessionTiming]] = {
            exch.upper(): sorted(sessions, key=lambda s: s.start_time) 
            for exch, sessions in config_sessions.items()
        }
        self.default_exchange = default_exchange.upper()
        self.timezone = pytz.timezone('Asia/Kolkata') # Default, can be made configurable
        self.weekend_days = {5, 6}  # Saturday and Sunday (0=Monday, 6=Sunday)
        self.logger = logger.getChild(self.__class__.__name__)

        # Example default sessions if not provided in config (for NSE)
        if not self.sessions_by_exchange.get(self.default_exchange) and self.default_exchange == 'NSE':
             self.sessions_by_exchange[self.default_exchange] = sorted([
                SessionTiming(dt_time(9, 0), dt_time(9, 15), SessionType.PRE_MARKET, "NSE Pre-Market"),
                SessionTiming(dt_time(9, 15), dt_time(15, 30), SessionType.REGULAR, "NSE Regular"),
                SessionTiming(dt_time(15, 30), dt_time(16, 0), SessionType.POST_MARKET, "NSE Post-Market"),
            ], key=lambda s: s.start_time)
             self.logger.info(f"Using default NSE sessions as no specific sessions provided for {self.default_exchange}.")


    def _get_sessions_for_exchange(self, exchange: str) -> List[SessionTiming]:
        return self.sessions_by_exchange.get(exchange.upper(), 
                                             self.sessions_by_exchange.get(self.default_exchange, []))

    def get_current_session_info(self, timestamp_sec: float, exchange: str) -> Tuple[SessionType, Optional[SessionTiming]]:
        """Get current session type and timing details."""
        # Ensure the timestamp is treated as being in the session manager's timezone (Asia/Kolkata)
        dt_object = datetime.fromtimestamp(timestamp_sec, self.timezone)
        self.logger.debug(f"get_current_session_info: Converted timestamp_sec {timestamp_sec} to dt_object {dt_object} (tz: {dt_object.tzinfo}) for exchange {exchange}")


        if dt_object.weekday() in self.weekend_days:
            self.logger.debug(f"get_current_session_info: Date {dt_object.date()} ({dt_object.strftime('%A')}) is a weekend. Market CLOSED.")
            return SessionType.CLOSED, None
        if self.holiday_manager.is_holiday(dt_object.date(), exchange):
            self.logger.debug(f"get_current_session_info: Date {dt_object.date()} is a holiday for {exchange}. Market CLOSED.")
            return SessionType.CLOSED, None

        current_sessions = self._get_sessions_for_exchange(exchange)
        if not current_sessions:
            self.logger.warning(f"get_current_session_info: No sessions defined for exchange {exchange}. Market considered CLOSED.")
            return SessionType.CLOSED, None
            
        self.logger.debug(f"get_current_session_info: Checking against sessions for {exchange}: {current_sessions}")
        for session in current_sessions:
            self.logger.debug(f"get_current_session_info: Checking session '{session.name}' ({session.start_time} - {session.end_time})")
            if session.is_active(dt_object):
                self.logger.debug(f"get_current_session_info: Timestamp {dt_object} is ACTIVE in session '{session.name}'. SessionType: {session.session_type}")
                return session.session_type, session
            else:
                self.logger.debug(f"get_current_session_info: Timestamp {dt_object} is NOT active in session '{session.name}'")
        
        self.logger.debug(f"get_current_session_info: Timestamp {dt_object} not in any active session for {exchange}. Market CLOSED.")
        return SessionType.CLOSED, None

    def is_market_open(self, timestamp_sec: float, exchange: str) -> bool:
        """Check if the market is open at the given timestamp."""
        self.logger.debug(f"is_market_open: Checking for exchange {exchange} at timestamp_sec {timestamp_sec}")
        session_type, _ = self.get_current_session_info(timestamp_sec, exchange)
        is_open_result = session_type != SessionType.CLOSED
        self.logger.debug(f"is_market_open: Result for exchange {exchange} is {is_open_result} (SessionType: {session_type})")
        return is_open_result

    def get_next_session_start_or_current_end(self, timestamp_sec: float, exchange: str) -> Tuple[Optional[float], Optional[float]]:
        """
        Returns (next_session_start_ts, current_session_end_ts).
        If market is closed, current_session_end_ts is None.
        If market is open, next_session_start_ts is None (or start of next day's first session if it's the last session).
        """
        dt_object = datetime.fromtimestamp(timestamp_sec, self.timezone)
        current_date = dt_object.date()
        
        session_type, current_session_timing = self.get_current_session_info(timestamp_sec, exchange)

        current_session_end_ts: Optional[float] = None
        if current_session_timing:
            end_dt = self.timezone.localize(datetime.combine(current_date, current_session_timing.end_time))
            current_session_end_ts = end_dt.timestamp()

        # Find next session start
        # 1. Check for later sessions today
        current_sessions = self._get_sessions_for_exchange(exchange)
        for session in current_sessions:
            if session.start_time > dt_object.time(): # Found a session later today
                # Ensure this day is not a weekend/holiday
                if not (dt_object.weekday() in self.weekend_days or self.holiday_manager.is_holiday(current_date, exchange)):
                    next_start_dt = self.timezone.localize(datetime.combine(current_date, session.start_time))
                    return next_start_dt.timestamp(), current_session_end_ts
        
        # 2. Check for sessions on subsequent days
        for days_ahead in range(1, 8): # Check up to a week ahead
            next_potential_date = current_date + timedelta(days=days_ahead)
            if next_potential_date.weekday() in self.weekend_days or \
               self.holiday_manager.is_holiday(next_potential_date, exchange):
                continue
            
            # Found a valid next trading day
            if current_sessions: # Should always have sessions if configured
                first_session_next_day = current_sessions[0] # Assumes sorted
                next_start_dt = self.timezone.localize(datetime.combine(next_potential_date, first_session_next_day.start_time))
                return next_start_dt.timestamp(), current_session_end_ts
        
        return None, current_session_end_ts # No upcoming session found within a week


class DataValidator:
    """Validates market data ticks."""
    def __init__(self, config: TimeframeManagerConfig):
        self.config = config
        self.price_history: Dict[str, deque] = defaultdict(lambda: deque(maxlen=config.min_ticks_for_vol_avg * 2)) # symbol -> prices
        self.volume_history: Dict[str, deque] = defaultdict(lambda: deque(maxlen=config.min_ticks_for_vol_avg)) # symbol -> volumes
        self.last_tick_times: Dict[str, float] = {} # symbol -> timestamp
        self.logger = logger.getChild(self.__class__.__name__)
        self.lock = threading.RLock()

    def validate_tick(self, symbol: str, market_data: Dict[str, Any], last_close_price: Optional[float]) -> Tuple[bool, str]:
        """Validate a single tick."""
        if not self.config.enable_data_validation:
            return True, "Validation disabled"

        timestamp = market_data.get(MarketDataType.TIMESTAMP.value)
        price = market_data.get(MarketDataType.LAST_PRICE.value)
        volume = market_data.get(MarketDataType.VOLUME.value, 0) # Default volume to 0 if not present

        if timestamp is None or price is None:
            return False, "Missing timestamp or price"
        
        timestamp_sec = timestamp / 1000.0 if timestamp > 1e10 else timestamp # ms to s

        with self.lock:
            # 1. Stale data check
            if symbol in self.last_tick_times and \
               (timestamp_sec - self.last_tick_times[symbol]) > self.config.max_stale_data_seconds:
                self.logger.warning(f"Stale data for {symbol}: current_ts={timestamp_sec}, last_ts={self.last_tick_times[symbol]}")
                # Potentially allow stale data but log it, or return False
            
            # 2. Price sanity check (e.g., not zero or negative)
            if price <= 0:
                return False, f"Invalid price: {price}"

            # 3. Price change / circuit breaker (simplified)
            if last_close_price and last_close_price > 0:
                change_pct = abs(price - last_close_price) / last_close_price
                if change_pct > self.config.max_price_change_percentage:
                    return False, f"Price change {change_pct*100:.2f}% exceeds limit {self.config.max_price_change_percentage*100:.2f}%"

            # 4. Volume spike detection (optional, can be noisy)
            if len(self.volume_history[symbol]) >= self.config.min_ticks_for_vol_avg and volume > 0:
                avg_volume = sum(self.volume_history[symbol]) / len(self.volume_history[symbol]) if self.volume_history[symbol] else 0
                if avg_volume > 0 and volume > avg_volume * self.config.max_volume_spike_factor:
                    self.logger.warning(f"Volume spike for {symbol}: {volume} vs avg {avg_volume:.2f}")
            
            # Update history
            self.price_history[symbol].append(price)
            if volume > 0 : self.volume_history[symbol].append(volume) # Only positive volumes
            self.last_tick_times[symbol] = timestamp_sec
            
        return True, "Valid tick"


class PerformanceMonitor:
    """Monitors performance metrics for the TimeframeManager."""
    def __init__(self):
        self.metrics: Dict[str, Any] = {
            'bars_completed_total': 0,
            'bars_completed_per_key': defaultdict(int), # key: symbol:timeframe
            'ticks_processed_total': 0,
            'ticks_processed_per_symbol': defaultdict(int),
            'processing_latency_ms': deque(maxlen=10000), # Store recent latencies
            'errors_total': 0,
            'errors_per_type': defaultdict(int), # key: error_description
        }
        self.lock = threading.RLock()
        self.start_time = time.monotonic()
        self.logger = logger.getChild(self.__class__.__name__)

    def record_bar_completion(self, symbol: str, timeframe: str):
        with self.lock:
            self.metrics['bars_completed_total'] += 1
            self.metrics['bars_completed_per_key'][f"{symbol}:{timeframe}"] += 1

    def record_tick_processing(self, symbol: str, latency_sec: float):
        with self.lock:
            self.metrics['ticks_processed_total'] += 1
            self.metrics['ticks_processed_per_symbol'][symbol] += 1
            self.metrics['processing_latency_ms'].append(latency_sec * 1000)

    def record_error(self, error_type: str, symbol: Optional[str] = None):
        with self.lock:
            self.metrics['errors_total'] += 1
            key = f"{symbol}:{error_type}" if symbol else error_type
            self.metrics['errors_per_type'][key] += 1

    def get_statistics(self) -> Dict[str, Any]:
        with self.lock:
            uptime_seconds = time.monotonic() - self.start_time
            stats = {
                'uptime_seconds': uptime_seconds,
                'total_bars_completed': self.metrics['bars_completed_total'],
                'total_ticks_processed': self.metrics['ticks_processed_total'],
                'total_errors': self.metrics['errors_total'],
                'errors_by_type': dict(self.metrics['errors_per_type']),
                'bars_completed_by_key': dict(self.metrics['bars_completed_per_key']),
            }
            if self.metrics['processing_latency_ms']:
                latencies = list(self.metrics['processing_latency_ms'])
                stats['latency_stats_ms'] = {
                    'avg': np.mean(latencies) if latencies else 0,
                    'p50': np.percentile(latencies, 50) if latencies else 0,
                    'p95': np.percentile(latencies, 95) if latencies else 0,
                    'p99': np.percentile(latencies, 99) if latencies else 0,
                    'max': np.max(latencies) if latencies else 0,
                    'min': np.min(latencies) if latencies else 0,
                    'count': len(latencies)
                }
            return stats

    def log_statistics(self, interval_seconds: int = 300): # Log every 5 minutes
        # This could be run in a separate thread
        stats = self.get_statistics()
        self.logger.info(f"Performance Stats: {stats}")
        # Schedule next log
        # threading.Timer(interval_seconds, self.log_statistics, [interval_seconds]).start()


class TimeframeManager:
    """
    Manages time-based aggregation of market data ticks into OHLCV bars
    for multiple symbols and timeframes. Includes features like data validation,
    market session awareness, data persistence, and performance monitoring.
    """

    def __init__(self, config: TimeframeManagerConfig):
        self.config = config
        self.logger = logger.getChild(self.__class__.__name__)
        # self.logger.setLevel(logging.DEBUG) # Uncomment for forcing debug on this logger instance

        # Core data structures
        # Stores currently forming (incomplete) bars: {symbol_tf_key: BarData}
        self._current_bars: Dict[str, BarData] = {}
        # Stores completed bars: {symbol_tf_key: deque[BarData]}
        self._completed_bars_buffer: Dict[str, deque[BarData]] = defaultdict(
            lambda: deque(maxlen=self.config.max_bars_in_memory_per_timeframe)
        )
        # Cache for DataFrames: {symbol_tf_key: pd.DataFrame}
        self._bars_df_cache: Dict[str, pd.DataFrame] = {}
        
        self._last_tick_times: Dict[str, float] = {} # {symbol: timestamp_sec}
        self._last_close_prices: Dict[str, float] = {} # {symbol: price} for validation

        # Subscriptions: {symbol: Set[timeframe_str]}
        self._subscriptions: Dict[str, Set[str]] = defaultdict(set)

        # Locking - use fine-grained locks where possible
        self._subscription_lock = threading.RLock()
        self._current_bar_lock = threading.RLock() # Protects _current_bars
        self._completed_bar_lock = threading.RLock() # Protects _completed_bars_buffer
        self._cache_lock = threading.RLock() # Protects _bars_df_cache
        self._tick_meta_lock = threading.RLock() # Protects _last_tick_times, _last_close_prices

        # Components
        self._holiday_manager = MarketHolidayManager(config.holidays_file_path)
        self._session_manager = MarketSessionManager(self._holiday_manager, config.market_sessions, config.default_exchange)
        self._data_validator = DataValidator(config) if config.enable_data_validation else None
        self._perf_monitor = PerformanceMonitor() if config.enable_performance_monitoring else None
        
        # Persistence
        self._persistor_executor = None
        if config.data_persistence_path:
            Path(config.data_persistence_path).mkdir(parents=True, exist_ok=True)
            self._persistor_executor = ThreadPoolExecutor(max_workers=2, thread_name_prefix="BarPersistor")
            self._load_all_persisted_data()

        self.logger.info(f"TimeframeManager initialized with {len(config.timeframes)} timeframes. Persistence: {'Enabled' if config.data_persistence_path else 'Disabled'}")

    def _get_symbol_timeframe_key(self, symbol: str, timeframe: str) -> str:
        return f"{symbol.upper()}_{timeframe}"
        
    def _get_exchange_from_symbol(self, symbol: str) -> str:
        # Basic assumption: "EXCHANGE:SYMBOL_CODE" or just "SYMBOL_CODE" (uses default)
        parts = symbol.split(':', 1)
        return parts[0].upper() if len(parts) > 1 else self.config.default_exchange.upper()

    def subscribe(self, symbol: str, timeframes: List[str]):
        """Subscribe to one or more timeframes for a given symbol."""
        with self._subscription_lock:
            normalized_symbol = symbol.upper()
            for tf_str in timeframes:
                if tf_str not in self.config.timeframes:
                    self.logger.warning(f"Unsupported timeframe '{tf_str}' for subscription to '{normalized_symbol}'. Skipping.")
                    continue
                self._subscriptions[normalized_symbol].add(tf_str)
                self.logger.info(f"Subscribed to {normalized_symbol} for timeframe {tf_str}")

    def unsubscribe(self, symbol: str, timeframes: List[str]):
        """Unsubscribe from one or more timeframes for a given symbol."""
        with self._subscription_lock:
            normalized_symbol = symbol.upper()
            for tf_str in timeframes:
                if normalized_symbol in self._subscriptions and tf_str in self._subscriptions[normalized_symbol]:
                    self._subscriptions[normalized_symbol].remove(tf_str)
                    self.logger.info(f"Unsubscribed from {normalized_symbol} for timeframe {tf_str}")
                    if not self._subscriptions[normalized_symbol]: 
                        del self._subscriptions[normalized_symbol]
                        self.logger.info(f"Removed all subscriptions for {normalized_symbol}")
                else:
                    self.logger.warning(f"Not subscribed to {normalized_symbol} for timeframe {tf_str}. Cannot unsubscribe.")
    
    def get_active_subscriptions(self) -> Dict[str, List[str]]:
        with self._subscription_lock:
            return {symbol: list(tfs) for symbol, tfs in self._subscriptions.items()}

    def process_tick(self, symbol: str, market_data: Dict[str, Any]) -> Dict[str, bool]:
        """
        Process a single market data tick.
        Returns a dictionary indicating which timeframes completed a bar.
        e.g., {'1m': True, '5m': False}
        """
        processing_start_time = time.monotonic()
        normalized_symbol = symbol.upper()
        # PT_DEBUG messages added below
        self.logger.debug(f"PT_DEBUG [1]: Processing tick for {normalized_symbol} with data: {market_data}")

        # 0. Check if subscribed to this symbol at all
        with self._subscription_lock:
            if normalized_symbol not in self._subscriptions or not self._subscriptions[normalized_symbol]:
                self.logger.debug(f"PT_DEBUG [2]: Ignoring tick for unsubscribed symbol: {normalized_symbol}")
                return {}
        self.logger.debug(f"PT_DEBUG [3]: Symbol {normalized_symbol} is subscribed. Subscriptions: {self._subscriptions[normalized_symbol]}")

        # 1. Extract essential data
        price = market_data.get(MarketDataType.LAST_PRICE.value)
        timestamp_ms = market_data.get(MarketDataType.TIMESTAMP.value)
        volume = market_data.get(MarketDataType.VOLUME.value, 0.0) 
        open_interest = market_data.get(MarketDataType.OPEN_INTEREST.value, 0.0)

        if price is None or timestamp_ms is None:
            self.logger.warning(f"PT_DEBUG [4]: Tick for {normalized_symbol} missing price or timestamp. Data: {market_data}")
            if self._perf_monitor: self._perf_monitor.record_error("missing_price_or_ts", normalized_symbol)
            return {}
        
        timestamp_sec = timestamp_ms / 1000.0 if timestamp_ms > 1e10 else timestamp_ms
        self.logger.debug(f"PT_DEBUG [5]: Extracted price={price}, ts_sec={timestamp_sec} (from ts_ms={timestamp_ms}) for {normalized_symbol}")

        # 2. Market Session Validation
        exchange = self._get_exchange_from_symbol(normalized_symbol)
        self.logger.debug(f"PT_DEBUG [6]: Validating market session for {normalized_symbol} on exchange '{exchange}' at ts_sec={timestamp_sec} (enable_market_session_validation: {self.config.enable_market_session_validation})")
        if self.config.enable_market_session_validation and self._session_manager:
            is_open = self._session_manager.is_market_open(timestamp_sec, exchange)
            self.logger.debug(f"PT_DEBUG [7]: Market session validation for {normalized_symbol}: is_market_open={is_open}")
            if not is_open:
                self.logger.debug(f"PT_DEBUG [8]: Tick for {normalized_symbol} (exchange '{exchange}') outside market hours. Current time based on tick: {datetime.fromtimestamp(timestamp_sec, self._session_manager.timezone)}. Ignoring.")
                return {}
        self.logger.debug(f"PT_DEBUG [9]: Market session check passed (or disabled) for {normalized_symbol}.")

        # 3. Data Validation
        self.logger.debug(f"PT_DEBUG [10]: Validating data for {normalized_symbol} (enable_data_validation: {self.config.enable_data_validation})")
        if self.config.enable_data_validation and self._data_validator:
            last_close = self._last_close_prices.get(normalized_symbol)
            self.logger.debug(f"PT_DEBUG [10a]: Last close for {normalized_symbol} is {last_close}")
            is_valid, reason = self._data_validator.validate_tick(normalized_symbol, market_data, last_close)
            self.logger.debug(f"PT_DEBUG [11]: Data validation for {normalized_symbol}: is_valid={is_valid}, reason='{reason}'")
            if not is_valid:
                self.logger.warning(f"PT_DEBUG [12]: Invalid tick for {normalized_symbol}: {reason}. Data: {market_data}")
                if self._perf_monitor: self._perf_monitor.record_error(f"validation_failed_{reason}", normalized_symbol)
                return {}
        self.logger.debug(f"PT_DEBUG [13]: Data validation passed (or disabled) for {normalized_symbol}.")
        
        with self._tick_meta_lock:
            self._last_tick_times[normalized_symbol] = timestamp_sec
            self._last_close_prices[normalized_symbol] = price
        self.logger.debug(f"PT_DEBUG [14]: Updated last_tick_time and last_close_price for {normalized_symbol}.")


        completed_bars_for_timeframes: Dict[str, bool] = {}

        with self._subscription_lock: 
            subscribed_timeframes_for_symbol = list(self._subscriptions.get(normalized_symbol, []))
        
        self.logger.debug(f"PT_DEBUG [15]: Processing for subscribed timeframes of {normalized_symbol}: {subscribed_timeframes_for_symbol}")

        for tf_str in subscribed_timeframes_for_symbol:
            self.logger.debug(f"PT_DEBUG [16]: Processing timeframe '{tf_str}' for {normalized_symbol}.")
            if tf_str not in self.config.timeframes:
                self.logger.warning(f"PT_DEBUG [16a]: Timeframe '{tf_str}' not in config.timeframes. Skipping for {normalized_symbol}.")
                continue

            tf_seconds = self.config.timeframes[tf_str]
            symbol_tf_key = self._get_symbol_timeframe_key(normalized_symbol, tf_str)
            bar_start_timestamp = int(timestamp_sec // tf_seconds * tf_seconds)
            self.logger.debug(f"PT_DEBUG [17]: {symbol_tf_key} - Tick ts_sec={timestamp_sec}, tf_seconds={tf_seconds}, bar_start_ts={bar_start_timestamp}")


            with self._current_bar_lock:
                current_bar = self._current_bars.get(symbol_tf_key)
                self.logger.debug(f"PT_DEBUG [18]: {symbol_tf_key} - Current bar before update: {current_bar.to_dict() if current_bar else 'None'}")

                if current_bar is None or bar_start_timestamp > current_bar.timestamp:
                    self.logger.debug(f"PT_DEBUG [19]: {symbol_tf_key} - New bar condition met (current_bar is None or bar_start_timestamp {bar_start_timestamp} > current_bar.timestamp {current_bar.timestamp if current_bar else 'N/A'}).")
                    if current_bar is not None:
                        self.logger.debug(f"PT_DEBUG [20]: {symbol_tf_key} - Completing old bar: {current_bar.to_dict()}")
                        self._complete_bar(normalized_symbol, tf_str, current_bar)
                        completed_bars_for_timeframes[tf_str] = True
                    
                    
                    new_bar = BarData(
                        timestamp=bar_start_timestamp,
                        open=price, high=price, low=price, close=price,
                        volume=volume, open_interest=open_interest
                    )
                    self._current_bars[symbol_tf_key] = new_bar
                    self.logger.debug(f"PT_DEBUG [21]: {symbol_tf_key} - Created new bar: {new_bar.to_dict()}")
                    if tf_str not in completed_bars_for_timeframes: 
                         completed_bars_for_timeframes[tf_str] = False

                else: 
                    self.logger.debug(f"PT_DEBUG [22]: {symbol_tf_key} - Updating existing bar.")
                    current_bar.high = max(current_bar.high, price)
                    current_bar.low = min(current_bar.low, price)
                    current_bar.close = price
                    current_bar.volume += volume 
                    current_bar.open_interest = open_interest 
                    completed_bars_for_timeframes[tf_str] = False
                    self.logger.debug(f"PT_DEBUG [23]: {symbol_tf_key} - Updated bar: {current_bar.to_dict()}")
        
        self.logger.debug(f"PT_DEBUG [24]: {normalized_symbol} - Completed bars for timeframes: {completed_bars_for_timeframes}")
        if self._perf_monitor:
            latency = time.monotonic() - processing_start_time
            self._perf_monitor.record_tick_processing(normalized_symbol, latency)
            self.logger.debug(f"PT_DEBUG [25]: {normalized_symbol} - Recorded tick processing. Latency: {latency*1000:.2f} ms. Total ticks: {self._perf_monitor.metrics['ticks_processed_per_symbol'][normalized_symbol]}")
            for tf_str_completed, completed_flag in completed_bars_for_timeframes.items(): # Corrected iteration
                if completed_flag: # Check the boolean flag
                    self._perf_monitor.record_bar_completion(normalized_symbol, tf_str_completed)
                    self.logger.debug(f"PT_DEBUG [26]: {normalized_symbol} - Recorded bar completion for timeframe {tf_str_completed}.")

        
        return completed_bars_for_timeframes

    def _complete_bar(self, symbol: str, timeframe: str, bar_to_complete: BarData):
        """Internal method to finalize a bar and handle post-completion tasks."""
        symbol_tf_key = self._get_symbol_timeframe_key(symbol, timeframe)
        self.logger.debug(f"PT_DEBUG_CB [1]: Completing bar for {symbol_tf_key}: {bar_to_complete.to_dict()}")
        
        with self._completed_bar_lock:
            self._completed_bars_buffer[symbol_tf_key].append(bar_to_complete)
            self.logger.debug(f"PT_DEBUG_CB [2]: Appended to completed_bars_buffer for {symbol_tf_key}. Buffer size: {len(self._completed_bars_buffer[symbol_tf_key])}")

        
        with self._cache_lock: 
            if symbol_tf_key in self._bars_df_cache:
                del self._bars_df_cache[symbol_tf_key]
                self.logger.debug(f"PT_DEBUG_CB [3]: Invalidated _bars_df_cache for {symbol_tf_key}")
        
        if self._persistor_executor and self.config.data_persistence_path:
            self.logger.debug(f"PT_DEBUG_CB [4]: Submitting bar for persistence: {symbol_tf_key}")
            self._persistor_executor.submit(self._persist_bar_data_async, symbol, timeframe, bar_to_complete)

        if self.config.event_callback:
            self.logger.debug(f"PT_DEBUG_CB [5]: Calling event_callback for {symbol_tf_key}")
            try:
                self.config.event_callback(bar_to_complete, symbol, timeframe)
            except Exception as e:
                self.logger.error(f"Error in event_callback for {symbol_tf_key}: {e}", exc_info=True)
                if self._perf_monitor: self._perf_monitor.record_error("event_callback_error", symbol_tf_key)
        
        self.logger.info(f"Completed bar for {symbol_tf_key}: T={datetime.fromtimestamp(bar_to_complete.timestamp)} O={bar_to_complete.open} H={bar_to_complete.high} L={bar_to_complete.low} C={bar_to_complete.close} V={bar_to_complete.volume}")

    def get_bars(self, symbol: str, timeframe: str, count: Optional[int] = None) -> Optional[pd.DataFrame]:
        """Retrieve completed bars as a Pandas DataFrame."""
        normalized_symbol = symbol.upper()
        if timeframe not in self.config.timeframes:
            self.logger.warning(f"Unsupported timeframe: {timeframe}")
            return None
        
        symbol_tf_key = self._get_symbol_timeframe_key(normalized_symbol, timeframe)
        
        with self._cache_lock:
            cached_df = self._bars_df_cache.get(symbol_tf_key)
            if cached_df is not None:
                self.logger.debug(f"Cache hit for {symbol_tf_key} in get_bars.")
                return cached_df.tail(count).copy() if count else cached_df.copy()
        self.logger.debug(f"Cache miss for {symbol_tf_key} in get_bars.")


        with self._completed_bar_lock:
            bars_list = list(self._completed_bars_buffer.get(symbol_tf_key, []))

        if not bars_list:
            self.logger.debug(f"No completed bars available in buffer for {symbol_tf_key}")
            return pd.DataFrame(columns=['timestamp', 'open', 'high', 'low', 'close', 'volume', 'open_interest', 'datetime']).set_index('datetime')


        df = pd.DataFrame([b.to_dict() for b in bars_list])
        if 'timestamp' not in df.columns: # Should not happen if BarData.to_dict() is correct
             self.logger.error(f"DataFrame for {symbol_tf_key} missing 'timestamp' column after creation from bars_list. Columns: {df.columns}")
             return pd.DataFrame(columns=['timestamp', 'open', 'high', 'low', 'close', 'volume', 'open_interest', 'datetime']).set_index('datetime')

        df['datetime'] = pd.to_datetime(df['timestamp'], unit='s')
        df.set_index('datetime', inplace=True)
        
        with self._cache_lock:
            self._bars_df_cache[symbol_tf_key] = df.copy() 
            self.logger.debug(f"Populated cache for {symbol_tf_key} in get_bars. DF length: {len(df)}")

        
        return df.tail(count).copy() if count else df.copy()

    def get_latest_completed_bar(self, symbol: str, timeframe: str) -> Optional[BarData]:
        """Get the most recently completed bar."""
        normalized_symbol = symbol.upper()
        symbol_tf_key = self._get_symbol_timeframe_key(normalized_symbol, timeframe)
        with self._completed_bar_lock:
            buffer = self._completed_bars_buffer.get(symbol_tf_key)
            if buffer:
                return buffer[-1] 
        return None

    def get_current_bar(self, symbol: str, timeframe: str) -> Optional[BarData]:
        """Get the currently forming (incomplete) bar."""
        normalized_symbol = symbol.upper()
        symbol_tf_key = self._get_symbol_timeframe_key(normalized_symbol, timeframe)
        with self._current_bar_lock:
            return self._current_bars.get(symbol_tf_key)
            
    # --- Persistence Methods ---
    def _get_bar_data_path(self, symbol: str, timeframe: str) -> Path:
        if not self.config.data_persistence_path:
            raise ValueError("Data persistence path not configured.")
        
        safe_symbol = "".join(c if c.isalnum() else "_" for c in symbol)
        safe_timeframe = "".join(c if c.isalnum() else "_" for c in timeframe)
        
        return Path(self.config.data_persistence_path) / f"{safe_symbol}_{safe_timeframe}_bars.jsonl"

    def _persist_bar_data_async(self, symbol: str, timeframe: str, bar_data: BarData):
        """Persists a single bar to a JSONL file (append mode)."""
        try:
            file_path = self._get_bar_data_path(symbol, timeframe)
            self.logger.debug(f"Persisting bar to {file_path}: {bar_data.to_dict()}")
            with open(file_path, 'a') as f:
                json.dump(bar_data.to_dict(), f)
                f.write('\n')
        except Exception as e:
            self.logger.error(f"Failed to persist bar for {symbol}_{timeframe} to {file_path}: {e}", exc_info=True)
            if self._perf_monitor: self._perf_monitor.record_error("persistence_failure", f"{symbol}_{timeframe}")

    def _load_all_persisted_data(self):
        """Loads all persisted bar data on initialization."""
        if not self.config.data_persistence_path or not self._persistor_executor:
            self.logger.debug("Persistence path not configured or executor not available. Skipping load.")
            return
        
        self.logger.info("Starting load of persisted bar data...")
        root_path = Path(self.config.data_persistence_path)
        futures = []
        if root_path.exists() and root_path.is_dir(): 
            for file_path in root_path.glob("*_bars.jsonl"):
                self.logger.debug(f"Found persisted data file: {file_path}")
                parts = file_path.name.rsplit('_', 2) 
                if len(parts) == 3 and parts[2] == "bars.jsonl":
                    symbol, timeframe = parts[0], parts[1]
                    self.logger.debug(f"Scheduling load for symbol '{symbol}', timeframe '{timeframe}' from {file_path}")
                    futures.append(self._persistor_executor.submit(self._load_bars_from_file, file_path, symbol, timeframe))
                else:
                    self.logger.warning(f"Skipping file with unexpected name format: {file_path.name}")
        else:
            self.logger.warning(f"Persistence path {root_path} does not exist or is not a directory. Skipping load.")

        for i, future in enumerate(futures):
            try:
                self.logger.debug(f"Waiting for load future {i+1}/{len(futures)} to complete.")
                future.result() 
            except Exception as e:
                self.logger.error(f"Error during initial data load from future {i+1}: {e}", exc_info=True)
        self.logger.info("Finished loading persisted bar data.")

    def _load_bars_from_file(self, file_path: Path, symbol: str, timeframe: str):
        symbol_tf_key = self._get_symbol_timeframe_key(symbol, timeframe)
        loaded_bars: List[BarData] = []
        self.logger.debug(f"Loading bars for {symbol_tf_key} from {file_path}")
        try:
            with open(file_path, 'r') as f:
                for i, line in enumerate(f):
                    try:
                        data = json.loads(line)
                        loaded_bars.append(BarData(**data))
                    except json.JSONDecodeError:
                        self.logger.warning(f"Skipping invalid JSON line {i+1} in {file_path}: {line.strip()}")
                    except TypeError as te: 
                        self.logger.warning(f"Skipping line {i+1} with mismatched keys for BarData in {file_path}: {line.strip()}. Error: {te}")


            if loaded_bars:
                loaded_bars.sort(key=lambda b: b.timestamp)
                
                with self._completed_bar_lock:
                    if symbol_tf_key not in self._completed_bars_buffer:
                        self._completed_bars_buffer[symbol_tf_key] = deque(maxlen=self.config.max_bars_in_memory_per_timeframe)
                    
                    self._completed_bars_buffer[symbol_tf_key].extend(loaded_bars)

                self.logger.info(f"Loaded {len(loaded_bars)} bars for {symbol_tf_key} from {file_path}. Buffer size: {len(self._completed_bars_buffer[symbol_tf_key])}")
                
                with self._tick_meta_lock:
                    self._last_close_prices[symbol] = loaded_bars[-1].close
                    self._last_tick_times[symbol] = loaded_bars[-1].timestamp 
                    self.logger.debug(f"Updated last_close_price ({self._last_close_prices[symbol]}) and last_tick_time ({self._last_tick_times[symbol]}) for {symbol} from persisted data.")
            else:
                self.logger.debug(f"No valid bars loaded from {file_path} for {symbol_tf_key}.")

            
        except FileNotFoundError:
            self.logger.warning(f"Persistence file not found during load for {symbol_tf_key}: {file_path}")
        except Exception as e:
            self.logger.error(f"Failed to load bars for {symbol_tf_key} from {file_path}: {e}", exc_info=True)
            if self._perf_monitor: self._perf_monitor.record_error("load_persistence_error", symbol_tf_key)
            
    def get_performance_statistics(self) -> Optional[Dict[str, Any]]:
        if self._perf_monitor:
            return self._perf_monitor.get_statistics()
        return None

    def shutdown(self):
        """Gracefully shut down the TimeframeManager."""
        self.logger.info("Shutting down TimeframeManager...")
        if self._persistor_executor:
            self.logger.info("Waiting for pending persistence tasks to complete...")
            self._persistor_executor.shutdown(wait=True)
            self.logger.info("Persistence tasks completed.")
        
        self.logger.info("TimeframeManager shutdown complete.")


# --- Example Usage ---
if __name__ == '__main__':
    # This example demonstrates basic setup and usage.
    # In a real application, you'd integrate this with a data feed and event system.

    # 1. Configure
    example_config = TimeframeManagerConfig(
        timeframes={'1s': 1, '5s': 5, '1m': 60}, 
        max_bars_in_memory_per_timeframe=100,
        default_exchange='SIM_EX', 
        data_persistence_path=os.path.join(Path(__file__).parent, "bar_data_store_example"), 
        holidays_file_path=None, 
        enable_data_validation=True,
        max_price_change_percentage=0.50, 
        enable_market_session_validation=True,
        market_sessions={ 
            'SIM_EX': [
                SessionTiming(dt_time(0, 0), dt_time(23, 59, 59), SessionType.REGULAR, "Simulated Trading Hours (All Day)")
            ]
        },
        enable_performance_monitoring=True
    )

    # Simple event callback for demo
    def my_bar_event_handler(bar: BarData, symbol: str, timeframe: str):
        dt_obj = datetime.fromtimestamp(bar.timestamp)
        logger.info(f"[EVENT] New Bar for {symbol} [{timeframe}] at {dt_obj}: "
                    f"O={bar.open:.2f} H={bar.high:.2f} L={bar.low:.2f} C={bar.close:.2f} V={bar.volume:.0f}")

    example_config.event_callback = my_bar_event_handler
    
    # 2. Initialize TimeframeManager
    manager = TimeframeManager(example_config)

    # 3. Subscribe to symbols and timeframes
    manager.subscribe("SIM_STOCK_A", ["1s", "5s"])
    manager.subscribe("SIM_STOCK_B", ["5s", "1m"])

    logger.info(f"Active subscriptions: {manager.get_active_subscriptions()}")

    # 4. Simulate processing ticks
    start_price_a = 100.0
    start_price_b = 200.0
    
    # Use a fixed start time for the simulation for reproducibility, ensuring it's a weekday
    sim_tz = pytz.timezone('Asia/Kolkata')
    base_sim_dt = datetime.now(sim_tz)

    # Adjust to the previous Friday if current day is Sat (5) or Sun (6)
    if base_sim_dt.weekday() == 5: # Saturday
        base_sim_dt = base_sim_dt - timedelta(days=1)
    elif base_sim_dt.weekday() == 6: # Sunday
        base_sim_dt = base_sim_dt - timedelta(days=2)
    
    current_sim_dt = base_sim_dt.replace(hour=10, minute=0, second=0, microsecond=0) # Start at 10 AM on a weekday
    current_sim_time_sec = current_sim_dt.timestamp()
    logger.info(f"Simulation starting on a weekday: {current_sim_dt.strftime('%Y-%m-%d %A %H:%M:%S %Z%z')} (ts: {current_sim_time_sec})")


    try:
        logger.info("Simulating tick processing for 30 seconds...")
        sim_duration_seconds = 30 
        sim_start_time_monotonic = time.monotonic() 

        tick_counter = 0
        while time.monotonic() - sim_start_time_monotonic < sim_duration_seconds:
            current_sim_time_sec += 0.1 
            
            price_a = start_price_a + np.random.randn() * 0.1 
            volume_a = np.random.randint(10, 100)
            tick_a = {
                MarketDataType.TIMESTAMP.value: current_sim_time_sec * 1000, 
                MarketDataType.LAST_PRICE.value: price_a,
                MarketDataType.VOLUME.value: volume_a
            }
            # logger.debug(f"MAIN_SIM: Processing tick_a: {tick_a}") # Optional: very verbose
            manager.process_tick("SIM_STOCK_A", tick_a)

            if tick_counter % 2 == 0:
                price_b = start_price_b + np.random.randn() * 0.2
                volume_b = np.random.randint(50, 150)
                tick_b = {
                    MarketDataType.TIMESTAMP.value: current_sim_time_sec * 1000, 
                    MarketDataType.LAST_PRICE.value: price_b,
                    MarketDataType.VOLUME.value: volume_b
                }
                # logger.debug(f"MAIN_SIM: Processing tick_b: {tick_b}") # Optional: very verbose
                manager.process_tick("SIM_STOCK_B", tick_b)
            
            tick_counter +=1
            time.sleep(0.05) 

    except KeyboardInterrupt:
        logger.info("Simulation interrupted by user.")
    finally:
        logger.info("\n--- Retrieving Bars after Simulation ---")
        df_a_1s = manager.get_bars("SIM_STOCK_A", "1s")
        if df_a_1s is not None and not df_a_1s.empty:
            logger.info(f"\nSIM_STOCK_A - 1s bars:\n{df_a_1s.tail()}")
        else:
            logger.info(f"\nSIM_STOCK_A - 1s bars: No bars generated or DataFrame is empty.")


        df_b_1m = manager.get_bars("SIM_STOCK_B", "1m")
        if df_b_1m is not None and not df_b_1m.empty:
            logger.info(f"\nSIM_STOCK_B - 1m bars:\n{df_b_1m.tail()}")
        else:
            logger.info(f"\nSIM_STOCK_B - 1m bars: No bars generated or DataFrame is empty.")


        latest_a_5s = manager.get_latest_completed_bar("SIM_STOCK_A", "5s")
        if latest_a_5s:
             logger.info(f"\nLatest completed 5s bar for SIM_STOCK_A: {latest_a_5s.to_dict()}")
        else:
            logger.info(f"\nLatest completed 5s bar for SIM_STOCK_A: None found.")

        
        current_b_5s = manager.get_current_bar("SIM_STOCK_B", "5s")
        if current_b_5s:
             logger.info(f"\nCurrent forming 5s bar for SIM_STOCK_B: {current_b_5s.to_dict()}")
        else:
            logger.info(f"\nCurrent forming 5s bar for SIM_STOCK_B: None found.")


        perf_stats = manager.get_performance_statistics()
        if perf_stats:
            logger.info(f"\n--- Performance Statistics --- \n{json.dumps(perf_stats, indent=2, default=str)}")

        manager.shutdown()
        logger.info("Example finished.")

